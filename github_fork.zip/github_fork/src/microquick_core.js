/* MicroQuick statistical core — v1.1.0 (MIT)
 * DOM-free. Runs unchanged in the browser (global MQ) and in Node.js (module.exports),
 * so that the code that is validated is byte-for-byte the code that users run.
 * Every estimator is implemented from its primary publication; see docs/METHODS.md. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MQ = factory();
})(typeof self !== 'undefined' ? self : this, function () {
'use strict';
const VERSION = '1.1.0';

// ───────────────────────── numerics ─────────────────────────
function lnGamma(x) {
  const c = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
  let y = x, t = x + 5.5; t -= (x + 0.5) * Math.log(t);
  let ser = 1.000000000190015;
  for (let j = 0; j < 6; j++) ser += c[j] / ++y;
  return -t + Math.log(2.5066282746310005 * ser / x);
}
const _lf = [0, 0];
function lnFact(n) { for (let i = _lf.length; i <= n; i++) _lf.push(_lf[i - 1] + Math.log(i)); return _lf[n]; }
// regularised upper incomplete gamma Q(a,x): series for x<a+1, continued fraction otherwise
function gammaQ(a, x) {
  if (!(x > 0)) return 1;
  if (x < a + 1) {
    let ap = a, del = 1 / a, sum = del;
    for (let n = 0; n < 2000; n++) { ap++; del *= x / ap; sum += del; if (Math.abs(del) < Math.abs(sum) * 1e-15) break; }
    return Math.max(0, 1 - sum * Math.exp(-x + a * Math.log(x) - lnGamma(a)));
  }
  const FPMIN = 1e-300; let b = x + 1 - a, c = 1 / FPMIN, d = 1 / b, h = d;
  for (let i = 1; i < 2000; i++) {
    const an = -i * (i - a); b += 2;
    d = an * d + b; if (Math.abs(d) < FPMIN) d = FPMIN;
    c = b + an / c; if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d; const del = d * c; h *= del; if (Math.abs(del - 1) < 1e-15) break;
  }
  return Math.exp(-x + a * Math.log(x) - lnGamma(a)) * h;
}
function chi2sf(x, df) { if (!(df > 0) || !isFinite(x)) return NaN; if (x <= 0) return 1; return gammaQ(df / 2, x / 2); }
// seeded generator (mulberry32) — every stochastic step is reproducible from the seed
function rng(seed) {
  let a = (seed >>> 0) || 1;
  return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
function shuffle(arr, rnd, n) { n = n === undefined ? arr.length : n; for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = arr[i]; arr[i] = arr[j]; arr[j] = t; } return arr; }
function mean(a) { let s = 0, c = 0; for (const v of a) if (v !== null && v !== undefined && isFinite(v)) { s += v; c++; } return c ? s / c : NaN; }
function sd(a) { const x = a.filter(v => v !== null && v !== undefined && isFinite(v)); if (x.length < 2) return NaN; const m = mean(x); return Math.sqrt(x.reduce((s, v) => s + (v - m) * (v - m), 0) / (x.length - 1)); }
function quantile(sorted, q) { if (!sorted.length) return NaN; const h = (sorted.length - 1) * q, lo = Math.floor(h), hi = Math.ceil(h); return sorted[lo] + (sorted[hi] - sorted[lo]) * (h - lo); }

// multiple-testing adjustment; NaN entries are ignored and returned as NaN
function pAdjust(p, method) {
  const idx = []; p.forEach((v, i) => { if (v !== null && isFinite(v)) idx.push(i); });
  const m = idx.length, out = p.map(() => NaN);
  if (!m) return out;
  if (method === 'none') { idx.forEach(i => out[i] = p[i]); return out; }
  if (method === 'bonferroni') { idx.forEach(i => out[i] = Math.min(1, p[i] * m)); return out; }
  let cm = 1; if (method === 'by') { cm = 0; for (let i = 1; i <= m; i++) cm += 1 / i; }
  const o = idx.slice().sort((a, b) => p[b] - p[a]); let run = 1;       // step-up (BH 1995; BY 2001)
  o.forEach((i, r) => { const rank = m - r; run = Math.min(run, p[i] * m * cm / rank); out[i] = Math.min(1, run); });
  return out;
}
function fisherCombine(ps) { const v = ps.filter(x => isFinite(x)); if (!v.length) return { chi2: NaN, df: 0, p: NaN }; const c = -2 * v.reduce((s, x) => s + Math.log(Math.max(x, 1e-300)), 0); return { chi2: c, df: 2 * v.length, p: chi2sf(c, 2 * v.length) }; }

// ───────────────────────── input ─────────────────────────
const MISSING = new Set(['', '0', '00', '000', '000000', '?', 'na', 'nan', 'n/a', '-', '-1', '-9', '-99', '.', 'null', 'missing']);
function cleanAllele(v) {
  if (v === null || v === undefined) return null;
  const s = String(v).trim(); if (MISSING.has(s.toLowerCase())) return null;
  const n = +s.replace(',', '.'); if (!isFinite(n)) return undefined;      // undefined = unreadable
  return n === 0 ? null : n;
}
// minimal RFC-4180 reader with delimiter sniffing (comma, semicolon, tab)
function parseDelimited(text) {
  text = text.replace(/^﻿/, '');
  const first = text.split(/\r?\n/, 1)[0];
  const cnt = d => { let c = 0, q = false; for (const ch of first) { if (ch === '"') q = !q; else if (ch === d && !q) c++; } return c; };
  const cands = [',', ';', '\t']; let delim = ',', best = -1;
  cands.forEach(d => { const c = cnt(d); if (c > best) { best = c; delim = d; } });
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
    else if (ch === '"') q = true;
    else if (ch === delim) { row.push(cur); cur = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; rows.push(row); row = []; }
    else cur += ch;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return { rows: rows.filter(r => r.some(v => String(v).trim() !== '')), delim };
}
const KEY = h => String(h == null ? '' : h).trim().toLowerCase().replace(/[\s_.\-()]/g, '');
const ID_KEYS = ['individual', 'individ', 'indiv', 'ind', 'id', 'sample', 'sampleid', 'samplename', 'name', 'no', 'number', 'code', 'accession'];
const POP_KEYS = ['population', 'populations', 'pop', 'group', 'groups', 'subpopulation', 'subpop', 'popid', 'region', 'location', 'site', 'deme', 'origin', 'breed', 'colony', 'year', 'cohort'];

/* headers: array of strings; rows: array of arrays. Diploid codominant genotypes only. */
function parseGenotypes(headers, rows) {
  let popIdx = null, idIdx = null;
  headers.forEach((h, i) => { const k = KEY(h); if (popIdx == null && POP_KEYS.includes(k)) popIdx = i; if (idIdx == null && ID_KEYS.includes(k)) idIdx = i; });
  const dataIdx = headers.map((h, i) => i).filter(i => i !== popIdx && i !== idIdx && headers[i] != null && String(headers[i]).trim() !== '');
  const sep = /[\/:|]/;
  const combinedCols = dataIdx.filter(i => { let hit = 0, tot = 0; for (const r of rows) { const v = r[i]; if (v == null || v === '') continue; tot++; if (sep.test(String(v))) hit++; } return tot > 0 && hit / tot >= 0.5; });
  const combined = dataIdx.length > 0 && combinedCols.length >= dataIdx.length * 0.5;
  const records = rows.map((r, idx) => ({
    id: idIdx != null && r[idIdx] != null && String(r[idIdx]).trim() !== '' ? String(r[idIdx]).trim() : 'Ind_' + (idx + 1),
    pop: popIdx != null ? (String(r[popIdx] == null ? '' : r[popIdx]).trim() || 'Unknown') : 'All', geno: {} }));
  const lociNames = [], warn = { partial: 0, unreadable: 0, polyploid: 0 };
  const put = (idx, name, x, y) => {
    let a = cleanAllele(x), b = cleanAllele(y);
    if (a === undefined || b === undefined) { warn.unreadable++; a = b = null; }
    if ((a === null) !== (b === null)) { warn.partial++; a = b = null; }   // half-scored genotype = missing genotype
    records[idx].geno[name] = [a, b];
  };
  if (combined) {
    dataIdx.forEach((i, li) => {
      const name = String(headers[i]).trim() || ('Locus' + (li + 1)); lociNames.push(name);
      rows.forEach((r, idx) => {
        const raw = r[i]; if (raw == null || String(raw).trim() === '') { records[idx].geno[name] = [null, null]; return; }
        const p = String(raw).split(sep).map(s => s.trim()).filter(s => s !== '');
        if (p.length > 2) { warn.polyploid++; records[idx].geno[name] = [null, null]; return; }
        put(idx, name, p[0], p.length > 1 ? p[1] : p[0]);
      });
    });
  } else {
    const parsed = dataIdx.map(i => { const s = String(headers[i]).trim(); let m, base = s;
      if ((m = s.match(/^(.*?)[\s._-]*\((\d+|[abAB])\)\s*$/))) base = m[1];
      else if ((m = s.match(/^(.*?)[\s._-]+(\d+|[abAB])$/))) base = m[1];
      return { i, base: base.replace(/[\s._-]+$/, '').trim() }; });
    const groups = []; parsed.forEach(p => { const last = groups[groups.length - 1]; if (last && last.base === p.base && last.idxs.length < 2) last.idxs.push(p.i); else groups.push({ base: p.base, idxs: [p.i] }); });
    let pairs = groups.filter(g => g.idxs.length === 2).map((g, k) => ({ name: g.base || ('Locus' + (k + 1)), c1: g.idxs[0], c2: g.idxs[1] }));
    if (!(pairs.length && pairs.length * 2 >= dataIdx.length * 0.7)) {
      pairs = []; for (let i = 0; i + 1 < dataIdx.length; i += 2) pairs.push({ name: parsed[i].base || ('Locus' + (i / 2 + 1)), c1: dataIdx[i], c2: dataIdx[i + 1] });
    }
    const seen = {};
    pairs.forEach((lp, li) => { let name = lp.name || ('Locus' + (li + 1)); if (seen[name]) name += '_' + (li + 1); seen[name] = 1; lociNames.push(name); rows.forEach((r, idx) => put(idx, name, r[lp.c1], r[lp.c2])); });
  }
  return { records, lociNames, hasPop: popIdx != null, popName: popIdx != null ? String(headers[popIdx]) : null, idName: idIdx != null ? String(headers[idIdx]) : null, combined, warn };
}

/* integer-encode a (possibly subsetted) data set */
function encode(records, lociNames, opt) {
  opt = opt || {};
  const keepPop = opt.pops ? new Set(opt.pops) : null, keepLoc = opt.loci ? new Set(opt.loci) : null;
  const recs = records.filter(r => !keepPop || keepPop.has(r.pop));
  const popNames = []; recs.forEach(r => { if (!popNames.includes(r.pop)) popNames.push(r.pop); });
  const n = recs.length, pop = new Int32Array(n); recs.forEach((r, i) => pop[i] = popNames.indexOf(r.pop));
  const names = [], alleles = [], A = [], B = [];
  lociNames.filter(l => !keepLoc || keepLoc.has(l)).forEach(l => {
    const set = new Set(); recs.forEach(r => { const g = r.geno[l]; if (g && g[0] !== null) { set.add(g[0]); set.add(g[1]); } });
    if (!set.size) return;
    const al = [...set].sort((x, y) => x - y), ix = new Map(al.map((v, i) => [v, i]));
    const a = new Int16Array(n).fill(-1), b = new Int16Array(n).fill(-1);
    recs.forEach((r, i) => { const g = r.geno[l]; if (g && g[0] !== null) { a[i] = ix.get(g[0]); b[i] = ix.get(g[1]); } });
    names.push(l); alleles.push(al); A.push(a); B.push(b);
  });
  const popIdx = popNames.map(() => []); for (let i = 0; i < n; i++) popIdx[pop[i]].push(i);
  return { n, L: names.length, K: popNames.length, popNames, loci: names, alleles, A, B, pop, popIdx, ids: recs.map(r => r.id) };
}

// ───────────────────────── counting ─────────────────────────
/* group-wise counts at one locus. grp[i] in 0..G-1, or -1 to skip the individual */
function counts(D, l, grp, G) {
  const k = D.alleles[l].length, a = D.A[l], b = D.B[l];
  const n = new Float64Array(G), H = new Float64Array(G), cnt = new Float64Array(G * k), het = new Float64Array(G * k);
  for (let i = 0; i < D.n; i++) {
    const g = grp[i]; if (g < 0) continue; const x = a[i]; if (x < 0) continue; const y = b[i];
    n[g]++; cnt[g * k + x]++; cnt[g * k + y]++;
    if (x !== y) { H[g]++; het[g * k + x]++; het[g * k + y]++; }
  }
  return { k, n, H, cnt, het };
}

// ───────────────────────── single-sample diversity ─────────────────────────
/* c: allele counts (length k), n typed individuals, H heterozygous individuals */
function diversity(c, n, H) {
  if (!n) return { N: 0, Na: 0, Ne: NaN, I: NaN, Ho: NaN, He: NaN, uHe: NaN, PIC: NaN, F: NaN };
  const tot = 2 * n; let s2 = 0, I = 0, Na = 0; const p = [];
  for (let i = 0; i < c.length; i++) if (c[i] > 0) { const f = c[i] / tot; p.push(f); s2 += f * f; I -= f * Math.log(f); Na++; }
  let s4 = 0; for (const f of p) s4 += f * f * f * f;
  const He = 1 - s2, uHe = n > 0.5 ? (tot / (tot - 1)) * He : NaN, Ho = H / n;
  const PIC = 1 - s2 - (s2 * s2 - s4);                       // Botstein et al. 1980: 1 − Σp² − ΣΣ 2p_i²p_j²
  return { N: n, Na, Ne: 1 / s2, I, Ho, He, uHe, PIC, F: He > 0 ? 1 - Ho / He : NaN };
}
/* rarefied allelic richness for g gene copies (Hurlbert 1971; El Mousadik & Petit 1996) */
function richness(c, g) {
  let N = 0; for (const v of c) N += v; if (N < g || g < 1) return NaN;
  const lc = (n, k) => k > n ? -Infinity : lnFact(n) - lnFact(k) - lnFact(n - k), den = lc(N, g); let ar = 0;
  for (const v of c) if (v > 0) { const x = lc(N - v, g); ar += 1 - (x === -Infinity ? 0 : Math.exp(x - den)); }
  return ar;
}
// Brookfield (1996) estimator 1, from unbiased He
function nullFreq(Ho, uHe) { return isFinite(Ho) && uHe > 0 ? (uHe - Ho) / (1 + uHe) : NaN; }

// ───────────────────────── F-statistics, per locus ─────────────────────────
/* Nei (1987) estimators with the Nei & Chesser (1983) sample-size correction — the definitions
   implemented in hierfstat::basic.stats. Populations without data at the locus are dropped. */
function neiLocus(C) {
  const { k, n, H, cnt } = C, G = n.length; let np = 0, sInv = 0, mHo = 0, msp2 = 0; const mp = new Float64Array(k);
  for (let g = 0; g < G; g++) { if (!n[g]) continue; np++; sInv += 1 / n[g]; mHo += H[g] / n[g]; let s = 0; for (let a = 0; a < k; a++) { const p = cnt[g * k + a] / (2 * n[g]); s += p * p; mp[a] += p; } msp2 += s; }
  if (!np) return null;
  mHo /= np; msp2 /= np; const mn = np / sInv; let mp2 = 0; for (let a = 0; a < k; a++) { mp[a] /= np; mp2 += mp[a] * mp[a]; }
  const Hs = mn > 1 ? mn / (mn - 1) * (1 - msp2 - mHo / (2 * mn)) : NaN;
  const Ht = 1 - mp2 + Hs / (mn * np) - mHo / (2 * mn * np);
  const Dst = Ht - Hs, Dstp = np > 1 ? np / (np - 1) * Dst : NaN, Htp = Hs + Dstp;
  return { np, Ho: mHo, Hs, Ht, Dst, Dstp, Htp };
}
/* ratios from (single-locus or locus-averaged) components */
function neiRatios(c) {
  const { np, Ho, Hs, Ht, Dst, Dstp, Htp } = c, multi = np > 1, r = (x, y) => (y > 1e-12 ? x / y : NaN);
  const Gst = multi ? r(Dst, Ht) : NaN;
  return { HoS: Ho, Hs, Ht, Fis: 1 - r(Ho, Hs), Fit: multi ? 1 - r(Ho, Ht) : NaN, Gst,
    GstP: multi ? r(Dstp, Htp) : NaN,                                             // Nei 1987, corrected for number of populations
    GstH: multi ? Gst * (np - 1 + Hs) / ((np - 1) * (1 - Hs)) : NaN,              // Hedrick 2005 G'ST
    Gst2: multi ? r(np * (Ht - Hs), (np * Ht - Hs) * (1 - Hs)) : NaN,             // Meirmans & Hedrick 2011 G''ST
    D: multi ? r(Dstp, 1 - Hs) : NaN };                                           // Jost 2008 D_est
}
/* Weir & Cockerham (1984) variance components, summed over alleles */
function wcLocus(C) {
  const { k, n, cnt, het } = C, G = n.length; let r = 0, sn = 0, sn2 = 0;
  for (let g = 0; g < G; g++) if (n[g]) { r++; sn += n[g]; sn2 += n[g] * n[g]; }
  if (r < 2) return null; const nb = sn / r; if (nb <= 1) return null; const nc = (sn - sn2 / sn) / (r - 1);
  let A = 0, Bc = 0, Cc = 0;
  for (let a = 0; a < k; a++) {
    let pb = 0, hb = 0; for (let g = 0; g < G; g++) if (n[g]) { pb += cnt[g * k + a] / 2; hb += het[g * k + a]; }
    pb /= sn; hb /= sn; if (pb === 0) continue;
    let s2 = 0; for (let g = 0; g < G; g++) if (n[g]) { const d = cnt[g * k + a] / (2 * n[g]) - pb; s2 += n[g] * d * d; } s2 /= (r - 1) * nb;
    const q = pb * (1 - pb) - (r - 1) / r * s2;
    A += nb / nc * (s2 - (q - hb / 4) / (nb - 1));
    Bc += nb / (nb - 1) * (q - (2 * nb - 1) / (4 * nb) * hb);
    Cc += hb / 2;
  }
  return { a: A, b: Bc, c: Cc };
}
function wcRatios(a, b, c) { const t = a + b + c; return { theta: t > 1e-12 ? a / t : NaN, capF: t > 1e-12 ? 1 - c / t : NaN, f: (b + c) > 1e-12 ? 1 - c / (b + c) : NaN }; }

/* all per-locus components for an arbitrary grouping, plus multilocus summaries */
function fstats(D, grp, G) {
  const per = [];
  for (let l = 0; l < D.L; l++) { const C = counts(D, l, grp, G); per.push({ nei: neiLocus(C), wc: wcLocus(C) }); }
  return { per, multi: fMulti(per) };
}
function fMulti(per, idx) {
  let a = 0, b = 0, c = 0, m = 0; const acc = { Ho: 0, Hs: 0, Ht: 0, Dst: 0, Dstp: 0, Htp: 0 }; let np = 0;
  const it = idx || per.map((_, i) => i);
  for (const i of it) { const p = per[i]; if (p.wc) { a += p.wc.a; b += p.wc.b; c += p.wc.c; }
    if (p.nei && isFinite(p.nei.Hs) && isFinite(p.nei.Ht)) { m++; np = Math.max(np, p.nei.np); for (const k in acc) acc[k] += isFinite(p.nei[k]) ? p.nei[k] : 0; } }
  if (!m) return null; for (const k in acc) acc[k] /= m;
  return Object.assign({ nLoci: m }, neiRatios(Object.assign({ np }, acc)), wcRatios(a, b, c));
}
/* percentile bootstrap over loci (Weir & Cockerham 1984; as in FSTAT / hierfstat::boot.vc) */
function bootLoci(per, B, rnd, keys) {
  const L = per.length, out = {}; keys.forEach(k => out[k] = []);
  const idx = new Array(L);
  for (let b = 0; b < B; b++) { for (let i = 0; i < L; i++) idx[i] = Math.floor(rnd() * L); const m = fMulti(per, idx); if (m) keys.forEach(k => { if (isFinite(m[k])) out[k].push(m[k]); }); }
  const ci = {}; keys.forEach(k => { const s = out[k].sort((x, y) => x - y); ci[k] = s.length > 10 ? [quantile(s, 0.025), quantile(s, 0.975)] : [NaN, NaN]; });
  return ci;
}
/* fast multilocus theta for permutation tests */
function thetaOnly(D, grp, G) {
  let a = 0, t = 0;
  for (let l = 0; l < D.L; l++) { const w = wcLocus(counts(D, l, grp, G)); if (w) { a += w.a; t += w.a + w.b + w.c; } }
  return t > 1e-12 ? a / t : NaN;
}
/* permutation of whole multilocus genotypes among the G groups; one-sided p for theta */
function permTheta(D, grp, G, B, rnd) {
  const obs = thetaOnly(D, grp, G); if (!isFinite(obs)) return { theta: obs, p: NaN };
  const who = []; for (let i = 0; i < D.n; i++) if (grp[i] >= 0) who.push(i);
  const lab = who.map(i => grp[i]), g2 = new Int32Array(D.n).fill(-1); let ge = 0;
  for (let b = 0; b < B; b++) { shuffle(lab, rnd); for (let j = 0; j < who.length; j++) g2[who[j]] = lab[j]; const t = thetaOnly(D, g2, G); if (t >= obs - 1e-12) ge++; }
  return { theta: obs, p: (ge + 1) / (B + 1) };
}

// ───────────────────────── Hardy–Weinberg ─────────────────────────
/* One locus, one sample. Returns the full genotype-class chi-square (df = k(k−1)/2) and a Monte Carlo
   exact test (Guo & Thompson 1992): alleles are permuted among individuals and the p value is the
   share of permuted samples whose conditional probability does not exceed that of the observed one. */
function hwe(a, b, idx, kAll, B, rnd) {
  const al = [], map = new Int32Array(kAll).fill(-1); let k = 0, n = 0, H = 0;
  for (const i of idx) { const x = a[i]; if (x < 0) continue; const y = b[i]; if (map[x] < 0) map[x] = k++; if (map[y] < 0) map[y] = k++; al.push(map[x], map[y]); n++; if (x !== y) H++; }
  const res = { n, k, Ho: n ? H / n : NaN, uHe: NaN, Fis: NaN, chi2: NaN, df: NaN, pChi: NaN, pExact: NaN, minExp: NaN };
  if (n < 2) return res;
  const c = new Float64Array(k); for (const v of al) c[v]++; let s2 = 0; for (let i = 0; i < k; i++) s2 += (c[i] / (2 * n)) ** 2;
  res.uHe = 2 * n / (2 * n - 1) * (1 - s2); res.Fis = res.uHe > 0 ? 1 - res.Ho / res.uHe : NaN;
  if (k < 2 || n < 5) return res;
  let cmax = 0; for (let i = 0; i < k; i++) if (c[i] > cmax) cmax = c[i];
  if (2 * n - cmax < 2) return res;                      // a single copy of the only minor allele: one possible sample, no information
  const g = new Float64Array(k * k); for (let i = 0; i < al.length; i += 2) { const x = Math.min(al[i], al[i + 1]), y = Math.max(al[i], al[i + 1]); g[x * k + y]++; }
  let chi = 0, minE = Infinity;
  for (let i = 0; i < k; i++) for (let j = i; j < k; j++) { const e = (i === j ? 1 : 2) * c[i] * c[j] / (4 * n); const o = g[i * k + j]; chi += (o - e) * (o - e) / e; if (e < minE) minE = e; }
  res.chi2 = chi; res.df = k * (k - 1) / 2; res.pChi = chi2sf(chi, res.df); res.minExp = minE;
  if (B > 0) {
    const stat = () => { let s = 0; for (let i = 0; i < k; i++) for (let j = i; j < k; j++) { const o = g[i * k + j]; if (o) { s -= lnFact(o); if (i !== j) s += o * Math.LN2; } } return s; };
    const obs = stat(); let le = 0; const arr = Int32Array.from(al);
    for (let r = 0; r < B; r++) { shuffle(arr, rnd); g.fill(0); for (let i = 0; i < arr.length; i += 2) { const x = arr[i], y = arr[i + 1]; if (x < y) g[x * k + y]++; else g[y * k + x]++; } if (stat() <= obs + 1e-9) le++; }
    res.pExact = (le + 1) / (B + 1);
  }
  return res;
}
/* every locus × population, and every locus on the pooled sample */
function hweAll(D, B, rnd) {
  const all = [...Array(D.n).keys()], byPop = [], pooled = [];
  for (let l = 0; l < D.L; l++) { const k = D.alleles[l].length; byPop.push(D.popIdx.map(ix => hwe(D.A[l], D.B[l], ix, k, B, rnd))); pooled.push(hwe(D.A[l], D.B[l], all, k, B, rnd)); }
  return { byPop, pooled };
}

// ───────────────────────── genotypic linkage disequilibrium ─────────────────────────
/* Log-likelihood-ratio (G) test on the genotype × genotype contingency table of two loci within one
   population; null distribution by permuting the genotypes of the second locus among individuals
   (the test of Genepop option 2, evaluated by Monte Carlo instead of a Markov chain).
   Populations are combined with Fisher's method. */
function ldAll(D, B, rnd, progress) {
  const L = D.L, K = D.K, code = [];
  for (let l = 0; l < L; l++) { const k = D.alleles[l].length, c = new Int32Array(D.n); for (let i = 0; i < D.n; i++) { const x = D.A[l][i], y = D.B[l][i]; c[i] = x < 0 ? -1 : (x < y ? x * k + y : y * k + x); } code.push(c); }
  const xlx = v => v > 0 ? v * Math.log(v) : 0, out = [];
  for (let i = 0; i < L; i++) { for (let j = i + 1; j < L; j++) {
    const ps = [];
    for (let p = 0; p < K; p++) {
      const ra = [], rb = [], ma = new Map(), mb = new Map();
      for (const ind of D.popIdx[p]) { const x = code[i][ind], y = code[j][ind]; if (x < 0 || y < 0) continue; if (!ma.has(x)) ma.set(x, ma.size); if (!mb.has(y)) mb.set(y, mb.size); ra.push(ma.get(x)); rb.push(mb.get(y)); }
      const n = ra.length, R = ma.size, Cn = mb.size; if (n < 5 || R < 2 || Cn < 2) { ps.push(NaN); continue; }
      const cell = new Int32Array(R * Cn), sum = arr => { cell.fill(0); for (let t = 0; t < n; t++) cell[ra[t] * Cn + arr[t]]++; let s = 0; for (let t = 0; t < cell.length; t++) s += xlx(cell[t]); return s; };
      const obs = sum(rb); let ge = 0; const perm = rb.slice();
      for (let r = 0; r < B; r++) { shuffle(perm, rnd); if (sum(perm) >= obs - 1e-9) ge++; }
      ps.push((ge + 1) / (B + 1));
    }
    const f = fisherCombine(ps);
    out.push({ i, j, byPop: ps, nPop: f.df / 2, chi2: f.chi2, df: f.df, p: f.p });
  } if (progress) progress((i + 1) / L); }
  return out;
}

// ───────────────────────── PCA, k-means, DAPC ─────────────────────────
/* cyclic Jacobi eigen-decomposition of a symmetric n×n matrix stored row-major (overwritten) */
function eigSym(A, n) {
  const V = new Float64Array(n * n); for (let i = 0; i < n; i++) V[i * n + i] = 1;
  let diag = 0; for (let i = 0; i < n; i++) diag += A[i * n + i] * A[i * n + i];
  for (let sweep = 0; sweep < 100; sweep++) {
    let off = 0; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) off += A[i * n + j] * A[i * n + j];
    if (off <= 1e-24 * (diag + off) || off === 0) break;
    for (let p = 0; p < n - 1; p++) for (let q = p + 1; q < n; q++) {
      const apq = A[p * n + q]; if (Math.abs(apq) < 1e-300) continue;
      const th = (A[q * n + q] - A[p * n + p]) / (2 * apq), t = (th >= 0 ? 1 : -1) / (Math.abs(th) + Math.sqrt(th * th + 1)), c = 1 / Math.sqrt(t * t + 1), s = t * c;
      A[p * n + p] -= t * apq; A[q * n + q] += t * apq; A[p * n + q] = 0; A[q * n + p] = 0;
      for (let r = 0; r < n; r++) { if (r !== p && r !== q) { const arp = A[r * n + p], arq = A[r * n + q]; const x = c * arp - s * arq, y = s * arp + c * arq; A[r * n + p] = x; A[p * n + r] = x; A[r * n + q] = y; A[q * n + r] = y; }
        const vrp = V[r * n + p], vrq = V[r * n + q]; V[r * n + p] = c * vrp - s * vrq; V[r * n + q] = s * vrp + c * vrq; }
    }
  }
  const ord = [...Array(n).keys()].sort((x, y) => A[y * n + y] - A[x * n + x]);
  return { vals: ord.map(i => A[i * n + i]), vec: j => { const o = ord[j], v = new Float64Array(n); for (let r = 0; r < n; r++) v[r] = V[r * n + o]; return v; } };
}
/* PCA of individual allele frequencies (0, 0.5, 1), centred, unscaled; missing genotypes take the
   allele's mean over all typed individuals — the convention of adegenet (Jombart 2008). */
function pca(D, maxComp) {
  const n = D.n, cols = []; for (let l = 0; l < D.L; l++) if (D.alleles[l].length > 1) for (let a = 0; a < D.alleles[l].length; a++) cols.push([l, a]);
  const m = cols.length; if (n < 3 || m < 2) return null;
  const X = new Float64Array(n * m);
  cols.forEach(([l, a], j) => { let s = 0, c = 0; const A = D.A[l], Bq = D.B[l];
    for (let i = 0; i < n; i++) { if (A[i] < 0) { X[i * m + j] = NaN; continue; } const v = ((A[i] === a) + (Bq[i] === a)) / 2; X[i * m + j] = v; s += v; c++; }
    const mu = c ? s / c : 0; for (let i = 0; i < n; i++) X[i * m + j] = isNaN(X[i * m + j]) ? 0 : X[i * m + j] - mu; });
  const dual = n < m, d = dual ? n : m, S = new Float64Array(d * d);
  if (dual) { for (let i = 0; i < n; i++) for (let k = i; k < n; k++) { let s = 0; const oi = i * m, ok = k * m; for (let j = 0; j < m; j++) s += X[oi + j] * X[ok + j]; S[i * d + k] = S[k * d + i] = s / n; } }
  else { for (let i = 0; i < n; i++) { const o = i * m; for (let a = 0; a < m; a++) { const xa = X[o + a]; if (xa === 0) continue; for (let b = a; b < m; b++) S[a * d + b] += xa * X[o + b]; } } for (let a = 0; a < m; a++) for (let b = a; b < m; b++) { S[a * d + b] /= n; S[b * d + a] = S[a * d + b]; } }
  let tot = 0; for (let i = 0; i < d; i++) tot += S[i * d + i];
  const e = eigSym(S, d), vals = e.vals.filter(v => v > tot * 1e-10), k = Math.min(maxComp || 80, vals.length);
  const scores = Array.from({ length: n }, () => new Float64Array(k));
  for (let c = 0; c < k; c++) { const v = e.vec(c); let big = 0, sg = 1;
    if (dual) { const sc = Math.sqrt(n * vals[c]); for (let i = 0; i < n; i++) scores[i][c] = v[i] * sc; }
    else for (let i = 0; i < n; i++) { let s = 0; const o = i * m; for (let j = 0; j < m; j++) s += X[o + j] * v[j]; scores[i][c] = s; }
    for (let i = 0; i < n; i++) if (Math.abs(scores[i][c]) > big) { big = Math.abs(scores[i][c]); sg = Math.sign(scores[i][c]) || 1; }
    if (sg < 0) for (let i = 0; i < n; i++) scores[i][c] = -scores[i][c]; }
  const varExp = vals.map(v => 100 * v / tot); let cum = 0; const cumVar = varExp.map(v => (cum += v));
  return { scores, eig: vals, varExp, cumVar, nFeatures: m, total: tot };
}
function dist2(a, b, d) { let s = 0; for (let i = 0; i < d; i++) { const x = a[i] - b[i]; s += x * x; } return s; }
/* k-means (Lloyd) with k-means++ seeding and restarts; lowest within-cluster sum of squares wins */
function kmeans(scores, d, K, restarts, rnd, maxIter) {
  const n = scores.length; let best = null;
  for (let r = 0; r < restarts; r++) {
    const cents = [Float64Array.from(scores[Math.floor(rnd() * n)].subarray(0, d))], dmin = new Float64Array(n).fill(Infinity);
    while (cents.length < K) { let sum = 0; const c = cents[cents.length - 1]; for (let i = 0; i < n; i++) { const v = dist2(scores[i], c, d); if (v < dmin[i]) dmin[i] = v; sum += dmin[i]; }
      let u = rnd() * sum, idx = n - 1; for (let i = 0; i < n; i++) { u -= dmin[i]; if (u <= 0) { idx = i; break; } } cents.push(Float64Array.from(scores[idx].subarray(0, d))); }
    const assign = new Int32Array(n).fill(-1); let it = 0, conv = false;
    for (; it < (maxIter || 200); it++) {
      let changed = false; for (let i = 0; i < n; i++) { let bi = 0, bd = Infinity; for (let k = 0; k < K; k++) { const v = dist2(scores[i], cents[k], d); if (v < bd) { bd = v; bi = k; } } if (assign[i] !== bi) { assign[i] = bi; changed = true; } }
      if (!changed) { conv = true; break; }
      const cnt = new Float64Array(K), sum = Array.from({ length: K }, () => new Float64Array(d));
      for (let i = 0; i < n; i++) { cnt[assign[i]]++; for (let j = 0; j < d; j++) sum[assign[i]][j] += scores[i][j]; }
      for (let k = 0; k < K; k++) if (cnt[k]) for (let j = 0; j < d; j++) cents[k][j] = sum[k][j] / cnt[k];
    }
    let wss = 0; for (let i = 0; i < n; i++) wss += dist2(scores[i], cents[assign[i]], d);
    if (!best || wss < best.wss - 1e-12) best = { assign, cents, wss, iters: it, converged: conv };
  }
  best.bic = n * Math.log(best.wss / n) + K * Math.log(n);       // as adegenet::find.clusters
  return best;
}
/* DAPC (Jombart et al. 2010): linear discriminant analysis of the first d principal components.
   Discriminant axes are scaled to unit within-group variance (as MASS::lda); posterior membership
   probabilities use prior = group proportions and all discriminant functions. */
function dapc(scores, d, grp, G) {
  const n = scores.length, cnt = new Float64Array(G), mu = Array.from({ length: G }, () => new Float64Array(d)), gm = new Float64Array(d);
  for (let i = 0; i < n; i++) { cnt[grp[i]]++; for (let j = 0; j < d; j++) { mu[grp[i]][j] += scores[i][j]; gm[j] += scores[i][j] / n; } }
  for (let g = 0; g < G; g++) { if (!cnt[g]) return null; for (let j = 0; j < d; j++) mu[g][j] /= cnt[g]; }
  if (G < 2 || n - G < d) return null;
  const W = new Float64Array(d * d), Bm = new Float64Array(d * d);
  for (let i = 0; i < n; i++) { const m = mu[grp[i]]; for (let a = 0; a < d; a++) { const xa = scores[i][a] - m[a]; for (let b = a; b < d; b++) W[a * d + b] += xa * (scores[i][b] - m[b]); } }
  for (let a = 0; a < d; a++) for (let b = a; b < d; b++) { W[a * d + b] /= (n - G); W[b * d + a] = W[a * d + b]; let s = 0; for (let g = 0; g < G; g++) s += cnt[g] * (mu[g][a] - gm[a]) * (mu[g][b] - gm[b]); Bm[a * d + b] = Bm[b * d + a] = s / (G - 1); }
  const Lc = new Float64Array(d * d);                                             // Cholesky W = L Lᵀ
  for (let i = 0; i < d; i++) for (let j = 0; j <= i; j++) { let s = W[i * d + j]; for (let k = 0; k < j; k++) s -= Lc[i * d + k] * Lc[j * d + k]; if (i === j) { if (s <= 1e-14) return null; Lc[i * d + i] = Math.sqrt(s); } else Lc[i * d + j] = s / Lc[j * d + j]; }
  const fwd = v => { const z = new Float64Array(d); for (let i = 0; i < d; i++) { let s = v[i]; for (let k = 0; k < i; k++) s -= Lc[i * d + k] * z[k]; z[i] = s / Lc[i * d + i]; } return z; };
  const bwd = v => { const z = new Float64Array(d); for (let i = d - 1; i >= 0; i--) { let s = v[i]; for (let k = i + 1; k < d; k++) s -= Lc[k * d + i] * z[k]; z[i] = s / Lc[i * d + i]; } return z; };
  const T = new Float64Array(d * d);                                              // L⁻¹ B L⁻ᵀ
  const cols = []; for (let b = 0; b < d; b++) { const col = new Float64Array(d); for (let a = 0; a < d; a++) col[a] = Bm[a * d + b]; cols.push(fwd(col)); }
  for (let a = 0; a < d; a++) { const row = new Float64Array(d); for (let b = 0; b < d; b++) row[b] = cols[b][a]; const z = fwd(row); for (let b = 0; b < d; b++) T[a * d + b] = z[b]; }
  for (let a = 0; a < d; a++) for (let b = a + 1; b < d; b++) { const v = (T[a * d + b] + T[b * d + a]) / 2; T[a * d + b] = T[b * d + a] = v; }
  const e = eigSym(T, d), nd = Math.min(G - 1, d), axes = [], evs = e.vals.slice(0, nd).map(v => Math.max(0, v));
  for (let c = 0; c < nd; c++) axes.push(bwd(e.vec(c)));
  const coords = scores.map(x => { const o = new Float64Array(nd); for (let c = 0; c < nd; c++) { let s = 0; for (let j = 0; j < d; j++) s += (x[j] - gm[j]) * axes[c][j]; o[c] = s; } return o; });
  for (let c = 0; c < nd; c++) { let big = 0, sg = 1; for (let i = 0; i < n; i++) if (Math.abs(coords[i][c]) > big) { big = Math.abs(coords[i][c]); sg = Math.sign(coords[i][c]) || 1; } if (sg < 0) for (let i = 0; i < n; i++) coords[i][c] = -coords[i][c]; }
  const post = [], assign = new Int32Array(n); let ok = 0; const diff = new Float64Array(d);
  for (let i = 0; i < n; i++) { const lp = new Float64Array(G); let mx = -Infinity;
    for (let g = 0; g < G; g++) { for (let j = 0; j < d; j++) diff[j] = scores[i][j] - mu[g][j]; const z = fwd(diff); let q = 0; for (let j = 0; j < d; j++) q += z[j] * z[j]; lp[g] = Math.log(cnt[g] / n) - q / 2; if (lp[g] > mx) mx = lp[g]; }
    let s = 0; for (let g = 0; g < G; g++) { lp[g] = Math.exp(lp[g] - mx); s += lp[g]; } let bg = 0; for (let g = 0; g < G; g++) { lp[g] /= s; if (lp[g] > lp[bg]) bg = g; }
    post.push(lp); assign[i] = bg; if (bg === grp[i]) ok++; }
  const sumEv = evs.reduce((a, b) => a + b, 0) || 1;
  return { nPC: d, nDA: nd, coords, eig: evs, daVar: evs.map(v => 100 * v / sumEv), posterior: post, assign, assignProp: ok / n };
}
/* k-means restarts: 50 up to 500 individuals, then 25 000/n, never fewer than 10 */
function defaultRestarts(n) { return Math.max(10, Math.min(50, Math.floor(25000 / n))); }
/* default number of PCs for clustering/DAPC: enough for 80 % of the variance, never more than n/3 */
function defaultNPC(P, n, G) { let d = P.cumVar.findIndex(v => v >= 80) + 1; if (d < 1) d = P.eig.length; return Math.max(2, Math.min(d, Math.floor(n / 3), P.scores[0].length, n - (G || 2) - 1)); }

// ───────────────────────── descriptive pipeline ─────────────────────────
function describe(D) {
  const L = D.L, K = D.K, one = new Int32Array(D.n), locus = [], perPop = [], cells = [];
  let g = Infinity; const store = [];
  for (let l = 0; l < L; l++) { const Cp = counts(D, l, D.pop, K), Ct = counts(D, l, one, 1); store.push([Cp, Ct]); for (let p = 0; p < K; p++) if (Cp.n[p] > 0 && 2 * Cp.n[p] < g) g = 2 * Cp.n[p]; }
  if (!isFinite(g)) g = 0;
  for (let l = 0; l < L; l++) {
    const [Cp, Ct] = store[l], k = Cp.k, d = diversity(Ct.cnt, Ct.n[0], Ct.H[0]);
    const nei = neiLocus(Cp), wc = wcLocus(Cp), row = [];
    for (let p = 0; p < K; p++) { const c = Cp.cnt.subarray(p * k, (p + 1) * k), dv = diversity(c, Cp.n[p], Cp.H[p]); dv.Ar = g >= 2 ? richness(c, g) : NaN; dv.Fis = dv.uHe > 0 ? 1 - dv.Ho / dv.uHe : NaN; dv.nullF = nullFreq(dv.Ho, dv.uHe);
      let priv = 0; for (let a = 0; a < k; a++) if (c[a] > 0) { let other = 0; for (let q = 0; q < K; q++) if (q !== p) other += Cp.cnt[q * k + a]; if (!other) priv++; } dv.priv = priv; row.push(dv); }
    cells.push(row);
    locus.push(Object.assign({ locus: D.loci[l], nullF: nullFreq(d.Ho, d.uHe), Ar: g >= 2 ? mean(row.map(r => r.Ar)) : NaN, nei, wc }, d,
      nei ? neiRatios(nei) : {}, wc ? wcRatios(wc.a, wc.b, wc.c) : {}));
  }
  for (let p = 0; p < K; p++) { const c = cells.map(r => r[p]).filter(r => r.N > 0), sHo = mean(c.map(r => r.Ho)), sU = mean(c.map(r => r.uHe));
    let miss = 0; for (let l = 0; l < L; l++) miss += D.popIdx[p].length - cells[l][p].N;
    perPop.push({ pop: D.popNames[p], N: D.popIdx[p].length, nTyped: mean(cells.map(r => r[p].N)), missing: L ? miss / (L * D.popIdx[p].length) : NaN, Na: mean(c.map(r => r.Na)), Ne: mean(c.map(r => r.Ne)), Ar: mean(c.map(r => r.Ar)), I: mean(c.map(r => r.I)),
      Ho: sHo, He: mean(c.map(r => r.He)), uHe: sU, Fis: sU > 0 ? 1 - sHo / sU : NaN, priv: K > 1 ? c.reduce((s, r) => s + r.priv, 0) : NaN }); }
  const per = locus.map(l => ({ nei: l.nei, wc: l.wc }));
  let typed = 0; cells.forEach(r => r.forEach(c => typed += c.N));
  return { locus, cells, perPop, per, multi: K > 1 ? fMulti(per) : fMulti(per), rareG: g, missing: D.n && L ? 1 - typed / (D.n * L) : NaN };
}
/* pairwise differentiation: estimates, loci-bootstrap CI and permutation p value for theta */
function pairwise(D, opt, progress) {
  const K = D.K, out = [], rnd = opt.rnd; let done = 0; const tot = K * (K - 1) / 2;
  for (let i = 0; i < K; i++) for (let j = i + 1; j < K; j++) {
    const grp = new Int32Array(D.n).fill(-1); D.popIdx[i].forEach(x => grp[x] = 0); D.popIdx[j].forEach(x => grp[x] = 1);
    const fs = fstats(D, grp, 2), m = fs.multi || {};
    const ci = opt.boot > 0 && D.L >= 2 ? bootLoci(fs.per, opt.boot, rnd, ['theta', 'Gst', 'Gst2', 'D']) : {};
    const pt = opt.perm > 0 ? permTheta(D, grp, 2, opt.perm, rnd) : { p: NaN };
    out.push({ i, j, theta: m.theta, Gst: m.Gst, GstP: m.GstP, GstH: m.GstH, Gst2: m.Gst2, D: m.D, ci, p: pt.p });
    if (progress) progress(++done / tot);
  }
  return out;
}

// ───────────────────────── interoperability ─────────────────────────
function toGenepop(D, title) {
  const big = D.alleles.some(al => al.some(v => v > 999 || v < 1 || v !== Math.floor(v)));
  const code = (l, x) => x < 0 ? '000' : String(big ? x + 1 : D.alleles[l][x]).padStart(3, '0');
  const lines = [title || 'MicroQuick export', ...D.loci.map(n => n.replace(/[,\s]+/g, '_'))];
  for (let p = 0; p < D.K; p++) { lines.push('Pop'); for (const i of D.popIdx[p]) lines.push(`${D.popNames[p].replace(/[,\s]+/g, '_')}_${D.ids[i].replace(/[,\s]+/g, '_')} , ` + D.loci.map((_, l) => code(l, D.A[l][i]) + code(l, D.B[l][i])).join(' ')); }
  return lines.join('\n') + '\n';
}
function toStructure(D) {
  const lines = [D.loci.map(n => n.replace(/\s+/g, '_')).join('\t')];
  for (let i = 0; i < D.n; i++) for (const X of [D.A, D.B]) lines.push([D.ids[i].replace(/\s+/g, '_'), D.pop[i] + 1, ...D.loci.map((_, l) => X[l][i] < 0 ? -9 : D.alleles[l][X[l][i]])].join('\t'));
  return lines.join('\n') + '\n';
}

return { VERSION, lnGamma, lnFact, chi2sf, rng, shuffle, mean, sd, quantile, pAdjust, fisherCombine, cleanAllele, parseDelimited, parseGenotypes, encode,
  counts, diversity, richness, nullFreq, neiLocus, neiRatios, wcLocus, wcRatios, fstats, fMulti, bootLoci, thetaOnly, permTheta, hwe, hweAll, ldAll,
  eigSym, pca, kmeans, dapc, defaultNPC, defaultRestarts, describe, pairwise, toGenepop, toStructure };
});
