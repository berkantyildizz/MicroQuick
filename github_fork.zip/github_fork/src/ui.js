/* MicroQuick user interface — v1.1.0. All statistics come from the MQ core above. */
'use strict';
const UI = (() => {
const $ = id => document.getElementById(id);
const PAL = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#882255', '#44AA99', '#999933', '#332288', '#AA4499', '#117733', '#DDCC77', '#661100', '#6699CC', '#888888', '#F0E442'];
const S = { parsed: null, fileName: '', sel: null, D: null, tables: {}, charts: {}, timing: {}, tab: 'overview' };
const TABS = [['overview', 'Overview'], ['qc', 'Data quality (HWE · LD · null alleles)'], ['locus', 'Per-locus'], ['pops', 'Populations'], ['fstats', 'F-statistics'], ['diff', 'Differentiation'], ['pca', 'PCA'], ['cluster', 'Clustering & DAPC'], ['charts', 'Charts'], ['guide', 'Guide']];
const CORR = { bh: 'Benjamini–Hochberg FDR', by: 'Benjamini–Yekutieli FDR', bonferroni: 'Bonferroni', none: 'none' };

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ok = v => v !== null && v !== undefined && typeof v === 'number' && isFinite(v);
const f = (v, d = 4) => ok(v) ? v.toFixed(d) : '—';
const fp = p => !ok(p) ? '—' : (p < 0.0001 ? p.toExponential(1) : p.toFixed(4));
const ci = (c, d = 4) => c && ok(c[0]) ? `${c[0].toFixed(d)} – ${c[1].toFixed(d)}` : '—';
const cssv = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const tick = () => new Promise(r => setTimeout(r, 0));

function msg(type, html) { const d = document.createElement('div'); d.className = 'note ' + (type || ''); d.innerHTML = html; $('msgArea').appendChild(d); }
function clearMsgs() { $('msgArea').innerHTML = ''; }
function progress(text, frac) { $('progress').classList.remove('hidden'); $('progMsg').textContent = text; $('progBar').style.width = Math.round(100 * frac) + '%'; }

// ── table registry: one definition drives screen, CSV and XLSX output ──────────────
function table(id, title, head, rows, opt = {}) {
  S.tables[id] = { title, head: head.map(h => h.replace(/<[^>]+>/g, '')), rows: rows.map(r => r.map(c => (c && typeof c === 'object') ? c.v : c)), sheet: opt.sheet || id };
  const th = head.map(h => `<th>${h}</th>`).join('');
  const body = rows.map((r, ri) => `<tr class="${opt.sumRows && opt.sumRows.includes(ri) ? 'sum' : ''}">` + r.map((c, ci2) => {
    const o = (c && typeof c === 'object') ? c : { v: c }; const d = opt.dec ? (opt.dec[ci2] ?? 4) : 4;
    const txt = o.t !== undefined ? o.t : (typeof o.v === 'number' ? (Number.isInteger(o.v) && d !== 'p' ? String(o.v) : (d === 'p' ? fp(o.v) : f(o.v, d))) : (o.v === null || o.v === undefined || (typeof o.v === 'number' && !isFinite(o.v)) ? '—' : esc(o.v)));
    return `<td class="${ci2 === 0 ? 'name ' : 'mono '}${o.c || ''}" ${o.s ? `style="${o.s}"` : ''} ${o.tip ? `title="${esc(o.tip)}"` : ''}>${txt}</td>`; }).join('') + '</tr>').join('');
  return `<div><div class="row between" style="margin-bottom:6px"><p class="b small">${title}</p><button class="btn xs" onclick="UI.csv('${id}')">CSV</button></div>
    ${opt.note ? `<p class="muted small" style="margin-bottom:6px">${opt.note}</p>` : ''}<div class="tscroll" style="${opt.max ? 'max-height:' + opt.max + 'px' : ''}"><table class="dtable"><thead><tr>${th}</tr></thead><tbody>${body}</tbody></table></div></div>`;
}
function download(name, text, mime) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime || 'text/plain;charset=utf-8' })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
const csvCell = v => { if (v === null || v === undefined || (typeof v === 'number' && !isFinite(v))) return ''; const s = String(v); return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
function tableCSV(id) { const t = S.tables[id]; return [t.head, ...t.rows].map(r => r.map(csvCell).join(',')).join('\n') + '\n'; }
function csv(id) { download(`MicroQuick_${id}.csv`, '﻿' + tableCSV(id), 'text/csv;charset=utf-8'); }

// ── loading ─────────────────────────────────────────────────────────────────
function loadFile(file) {
  if (!file) return; clearMsgs(); const ext = file.name.split('.').pop().toLowerCase(), r = new FileReader();
  r.onload = ev => { try {
    let rows;
    if (ext === 'xlsx' || ext === 'xls') { const wb = XLSX.read(new Uint8Array(ev.target.result), { type: 'array' }); rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: true, defval: '' }); }
    else rows = MQ.parseDelimited(new TextDecoder('utf-8').decode(ev.target.result)).rows;
    ingest(rows, file.name);
  } catch (e) { msg('err', 'Could not read the file: ' + esc(e.message)); } };
  r.readAsArrayBuffer(file);
}
function loadText(text, name) { clearMsgs(); ingest(MQ.parseDelimited(text).rows, name); }
function loadExample() { loadText(EXAMPLE_CSV, 'example_simulated_Denizli_Gerze.csv'); msg('warn', 'The example file is <b>simulated</b> (125 individuals, 12 loci, 5 subpopulations). It demonstrates the software and says nothing about any real population.'); }
function ingest(rows, name) {
  rows = rows.filter(r => Array.isArray(r) && r.some(v => v !== null && v !== undefined && String(v).trim() !== ''));
  if (rows.length < 2) { msg('err', 'No data rows found below the header row.'); return; }
  const P = MQ.parseGenotypes(rows[0].map(h => h == null ? '' : String(h)), rows.slice(1));
  if (!P.lociNames.length) { msg('err', 'No locus columns were recognised. Use two columns per locus, e.g. <code>Locus1(1)</code> and <code>Locus1(2)</code>, or one <code>148/150</code> column per locus — see the template.'); return; }
  S.parsed = P; S.fileName = name; $('dropLabel').textContent = name;
  const pops = []; P.records.forEach(r => { if (!pops.includes(r.pop)) pops.push(r.pop); });
  S.allPops = pops; S.sel = { pops: new Set(pops), loci: new Set(P.lociNames) };
  $('results').classList.add('hidden'); renderStage();
}
function renderStage() {
  const P = S.parsed, w = P.warn, cnt = {}; P.records.forEach(r => cnt[r.pop] = (cnt[r.pop] || 0) + 1);
  const warn = [];
  if (w.partial) warn.push(`${w.partial} genotype(s) had only one allele scored and are treated as missing genotypes.`);
  if (w.unreadable) warn.push(`${w.unreadable} genotype(s) contained non-numeric allele values and are treated as missing.`);
  if (w.polyploid) warn.push(`${w.polyploid} cell(s) contained more than two alleles. MicroQuick analyses diploid data only; these genotypes are treated as missing.`);
  if (!P.hasPop) warn.push('No population column was found: all individuals form one group, so differentiation statistics, DAPC with population priors and per-population tests are unavailable.');
  const small = S.allPops.filter(p => cnt[p] < 10); if (P.hasPop && small.length) warn.push(`Population(s) with fewer than 10 individuals (${small.map(esc).join(', ')}): estimates and tests for these have low precision and power.`);
  const opt = (id, vals, def, lab) => `<label class="f"><span>${lab}</span><select id="${id}">${vals.map(v => `<option value="${v[0]}"${v[0] === def ? ' selected' : ''}>${v[1]}</option>`).join('')}</select></label>`;
  $('stagePanel').innerHTML = `<div class="panel pad stack" style="border-color:var(--accent)">
    <div class="row between"><div><p class="b">2 · Check what was read, choose what to analyse</p>
      <p class="muted small"><b>${esc(S.fileName)}</b> — ${P.records.length} individuals · ${P.lociNames.length} loci · ${P.hasPop ? S.allPops.length + ' populations (column “' + esc(P.popName) + '”)' : 'no population column'} · ${P.combined ? 'one column per locus (a/b)' : 'two columns per locus'}</p></div>
      <button class="btn btn-primary" style="font-size:.95rem;padding:10px 24px" onclick="UI.run()">▶ Run analysis</button></div>
    ${warn.map(x => `<div class="note warn">${x}</div>`).join('')}
    ${P.hasPop ? `<div><p class="small muted" style="margin-bottom:5px">Populations — click to exclude/include (n individuals):</p><div class="row" id="popChips">${S.allPops.map((p, i) => `<span class="chip on" data-k="pops" data-v="${esc(p)}">${esc(p)} (${cnt[p]})</span>`).join('')}</div></div>` : ''}
    <div><p class="small muted" style="margin-bottom:5px">Loci — click to exclude/include (e.g. after inspecting the Data quality tab):</p><div class="row" id="locChips">${P.lociNames.map(l => `<span class="chip on" data-k="loci" data-v="${esc(l)}">${esc(l)}</span>`).join('')}</div></div>
    <div class="row" style="align-items:flex-end">
      ${opt('setPerm', [[0, 'none (fastest)'], [499, '499'], [999, '999'], [4999, '4 999'], [9999, '9 999']], 999, 'Permutations (HWE, LD, F<sub>ST</sub> tests)')}
      ${opt('setBoot', [[0, 'none'], [999, '999'], [4999, '4 999']], 999, 'Bootstrap replicates (95% CI, over loci)')}
      ${opt('setCorr', Object.entries(CORR), 'bh', 'Multiple-testing correction')}
      <label class="f">Significance level α<input type="number" id="setAlpha" value="0.05" min="0.001" max="0.2" step="0.005" style="width:90px"></label>
      <label class="f">Random seed<input type="number" id="setSeed" value="20260101" style="width:120px"></label>
      <p class="muted2 small" style="flex:1;min-width:240px">The same file, selection, settings and seed always give the same results. They are written to the “Run_info” sheet of the report.</p>
    </div></div>`;
  document.querySelectorAll('#stagePanel .chip').forEach(c => c.onclick = () => { const set = S.sel[c.dataset.k], v = c.dataset.v; if (set.has(v)) set.delete(v); else set.add(v); c.classList.toggle('on', set.has(v)); c.classList.toggle('off', !set.has(v)); });
}

// ── analysis pipeline ────────────────────────────────────────────────────────
async function run() {
  if (!S.parsed) return; clearMsgs();
  const st = S.set = { perm: +$('setPerm').value, boot: +$('setBoot').value, corr: $('setCorr').value, alpha: +$('setAlpha').value || 0.05, seed: Math.floor(+$('setSeed').value) || 1 };
  const D = S.D = MQ.encode(S.parsed.records, S.parsed.lociNames, { pops: [...S.sel.pops], loci: [...S.sel.loci] });
  if (D.n < 2 || !D.L) { msg('err', 'Nothing to analyse: the selection contains no scorable genotypes.'); return; }
  const rnd = MQ.rng(st.seed), T = S.timing = {}, t0 = performance.now(); let t;
  const step = async (name, label, frac, fn) => { progress(label, frac); await tick(); await tick(); t = performance.now(); const r = await fn(); T[name] = performance.now() - t; return r; };
  try {
    S.desc = await step('diversity_Fstatistics', 'Allele frequencies, diversity and F-statistics…', 0.05, () => MQ.describe(D));
    S.hw = await step('HWE', `Hardy–Weinberg tests (${D.L} loci × ${D.K} populations)…`, 0.15, () => MQ.hweAll(D, st.perm, rnd));
    S.ci = {}; S.globalP = NaN; S.pw = []; S.ld = [];
    if (D.K > 1) {
      await step('global_CI_test', 'Global F-statistics: bootstrap and permutation…', 0.3, () => { if (st.boot && D.L > 1) S.ci = MQ.bootLoci(S.desc.per, st.boot, rnd, ['theta', 'f', 'capF', 'Gst', 'Gst2', 'D', 'Fis']); if (st.perm) S.globalP = MQ.permTheta(D, D.pop, D.K, st.perm, rnd).p; });
      S.pw = await step('pairwise', `Pairwise differentiation (${D.K * (D.K - 1) / 2} pairs)…`, 0.4, () => MQ.pairwise(D, { boot: D.L > 1 ? st.boot : 0, perm: st.perm, rnd }));
    }
    if (st.perm && D.L > 1) S.ld = await step('LD', `Linkage disequilibrium (${D.L * (D.L - 1) / 2} locus pairs)…`, 0.6, () => MQ.ldAll(D, st.perm, rnd));
    S.pca = await step('PCA', 'Principal component analysis…', 0.8, () => MQ.pca(D, 80));
    S.km = null; S.da = null; S.clus = null;
    if (S.pca) await step('clustering_DAPC', 'k-means and DAPC…', 0.9, () => { S.nPC = MQ.defaultNPC(S.pca, D.n, D.K); clusterScan(); if (D.K > 1) S.da = MQ.dapc(S.pca.scores, Math.min(S.nPC, D.n - D.K - 1), D.pop, D.K); S.daPrior = 'pop'; });
    T.total = performance.now() - t0;
  } catch (e) { $('progress').classList.add('hidden'); msg('err', 'Analysis failed: ' + esc(e.message)); console.error(e); return; }
  adjust(); S.runAt = new Date();
  $('progress').classList.add('hidden'); $('results').classList.remove('hidden');
  S.tables = {}; renderAll(); switchTab('overview');
  $('statusBadge').textContent = `${D.n} ind · ${D.L} loci · ${D.K} pop · ${(T.total / 1000).toFixed(2)} s`;
}
function clusterScan() {
  const D = S.D, rnd = MQ.rng(S.set.seed + 7), Kmax = Math.min(Math.max(10, D.K + 3), 20, D.n - 1); S.km = [];
  for (let K = 1; K <= Kmax; K++) S.km.push(MQ.kmeans(S.pca.scores, S.nPC, K, MQ.defaultRestarts(D.n), rnd));
}
function adjust() {
  const D = S.D, m = S.set.corr, key = S.set.perm ? 'pExact' : 'pChi'; S.hwKey = key;
  const flat = []; S.hw.byPop.forEach(r => r.forEach(c => flat.push(c[key]))); const adj = MQ.pAdjust(flat, m); let i = 0; S.hw.byPop.forEach(r => r.forEach(c => c.adj = adj[i++]));
  const pa = MQ.pAdjust(S.hw.pooled.map(c => c[key]), m); S.hw.pooled.forEach((c, j) => c.adj = pa[j]);
  const la = MQ.pAdjust(S.ld.map(x => x.p), m); S.ld.forEach((x, j) => x.adj = la[j]);
  const wa = MQ.pAdjust(S.pw.map(x => x.p), m); S.pw.forEach((x, j) => x.adj = wa[j]);
}

// ── rendering ────────────────────────────────────────────────────────────────
function renderAll() {
  $('tabBar').innerHTML = TABS.map(t => `<button class="tab-btn" data-tab="${t[0]}" onclick="UI.switchTab('${t[0]}')">${t[1]}</button>`).join('') +
    `<div style="margin-left:auto;padding:0 12px;flex-wrap:nowrap" class="row"><button class="btn" onclick="UI.xlsx()">Report .xlsx</button><button class="btn" onclick="UI.genepop()">Genepop</button><button class="btn" onclick="UI.structureFile()">STRUCTURE</button></div>`;
  $('tabBody').innerHTML = TABS.map(t => `<div id="tab-${t[0]}" class="pad stack hidden"></div>`).join('');
  Object.values(S.charts).forEach(c => c.destroy()); S.charts = {};
  rOverview(); rQC(); rLocus(); rPops(); rF(); rDiff(); rPCA(); rCluster(); rCharts(); rGuide();
}
function switchTab(id, force) {
  if (force && $('results').classList.contains('hidden')) { $('results').classList.remove('hidden'); if (!$('tab-guide')) { $('tabBar').innerHTML = `<button class="tab-btn active" data-tab="guide">Guide</button>`; $('tabBody').innerHTML = '<div id="tab-guide" class="pad stack"></div>'; rGuide(); } }
  S.tab = id; document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === id));
  document.querySelectorAll('#tabBody>div').forEach(d => d.classList.toggle('hidden', d.id !== 'tab-' + id));
  if (force) $('results').scrollIntoView({ behavior: 'smooth' });
}
const card = (l, v, s, c) => `<div class="metric"><div class="lbl">${l}</div><div class="val mono" style="${c ? 'color:' + c : ''}">${v}</div><div class="sub">${s || ''}</div></div>`;

function rOverview() {
  const D = S.D, d = S.desc, m = d.multi || {}, L = d.locus, a = S.set.alpha, multi = D.K > 1;
  const hwT = [], hwS = []; S.hw.byPop.forEach(r => r.forEach(c => { if (ok(c[S.hwKey])) { hwT.push(c); if (c.adj < a) hwS.push(c); } }));
  const ldS = S.ld.filter(x => ok(x.adj) && x.adj < a).length, ldT = S.ld.filter(x => ok(x.p)).length;
  const pwS = S.pw.filter(x => ok(x.adj) && x.adj < a).length;
  const locFlag = D.loci.filter((_, l) => { const t = S.hw.byPop[l].filter(c => ok(c[S.hwKey])); return t.length && t.filter(c => c.adj < a).length > t.length / 2; });
  const popFlag = D.popNames.filter((_, p) => { const t = S.hw.byPop.map(r => r[p]).filter(c => ok(c[S.hwKey])); return t.length && t.filter(c => c.adj < a).length > t.length / 2; });
  const mono = L.filter(l => l.Na < 2).map(l => l.locus);
  const notes = [];
  if (mono.length) notes.push(`<div class="note warn">Monomorphic locus/loci in this selection: ${mono.map(esc).join(', ')}. They carry no information and can be excluded.</div>`);
  if (locFlag.length) notes.push(`<div class="note warn">Locus/loci departing from HWE in more than half of the tested populations: <b>${locFlag.map(esc).join(', ')}</b>. A locus-specific pattern suggests a technical cause (null alleles, scoring errors); consider re-scoring or excluding it and re-running.</div>`);
  if (popFlag.length) notes.push(`<div class="note warn">Population(s) departing from HWE at more than half of the tested loci: <b>${popFlag.map(esc).join(', ')}</b>. A population-wide pattern suggests a biological or sampling cause (inbreeding, hidden substructure/Wahlund effect, family sampling).</div>`);
  if (!locFlag.length && !popFlag.length && hwT.length) notes.push(`<div class="note ok">No locus and no population shows a consistent pattern of HWE departures (${hwS.length} of ${hwT.length} single tests significant after ${CORR[S.set.corr]} correction).</div>`);
  if (!S.set.perm) notes.push('<div class="note warn">Permutations were switched off: HWE uses the asymptotic χ² test only, and LD tests and F<sub>ST</sub> p values were not computed.</div>');
  if (D.L < 5 && multi) notes.push('<div class="note warn">Fewer than five loci: bootstrap confidence intervals over loci are unreliable and should not be reported.</div>');
  $('tab-overview').innerHTML = `
    <div class="grid g4">${card('Individuals', D.n, 'in the current selection')}${card('Loci', D.L, mono.length ? mono.length + ' monomorphic' : 'all polymorphic')}${card('Populations', D.K, esc(D.popNames.join(', ')).slice(0, 60))}${card('Missing genotypes', (100 * d.missing).toFixed(1) + '%', 'excluded per locus')}</div>
    <div class="grid g4">${card('Mean N<sub>a</sub> (pooled)', f(MQ.mean(L.map(l => l.Na)), 2), 'alleles per locus')}
      ${card('Mean H<sub>O</sub> / uH<sub>E</sub> (pooled)', f(MQ.mean(L.map(l => l.Ho)), 3) + ' / ' + f(MQ.mean(L.map(l => l.uHe)), 3), 'observed / unbiased expected')}
      ${multi ? card('F<sub>IS</sub> (f, W&amp;C)', f(m.f, 3), '95% CI ' + ci(S.ci.f, 3)) : card('F (pooled)', f(1 - MQ.mean(L.map(l => l.Ho)) / MQ.mean(L.map(l => l.uHe)), 3), '1 − H<sub>O</sub>/uH<sub>E</sub>')}
      ${multi ? card('F<sub>ST</sub> (θ, W&amp;C)', f(m.theta, 3), `95% CI ${ci(S.ci.theta, 3)} · p = ${fp(S.globalP)}`) : ''}
      ${multi ? card('G″<sub>ST</sub>', f(m.Gst2, 3), '95% CI ' + ci(S.ci.Gst2, 3)) : ''}${multi ? card('Jost’s D', f(m.D, 3), '95% CI ' + ci(S.ci.D, 3)) : ''}</div>
    <div class="grid g4">${card('HWE departures', `${hwS.length} / ${hwT.length}`, `locus × population tests, ${CORR[S.set.corr]}, α = ${a}`, hwS.length ? 'var(--warn)' : 'var(--ok)')}
      ${S.set.perm && D.L > 1 ? card('Locus pairs in LD', `${ldS} / ${ldT}`, 'Fisher across populations, corrected', ldS ? 'var(--warn)' : 'var(--ok)') : ''}
      ${multi && S.set.perm ? card('Differentiated pairs', `${pwS} / ${S.pw.length}`, 'pairwise θ, permutation test, corrected') : ''}
      ${card('Run time', (S.timing.total / 1000).toFixed(2) + ' s', 'this browser, this device')}</div>
    ${notes.join('')}
    ${table('run_log', 'Run log', ['Step', 'Time (ms)'], Object.entries(S.timing).map(([k, v]) => [k.replace(/_/g, ' '), Math.round(v)]), { max: 260 })}`;
}

function rQC() {
  const D = S.D, a = S.set.alpha, key = S.hwKey, lab = key === 'pExact' ? `Monte Carlo exact test, ${S.set.perm} permutations` : 'χ² test (asymptotic)';
  const cell = c => { if (!ok(c[key])) return { v: NaN, tip: `n = ${c.n}, alleles = ${c.k}: not testable` };
    return { v: c[key], t: fp(c[key]) + (c.Fis > 0 ? ' ▾' : c.Fis < 0 ? ' ▴' : ''), c: c.adj < a ? 'sig' : (c[key] < a ? 'nom' : ''), tip: `n = ${c.n}, alleles = ${c.k}, Ho = ${f(c.Ho, 3)}, uHe = ${f(c.uHe, 3)}, FIS = ${f(c.Fis, 3)}; chi2 = ${f(c.chi2, 2)}, df = ${c.df}, p(chi2) = ${fp(c.pChi)}, smallest expected count = ${f(c.minExp, 2)}; adjusted p = ${fp(c.adj)}` }; };
  const rows = D.loci.map((l, i) => { const r = S.hw.byPop[i], t = r.filter(c => ok(c[key])); return [l, ...r.map(cell), `${t.filter(c => c.adj < a).length} / ${t.length}`, cell(S.hw.pooled[i])]; });
  rows.push(['Significant / tested', ...D.popNames.map((_, p) => { const t = S.hw.byPop.map(r => r[p]).filter(c => ok(c[key])); return `${t.filter(c => c.adj < a).length} / ${t.length}`; }), '', '']);
  const hw = table('HWE', `Hardy–Weinberg equilibrium within populations — ${lab}`, ['Locus', ...D.popNames.map(esc), 'Sig. / tested', 'All pooled'], rows, { sumRows: [rows.length - 1],
    note: `p values per locus × population. <span class="sig">Red</span>: significant after ${CORR[S.set.corr]} correction over all ${D.L * D.K} tests (α = ${a}); <span class="nom">orange</span>: p &lt; α before correction only. ▾ heterozygote deficit, ▴ excess. Hover a cell for n, alleles, H<sub>O</sub>, uH<sub>E</sub>, F<sub>IS</sub> and the χ² test with k(k−1)/2 degrees of freedom. The “All pooled” column ignores populations and is expected to reject whenever populations differ (Wahlund effect); it is shown for comparison only.` });
  const hwLong = []; D.loci.forEach((l, i) => S.hw.byPop[i].forEach((c, p) => hwLong.push([l, D.popNames[p], c.n, c.k, c.Ho, c.uHe, c.Fis, c.chi2, c.df, c.pChi, c.pExact, c.adj, c.minExp])));
  S.tables.HWE_detail = { title: 'HWE detail', sheet: 'HWE_detail', head: ['Locus', 'Population', 'n', 'alleles', 'Ho', 'uHe', 'FIS', 'chi2', 'df', 'p_chi2', 'p_exact', 'p_adjusted', 'min_expected_count'], rows: hwLong };
  const nrows = D.loci.map((l, i) => [l, ...S.desc.cells[i].map(c => ({ v: c.nullF, t: ok(c.nullF) ? f(Math.max(0, c.nullF), 3) : '—', c: c.nullF > 0.1 ? 'nom' : '' })), { v: S.desc.locus[i].nullF, t: f(Math.max(0, S.desc.locus[i].nullF), 3) }]);
  const nul = table('null_alleles', 'Apparent null-allele frequency (Brookfield 1996, estimator 1)', ['Locus', ...D.popNames.map(esc), 'All pooled'], nrows, { max: 360,
    note: 'r = (uH<sub>E</sub> − H<sub>O</sub>)/(1 + uH<sub>E</sub>), set to 0 when negative, computed <b>within each population</b>. The estimator turns <i>any</i> heterozygote deficit into a null-allele frequency: inbreeding and hidden substructure produce the same signal, at all loci at once. Treat a value as evidence of a null allele only when the deficit is specific to that locus and repeated across populations. The pooled column is inflated by differences among populations.' });
  let ld = '<div class="note">Linkage-disequilibrium tests need permutations and at least two loci.</div>';
  if (S.ld.length) { const lr = S.ld.slice().sort((x, y) => (ok(x.p) ? x.p : 2) - (ok(y.p) ? y.p : 2)).map(x => [D.loci[x.i], D.loci[x.j], x.nPop, x.chi2, x.df, { v: x.p, t: fp(x.p), c: x.adj < a ? 'sig' : (x.p < a ? 'nom' : '') }, { v: x.adj, t: fp(x.adj) }]);
    ld = table('LD', `Genotypic linkage disequilibrium between locus pairs — G test within populations, ${S.set.perm} permutations, combined across populations by Fisher’s method`, ['Locus 1', 'Locus 2', 'Populations informative', 'χ² (Fisher)', 'df', 'p', 'p adjusted'], lr, { dec: [0, 0, 0, 2, 0, 'p', 'p'], max: 380, note: `Sorted by p. Correction: ${CORR[S.set.corr]} over ${S.ld.filter(x => ok(x.p)).length} pairs. With ${S.set.perm} permutations the smallest attainable p per population is ${(1 / (S.set.perm + 1)).toFixed(4)}.` });
    const long = []; S.ld.forEach(x => x.byPop.forEach((p, k) => long.push([D.loci[x.i], D.loci[x.j], D.popNames[k], p]))); S.tables.LD_by_population = { title: 'LD by population', sheet: 'LD_by_population', head: ['Locus1', 'Locus2', 'Population', 'p'], rows: long }; }
  const mrows = D.loci.map((l, i) => [l, ...S.desc.cells[i].map((c, p) => { const n = D.popIdx[p].length, m = n ? 100 * (1 - c.N / n) : NaN; return { v: m, t: f(m, 1), c: m > 20 ? 'nom' : '' }; })]);
  const miss = table('missing', 'Missing genotypes (%) per locus and population', ['Locus', ...D.popNames.map(esc)], mrows, { max: 300 });
  $('tab-qc').innerHTML = `<div class="note">Read this tab <b>before</b> the others. Loci or populations that fail here can be switched off in panel 2 above, and the analysis re-run, so that the effect of excluding them is visible. Tests are run within populations because pooling differentiated populations creates heterozygote deficits and LD by itself.</div>${hw}${ld}${nul}${miss}`;
}

function rLocus() {
  const L = S.desc.locus, cols = ['N', 'Na', 'Ne', 'I', 'Ho', 'He', 'uHe', 'PIC', 'F', 'Ar'];
  const rows = L.map(l => [l.locus, ...cols.map(c => l[c])]);
  rows.push(['Mean', ...cols.map(c => MQ.mean(L.map(l => l[c])))], ['SD', ...cols.map(c => MQ.sd(L.map(l => l[c])))]);
  $('tab-locus').innerHTML = table('per_locus', 'Per-locus statistics, all selected individuals pooled', ['Locus', 'N', 'N<sub>a</sub>', 'N<sub>e</sub>', 'I', 'H<sub>O</sub>', 'H<sub>E</sub>', 'uH<sub>E</sub>', 'PIC', 'F', 'A<sub>r</sub>'], rows, { dec: [0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3], sumRows: [rows.length - 2, rows.length - 1],
    note: `N individuals typed; N<sub>a</sub> alleles; N<sub>e</sub> = 1/Σp²; I Shannon index; H<sub>E</sub> = 1 − Σp²; uH<sub>E</sub> = 2N/(2N−1)·H<sub>E</sub> (Nei 1978); PIC (Botstein et al. 1980); F = 1 − H<sub>O</sub>/H<sub>E</sub>. With several populations, pooled H<sub>E</sub> and F include differences among populations — use the Populations and F-statistics tabs for within-population values. A<sub>r</sub>: mean over populations of allelic richness rarefied to ${S.desc.rareG} gene copies.` });
}
function rPops() {
  const D = S.D, P = S.desc.perPop;
  const rows = P.map(p => [p.pop, p.N, p.nTyped, 100 * p.missing, p.Na, p.Ne, p.Ar, p.Ho, p.He, p.uHe, p.Fis, p.priv]);
  const t1 = table('populations', 'Diversity within populations (means over loci)', ['Population', 'N', 'mean N typed', 'missing %', 'N<sub>a</sub>', 'N<sub>e</sub>', 'A<sub>r</sub>', 'H<sub>O</sub>', 'H<sub>E</sub>', 'uH<sub>E</sub>', 'F<sub>IS</sub>', 'Private alleles'], rows, { dec: [0, 0, 1, 1, 2, 3, 3, 3, 3, 3, 3, 0],
    note: `A<sub>r</sub>: allelic richness rarefied to ${S.desc.rareG} gene copies (= ${S.desc.rareG / 2} diploid individuals, the smallest number typed at any locus in any population), so that populations with different sample sizes are comparable. F<sub>IS</sub> = 1 − mean H<sub>O</sub> / mean uH<sub>E</sub>. Private alleles are raw counts and increase with sample size.` });
  const mk = (id, title, k, d) => table(id, title, ['Locus', ...D.popNames.map(esc)], D.loci.map((l, i) => [l, ...S.desc.cells[i].map(c => c[k])]), { dec: [0, ...D.popNames.map(() => d)], max: 320 });
  $('tab-pops').innerHTML = t1 + mk('uHe_by_locus_pop', 'Unbiased expected heterozygosity (uH<sub>E</sub>) per locus and population', 'uHe', 3) + mk('Ho_by_locus_pop', 'Observed heterozygosity (H<sub>O</sub>) per locus and population', 'Ho', 3) + mk('Na_by_locus_pop', 'Number of alleles per locus and population', 'Na', 0) + mk('Ar_by_locus_pop', 'Allelic richness per locus and population', 'Ar', 3);
}
function rF() {
  const D = S.D, L = S.desc.locus, m = S.desc.multi;
  if (D.K < 2 || !m) { $('tab-fstats').innerHTML = '<div class="note">F-statistics need a population column with at least two populations.</div>'; return; }
  const cols = ['HoS', 'Hs', 'Ht', 'Fis', 'Gst', 'Gst2', 'D', 'f', 'theta', 'capF'];
  const rows = L.map(l => [l.locus, ...cols.map(c => l[c])]);
  rows.push(['Multilocus estimate', ...cols.map(c => m[c])], ['95% CI (bootstrap over loci)', ...cols.map(c => S.ci[c] ? { v: ci(S.ci[c], 3) } : '')], ['Mean of per-locus values', ...cols.map(c => MQ.mean(L.map(l => l[c])))], ['SD of per-locus values', ...cols.map(c => MQ.sd(L.map(l => l[c])))]);
  $('tab-fstats').innerHTML = `<div class="grid g4">${card('F<sub>IS</sub> (f)', f(m.f, 4), '95% CI ' + ci(S.ci.f, 3))}${card('F<sub>ST</sub> (θ)', f(m.theta, 4), `95% CI ${ci(S.ci.theta, 3)} · p = ${fp(S.globalP)}`)}${card('F<sub>IT</sub> (F)', f(m.capF, 4), '95% CI ' + ci(S.ci.capF, 3))}${card('G<sub>ST</sub> · G″<sub>ST</sub> · D', `${f(m.Gst, 3)} · ${f(m.Gst2, 3)} · ${f(m.D, 3)}`, 'Nei 1987 · Meirmans &amp; Hedrick 2011 · Jost 2008')}</div>
    ${table('F_statistics', 'F-statistics and differentiation per locus', ['Locus', 'H<sub>O</sub>', 'H<sub>S</sub>', 'H<sub>T</sub>', 'F<sub>IS</sub> (Nei)', 'G<sub>ST</sub>', 'G″<sub>ST</sub>', 'D<sub>est</sub>', 'f (W&amp;C)', 'θ (W&amp;C)', 'F (W&amp;C)'], rows, { sumRows: [rows.length - 4, rows.length - 3, rows.length - 2, rows.length - 1],
      note: `Two estimator families are reported side by side. <b>Nei (1987)</b>: H<sub>O</sub>, H<sub>S</sub>, H<sub>T</sub> with the Nei &amp; Chesser (1983) sample-size correction, G<sub>ST</sub> = (H<sub>T</sub> − H<sub>S</sub>)/H<sub>T</sub>, G″<sub>ST</sub> (standardised for heterozygosity and number of populations) and Jost’s D. <b>Weir &amp; Cockerham (1984)</b>: f, θ, F from variance components, weighted by sample size. The <b>multilocus estimate</b> is a ratio of sums over loci (W&amp;C) or of locus-averaged H components (Nei); it is the value to report. The <b>mean of per-locus values</b> is a different quantity, given for description only. Global θ is tested by permuting individuals among populations (${S.set.perm} permutations).` })}
    <div class="note">G<sub>ST</sub> and θ measure how much of the total variation lies among populations (fixation); their maximum falls as within-population heterozygosity rises, so fixed verbal thresholds (“moderate”, “great”) do not apply to multi-allelic markers. G″<sub>ST</sub> rescales to the 0–1 range; Jost’s D measures allelic differentiation (the share of alleles not shared). They answer different questions and are best read together, with their confidence intervals.</div>`;
}
function rDiff() {
  const D = S.D, a = S.set.alpha;
  if (D.K < 2) { $('tab-diff').innerHTML = '<div class="note">At least two populations are required.</div>'; return; }
  $('tab-diff').innerHTML = `<div class="row"><span class="small muted">Matrix shows</span><select id="diffStat"><option value="theta">θ (Weir &amp; Cockerham F_ST)</option><option value="Gst2">G″_ST</option><option value="D">Jost’s D</option></select>
    <label class="small muted"><input type="checkbox" id="showNm"> also show the island-model N<sub>e</sub>m equivalent of θ</label></div><div id="diffMat"></div><div id="diffTab"></div>`;
  const draw = () => {
    const k = $('diffStat').value, get = {}; S.pw.forEach(x => get[x.i + '|' + x.j] = x); const mx = Math.max(1e-9, ...S.pw.map(x => ok(x[k]) ? x[k] : 0));
    const rows = D.popNames.map((p, i) => [p, ...D.popNames.map((q, j) => { if (i === j) return { v: '', t: '—' }; const x = get[Math.min(i, j) + '|' + Math.max(i, j)];
      if (i > j) return { v: x[k], t: f(x[k], 4), s: `background:rgba(var(--heat),${(0.75 * Math.max(0, x[k]) / mx).toFixed(3)})` };
      return { v: x.p, t: ok(x.p) ? fp(x.p) + (x.adj < a ? ' *' : '') : '—', c: x.adj < a ? 'b' : 'muted' }; })]);
    $('diffMat').innerHTML = table('pairwise_matrix', `Pairwise ${$('diffStat').selectedOptions[0].text} (below diagonal) and permutation p value for θ (above diagonal)`, ['', ...D.popNames.map(esc)], rows, { note: `Shading is relative to the largest value in this matrix; it is not a classification. * significant after ${CORR[S.set.corr]} correction over ${S.pw.length} pairs (α = ${a}); individuals permuted between the two populations, ${S.set.perm} permutations.` });
    const nm = $('showNm').checked, head = ['Population 1', 'Population 2', 'θ (F<sub>ST</sub>)', '95% CI (θ)', 'p', 'p adjusted', 'G″<sub>ST</sub>', '95% CI (G″<sub>ST</sub>)', 'Jost’s D', '95% CI (D)'];
    if (nm) head.push('N<sub>e</sub>m equivalent');
    $('diffTab').innerHTML = table('pairwise', 'Pairwise differentiation', head, S.pw.map(x => { const r = [D.popNames[x.i], D.popNames[x.j], x.theta, { v: ci(x.ci.theta, 4) }, { v: x.p, t: fp(x.p), c: x.adj < a ? 'sig' : '' }, { v: x.adj, t: fp(x.adj) }, x.Gst2, { v: ci(x.ci.Gst2, 4) }, x.D, { v: ci(x.ci.D, 4) }]; if (nm) r.push(x.theta > 0 ? (1 - x.theta) / (4 * x.theta) : NaN); return r; }), { dec: [0, 0, 4, 0, 'p', 'p', 4, 0, 4, 0, 2],
      note: 'Confidence intervals: percentile bootstrap over loci. Negative θ estimates are sampling noise around zero and are reported as estimated.' + (nm ? ' <b>N<sub>e</sub>m equivalent</b> = (1 − θ)/(4θ) is the number of migrants per generation that <i>would</i> produce this θ in Wright’s infinite-island model at migration–drift equilibrium. Real populations rarely meet those assumptions (Whitlock &amp; McCauley 1999); it is not an estimate of current gene flow.' : '') });
  };
  $('diffStat').onchange = draw; $('showNm').onchange = draw; draw();
}

// charts
function chartOpts(xl, yl, extra = {}) { const tc = cssv('--muted'), gc = cssv('--grid'), tx = cssv('--text');
  return Object.assign({ responsive: true, maintainAspectRatio: false, animation: false, plugins: { legend: { labels: { color: tx, usePointStyle: true, font: { size: 11 } } } },
    scales: { x: { title: { display: !!xl, text: xl, color: tx, font: { size: 12, weight: '600' } }, ticks: { color: tc }, grid: { color: gc } }, y: { title: { display: !!yl, text: yl, color: tx, font: { size: 12, weight: '600' } }, ticks: { color: tc }, grid: { color: gc } } } }, extra); }
function chart(id, cfg) { if (S.charts[id]) S.charts[id].destroy(); const el = $(id); if (!el) return; S.charts[id] = new Chart(el.getContext('2d'), cfg); }
const pngBtn = (id) => `<button class="btn xs" onclick="UI.png('${id}')">PNG</button>`;
function png(id) { const src = S.charts[id]; if (!src) return; const sc = 3, W = src.canvas.clientWidth * sc, H = src.canvas.clientHeight * sc, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H); const was = document.documentElement.classList.contains('dark'); document.documentElement.classList.remove('dark');
  const cfg = src.config, o = JSON.parse(JSON.stringify(cfg.options)); o.responsive = false; o.animation = false; o.devicePixelRatio = 1;
  (function walk(x) { for (const k in x) { if (k === 'size' && typeof x[k] === 'number') x[k] *= sc; else if (x[k] && typeof x[k] === 'object') walk(x[k]); } })(o);
  ['x', 'y'].forEach(ax => { if (o.scales && o.scales[ax]) { o.scales[ax].ticks = Object.assign(o.scales[ax].ticks || {}, { color: '#222', font: { size: 11 * sc } }); o.scales[ax].grid = Object.assign(o.scales[ax].grid || {}, { color: '#ddd' }); if (o.scales[ax].title) o.scales[ax].title.color = '#111'; } });
  if (o.plugins && o.plugins.legend && o.plugins.legend.labels) o.plugins.legend.labels.color = '#111';
  const data = { labels: cfg.data.labels, datasets: cfg.data.datasets.map(d => Object.assign({}, d, d.pointRadius ? { pointRadius: d.pointRadius * sc } : {})) };
  const tmp = new Chart(ctx, { type: cfg.type, data, options: o }); setTimeout(() => { const a = document.createElement('a'); a.href = cv.toDataURL('image/png'); a.download = 'MicroQuick_' + id + '.png'; a.click(); tmp.destroy(); if (was) document.documentElement.classList.add('dark'); }, 150); }
function scatterSets(xs, ys, labelsOf, names, ids) { return names.map((nm, g) => ({ label: nm, data: xs.map((x, i) => labelsOf[i] === g ? { x, y: ys[i], id: ids[i] } : null).filter(Boolean), backgroundColor: PAL[g % PAL.length] + 'cc', borderColor: PAL[g % PAL.length], pointRadius: 3.5 })); }
const tipId = { tooltip: { callbacks: { label: c => `${c.raw.id || ''} (${c.dataset.label})` } } };

function rPCA() {
  const el = $('tab-pca'), P = S.pca, D = S.D; if (!P) { el.innerHTML = '<div class="note">PCA needs at least three individuals and two alleles.</div>'; return; }
  const nc = Math.min(6, P.scores[0].length), o = s => [...Array(nc).keys()].map(i => `<option value="${i}"${i === s ? ' selected' : ''}>PC${i + 1}</option>`).join('');
  el.innerHTML = `<div class="row"><span class="small muted">Axes</span><select id="pcaX">${o(0)}</select><select id="pcaY">${o(1)}</select><span class="small muted">Variance explained: ${P.varExp.slice(0, 6).map((v, i) => `PC${i + 1} ${v.toFixed(1)}%`).join(' · ')}</span><span style="margin-left:auto">${pngBtn('pcaChart')}</span></div>
    <div class="panel pad"><div style="height:500px"><canvas id="pcaChart"></canvas></div></div>
    <p class="muted small">PCA of individual allele frequencies (0, ½, 1 per allele), centred, not scaled; ${P.nFeatures} allele columns; missing genotypes replaced by the allele’s mean frequency over all typed individuals (adegenet convention). PCA describes variation among individuals without using population labels; colours are added afterwards.</p>`;
  const draw = () => { const x = +$('pcaX').value, y = +$('pcaY').value; chart('pcaChart', { type: 'scatter', data: { datasets: scatterSets(P.scores.map(s => s[x]), P.scores.map(s => s[y]), D.pop, D.popNames, D.ids) }, options: chartOpts(`PC${x + 1} (${P.varExp[x].toFixed(1)}%)`, `PC${y + 1} (${P.varExp[y].toFixed(1)}%)`, { plugins: Object.assign({ legend: { position: 'right', labels: { color: cssv('--text'), usePointStyle: true } } }, tipId) }) }); };
  $('pcaX').onchange = draw; $('pcaY').onchange = draw; draw();
  S.tables.PCA_scores = { title: 'PCA scores', sheet: 'PCA_scores', head: ['Individual', 'Population', ...[...Array(Math.min(10, P.scores[0].length)).keys()].map(i => 'PC' + (i + 1))], rows: [['variance_%', '', ...P.varExp.slice(0, 10)], ...P.scores.map((s, i) => [D.ids[i], D.popNames[D.pop[i]], ...Array.from(s.subarray(0, 10))])] };
}

function rCluster() {
  const el = $('tab-cluster'), P = S.pca, D = S.D; if (!P || !S.km) { el.innerHTML = '<div class="note">Clustering needs a PCA.</div>'; return; }
  const maxPC = Math.max(2, Math.min(P.scores[0].length, Math.floor(D.n / 3)));
  el.innerHTML = `<div class="note">Exploratory, two-step procedure following Jombart et al. (2010). <b>(a)</b> k-means on the retained principal components for K = 1…${S.km.length}, compared by BIC — run <i>without</i> population labels. <b>(b)</b> DAPC, which finds the axes that best separate predefined groups — either your populations (informed) or the k-means clusters (uninformed). Compare both. This is not a model-based admixture analysis: no K is “the true K”, and membership probabilities are not ancestry proportions.</div>
    <div class="row" style="align-items:flex-end"><label class="f">Principal components retained<input type="number" id="nPC" min="1" max="${maxPC}" value="${S.nPC}" style="width:90px"></label>
      <label class="f">K for k-means<select id="kSel">${S.km.slice(1).map((_, i) => `<option value="${i + 2}">${i + 2}</option>`).join('')}</select></label>
      <label class="f">DAPC groups<select id="daPrior">${D.K > 1 ? '<option value="pop">populations (informed)</option>' : ''}<option value="km">k-means clusters (uninformed)</option></select></label>
      <button class="btn btn-primary" onclick="UI.recluster()">Update</button>
      <p class="muted2 small" style="flex:1;min-width:260px">Default: the components needed for 80% of the variance, at most N/3 (${S.nPC} here, ${P.cumVar[S.nPC - 1].toFixed(1)}%). Retaining too many components overfits DAPC. k-means: k-means++ start, ${MQ.defaultRestarts(D.n)} restarts, seed ${S.set.seed + 7}.</p></div>
    <div class="grid g2"><div class="panel pad"><div class="row between"><p class="b small">BIC of k-means solutions (lower is better; look for an elbow)</p>${pngBtn('bicChart')}</div><div style="height:260px"><canvas id="bicChart"></canvas></div></div>
      <div class="panel pad"><div class="row between"><p class="b small" id="daTitle">DAPC</p>${pngBtn('daChart')}</div><div style="height:260px"><canvas id="daChart"></canvas></div></div></div>
    <div class="panel pad"><div class="row between"><p class="b small">DAPC posterior membership probability per individual (grouped by population)</p>${pngBtn('memChart')}</div><div style="height:240px"><canvas id="memChart"></canvas></div></div>
    <div id="clusTabs" class="stack"></div>`;
  const kd = S.km.slice(1).reduce((b, k, i) => (k.bic < S.km[b].bic ? i + 1 : b), 0) + 1; $('kSel').value = Math.max(2, Math.min(S.kSel || (D.K > 1 ? D.K : kd), S.km.length)); $('daPrior').value = S.daPrior && (D.K > 1 || S.daPrior === 'km') ? S.daPrior : (D.K > 1 ? 'pop' : 'km');
  drawCluster();
}
function recluster() { const D = S.D, v = Math.max(1, Math.min(+$('nPC').value || S.nPC, Math.floor(D.n / 3), S.pca.scores[0].length)); if (v !== S.nPC) { S.nPC = v; clusterScan(); } S.kSel = +$('kSel').value; S.daPrior = $('daPrior').value; rCluster(); }
function drawCluster() {
  const D = S.D, P = S.pca, K = +$('kSel').value, km = S.km[K - 1], prior = $('daPrior').value; S.kSel = K; S.daPrior = prior;
  chart('bicChart', { type: 'line', data: { labels: S.km.map((_, i) => i + 1), datasets: [{ label: 'BIC', data: S.km.map(k => k.bic), borderColor: PAL[0], backgroundColor: PAL[0], pointRadius: 4, tension: 0 }] }, options: chartOpts('Number of clusters K', 'BIC', { plugins: { legend: { display: false } } }) });
  const grp = prior === 'pop' ? D.pop : km.assign, G = prior === 'pop' ? D.K : K, names = prior === 'pop' ? D.popNames : [...Array(K).keys()].map(i => 'Cluster ' + (i + 1));
  const nPCda = Math.max(1, Math.min(S.nPC, D.n - G - 1)), da = S.da = MQ.dapc(P.scores, nPCda, grp, G); S.daNames = names;
  const out = [];
  const xt = S.km[K - 1], ct = D.popNames.map((p, pi) => [p, ...[...Array(K).keys()].map(k => D.popIdx[pi].filter(i => xt.assign[i] === k).length)]);
  out.push(table('kmeans_crosstab', `k-means clusters (K = ${K}) × populations — number of individuals`, ['Population', ...[...Array(K).keys()].map(i => 'Cluster ' + (i + 1))], ct, { max: 300, note: `Within-cluster sum of squares ${f(xt.wss, 3)}; BIC ${f(xt.bic, 2)}; ${S.nPC} principal components.` }));
  S.tables.kmeans_BIC = { title: 'k-means BIC', sheet: 'kmeans_BIC', head: ['K', 'within_SS', 'BIC'], rows: S.km.map((k, i) => [i + 1, k.wss, k.bic]) };
  if (!da) { $('daTitle').textContent = 'DAPC not available'; out.push('<div class="note warn">DAPC could not be computed for this grouping (a group is empty, or too many components for the number of individuals). Reduce the number of retained components.</div>'); $('clusTabs').innerHTML = out.join(''); return; }
  $('daTitle').innerHTML = `DAPC — ${prior === 'pop' ? 'populations as groups' : 'k-means clusters as groups'} · ${da.nPC} PCs, ${da.nDA} discriminant function(s) · ${(100 * da.assignProp).toFixed(1)}% reassigned to own group`;
  const y = da.nDA > 1 ? da.coords.map(c => c[1]) : da.coords.map((_, i) => grp[i] + 0.6 * ((i * 0.6180339887) % 1) - 0.3);
  chart('daChart', { type: 'scatter', data: { datasets: scatterSets(da.coords.map(c => c[0]), y, grp, names, D.ids) }, options: chartOpts(`LD1 (${da.daVar[0].toFixed(1)}%)`, da.nDA > 1 ? `LD2 (${da.daVar[1].toFixed(1)}%)` : 'group (jittered)', { plugins: Object.assign({ legend: { position: 'right', labels: { color: cssv('--text'), usePointStyle: true, font: { size: 10 } } } }, tipId) }) });
  const ord = [...Array(D.n).keys()].sort((a, b) => D.pop[a] - D.pop[b] || da.assign[a] - da.assign[b] || Math.max(...da.posterior[b]) - Math.max(...da.posterior[a]));
  chart('memChart', { type: 'bar', data: { labels: ord.map(i => D.ids[i] + ' — ' + D.popNames[D.pop[i]]), datasets: names.map((nm, g) => ({ label: nm, data: ord.map(i => da.posterior[i][g]), backgroundColor: PAL[g % PAL.length], borderWidth: 0, categoryPercentage: 1, barPercentage: 1 })) },
    options: chartOpts('', 'Posterior probability', { plugins: { legend: { labels: { color: cssv('--text'), font: { size: 10 }, boxWidth: 10 } } }, scales: { x: { stacked: true, ticks: { display: false }, grid: { display: false } }, y: { stacked: true, min: 0, max: 1, ticks: { color: cssv('--muted') }, grid: { color: cssv('--grid') } } } }) });
  const mm = D.popNames.map((p, pi) => [p, ...names.map((_, g) => MQ.mean(D.popIdx[pi].map(i => da.posterior[i][g])))]);
  out.push(table('DAPC_mean_membership', 'Mean DAPC posterior membership probability per population', ['Population', ...names.map(esc)], mm, { dec: [0, ...names.map(() => 3)], max: 300, note: 'Posterior probabilities come from the linear discriminant model (group priors = group proportions). They quantify how clearly an individual falls in a group <i>given the grouping supplied</i>; they are not estimates of admixture and, for informed groups, they are optimistic because the same individuals define the groups.' }));
  S.tables.DAPC_individuals = { title: 'DAPC individuals', sheet: 'DAPC_individuals', head: ['Individual', 'Population', 'Group_supplied', 'Group_assigned', ...[...Array(da.nDA).keys()].map(i => 'LD' + (i + 1)), ...names.map(n => 'P_' + n)], rows: D.ids.map((id, i) => [id, D.popNames[D.pop[i]], names[grp[i]], names[da.assign[i]], ...Array.from(da.coords[i]), ...Array.from(da.posterior[i])]) };
  $('clusTabs').innerHTML = out.join('');
}

function rCharts() {
  const D = S.D, L = S.desc.locus, P = S.desc.perPop;
  $('tab-charts').innerHTML = `<div class="grid g2"><div class="panel pad"><div class="row between"><p class="b small">Heterozygosity per locus (pooled)</p>${pngBtn('heChart')}</div><div style="height:280px"><canvas id="heChart"></canvas></div></div>
    <div class="panel pad"><div class="row between"><p class="b small">Diversity per population</p>${pngBtn('popChart')}</div><div style="height:280px"><canvas id="popChart"></canvas></div></div></div>
    <div class="panel pad"><div class="row between"><div class="row"><p class="b small">Allele frequencies by population — locus</p><select id="afLoc">${D.loci.map((l, i) => `<option value="${i}">${esc(l)}</option>`).join('')}</select></div>${pngBtn('afChart')}</div><div style="height:300px"><canvas id="afChart"></canvas></div></div>`;
  const bar = (label, data, i) => ({ label, data, backgroundColor: PAL[i] + 'cc' });
  chart('heChart', { type: 'bar', data: { labels: L.map(l => l.locus), datasets: [bar('uHE', L.map(l => l.uHe), 0), bar('HO', L.map(l => l.Ho), 1)] }, options: chartOpts('', 'Heterozygosity', { scales: { y: { min: 0, max: 1, ticks: { color: cssv('--muted') }, grid: { color: cssv('--grid') } }, x: { ticks: { color: cssv('--muted'), maxRotation: 60 }, grid: { display: false } } } }) });
  chart('popChart', { type: 'bar', data: { labels: P.map(p => p.pop), datasets: [bar('uHE', P.map(p => p.uHe), 0), bar('HO', P.map(p => p.Ho), 1), bar('FIS', P.map(p => p.Fis), 2)] }, options: chartOpts('', '', { scales: { x: { ticks: { color: cssv('--muted'), maxRotation: 60 }, grid: { display: false } }, y: { ticks: { color: cssv('--muted') }, grid: { color: cssv('--grid') } } } }) });
  const af = () => { const l = +$('afLoc').value, k = D.alleles[l].length, C = MQ.counts(D, l, D.pop, D.K);
    chart('afChart', { type: 'bar', data: { labels: D.alleles[l], datasets: D.popNames.map((p, g) => ({ label: p, data: [...Array(k).keys()].map(a => C.n[g] ? C.cnt[g * k + a] / (2 * C.n[g]) : 0), backgroundColor: PAL[g % PAL.length] })) }, options: chartOpts('Allele (size)', 'Frequency within population', {}) }); };
  $('afLoc').onchange = af; af();
  const rows = []; for (let l = 0; l < D.L; l++) { const k = D.alleles[l].length, C = MQ.counts(D, l, D.pop, D.K); for (let a = 0; a < k; a++) rows.push([D.loci[l], D.alleles[l][a], ...D.popNames.map((_, g) => C.n[g] ? C.cnt[g * k + a] / (2 * C.n[g]) : NaN)]); }
  S.tables.allele_frequencies = { title: 'Allele frequencies', sheet: 'Allele_frequencies', head: ['Locus', 'Allele', ...D.popNames], rows };
}

function rGuide() {
  $('tab-guide').innerHTML = `<div class="guide">
  <h3 style="margin-top:0">Who this is for</h3><p>Conservation practitioners, breed-society and hatchery managers, monitoring programmes and students who hold a table of scored microsatellite genotypes and need the standard, reproducible summary of it — without installing or programming anything. It complements, and does not replace, R (adegenet, hierfstat, pegas), Genepop, Arlequin, GenAlEx or STRUCTURE; the <b>Genepop</b> and <b>STRUCTURE</b> buttons export the current selection for those programs.</p>
  <h3>Five steps</h3><ol><li><b>Load</b> a .csv/.tsv/.xlsx file (or the simulated example). Check the counts of individuals, loci and populations and any warnings.</li>
  <li><b>Run</b> with the defaults (999 permutations, Benjamini–Hochberg correction, fixed seed).</li>
  <li><b>Read “Data quality” first.</b> A locus out of HWE in most populations, in LD with another locus, or with a locus-specific heterozygote deficit is a candidate for exclusion; a population out of HWE at most loci points to inbreeding or mixed samples.</li>
  <li><b>Exclude and re-run</b> by clicking loci or populations in panel 2. Report both runs if conclusions change.</li>
  <li><b>Export</b> “Report .xlsx”. Its Run_info sheet records version, file, selection, settings and seed, so next year’s monitoring sample can be analysed identically.</li></ol>
  <h3>What is computed, and where it comes from</h3>
  <div class="tscroll" style="max-height:none"><table class="dtable"><thead><tr><th>Output</th><th>Definition</th><th>Primary source</th><th>Reference implementation used for validation</th></tr></thead><tbody>
  ${[['N<sub>a</sub>, N<sub>e</sub>, I', 'count; 1/Σp²; −Σp ln p', 'Kimura &amp; Crow 1964; Shannon', 'adegenet'],
    ['H<sub>O</sub>, H<sub>E</sub>, uH<sub>E</sub>', 'heterozygote proportion; 1−Σp²; 2N/(2N−1)·H<sub>E</sub>', 'Nei 1973, 1978', 'adegenet, pegas'],
    ['PIC', '1−Σp²−ΣΣ2p<sub>i</sub>²p<sub>j</sub>²', 'Botstein et al. 1980', '—'],
    ['Allelic richness', 'rarefaction to the smallest number of gene copies', 'Hurlbert 1971; El Mousadik &amp; Petit 1996', 'hierfstat'],
    ['HWE', 'χ² with k(k−1)/2 df; Monte Carlo exact (probability) test', 'Guo &amp; Thompson 1992', 'pegas, Genepop'],
    ['Linkage disequilibrium', 'G test on genotype tables, permutation, Fisher across populations', 'Raymond &amp; Rousset 1995', 'Genepop'],
    ['Null alleles', '(uH<sub>E</sub>−H<sub>O</sub>)/(1+uH<sub>E</sub>)', 'Brookfield 1996', '—'],
    ['H<sub>S</sub>, H<sub>T</sub>, F<sub>IS</sub>, G<sub>ST</sub>', 'sample-size-corrected gene diversities', 'Nei &amp; Chesser 1983; Nei 1987', 'hierfstat'],
    ['G″<sub>ST</sub>, Jost’s D', 'standardised differentiation; allelic differentiation', 'Meirmans &amp; Hedrick 2011; Jost 2008', 'hierfstat, mmod'],
    ['f, θ, F', 'variance-component F-statistics', 'Weir &amp; Cockerham 1984', 'hierfstat, pegas'],
    ['Confidence intervals', 'percentile bootstrap over loci', 'Weir &amp; Cockerham 1984', 'hierfstat'],
    ['θ tests', 'permutation of individuals among populations', 'Excoffier et al. 1992', '—'],
    ['Multiple testing', 'Bonferroni; Benjamini–Hochberg; Benjamini–Yekutieli', 'Benjamini &amp; Hochberg 1995; Narum 2006', 'R p.adjust'],
    ['PCA', 'centred allele frequencies, eigen-decomposition', 'Jombart 2008', 'adegenet/ade4'],
    ['k-means + BIC, DAPC', 'clusters on PCs; discriminant analysis of PCs', 'Jombart et al. 2010', 'adegenet']].map(r => `<tr><td class="name">${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td></tr>`).join('')}</tbody></table></div>
  <h3>Limits you should know</h3><ul><li>Diploid, codominant markers only. Haploid, polyploid and mixed-ploidy data are not supported.</li>
  <li>No Bayesian or likelihood model is fitted: no STRUCTURE/ADMIXTURE-type ancestry, no AMOVA, no effective population size, no relatedness or parentage.</li>
  <li>Bootstrap intervals over loci need many loci (ideally ≥ 10); with few loci they are too narrow or undefined.</li>
  <li>Monte Carlo p values vary slightly with the seed; the smallest attainable value is 1/(permutations + 1).</li>
  <li>Private-allele counts are not corrected for sample size.</li><li>Tested with up to 2 000 individuals × 50 loci; see the paper for run times.</li></ul>
  <h3>How to cite</h3><p>Cite the MicroQuick paper and version (${MQ.VERSION}), and the primary source of every statistic you report.</p></div>`;
}

// ── exports ────────────────────────────────────────────────────────────────
function runInfo() { const D = S.D, P = S.parsed, st = S.set;
  return [['MicroQuick version', MQ.VERSION], ['Run date', S.runAt.toISOString()], ['Input file', S.fileName], ['Individuals analysed', D.n], ['Loci analysed', D.L], ['Populations analysed', D.K],
    ['Populations', D.popNames.join('; ')], ['Loci', D.loci.join('; ')], ['Populations excluded', S.allPops.filter(p => !S.sel.pops.has(p)).join('; ') || 'none'], ['Loci excluded', P.lociNames.filter(l => !S.sel.loci.has(l)).join('; ') || 'none'],
    ['Half-scored genotypes set to missing', P.warn.partial], ['Unreadable genotypes set to missing', P.warn.unreadable], ['Cells with >2 alleles set to missing', P.warn.polyploid],
    ['Permutations', st.perm], ['Bootstrap replicates', st.boot], ['Multiple-testing correction', CORR[st.corr]], ['Alpha', st.alpha], ['Random seed', st.seed],
    ['PCs retained for clustering/DAPC', S.nPC], ['Rarefaction size (gene copies)', S.desc.rareG], ['Browser', navigator.userAgent], ...Object.entries(S.timing).map(([k, v]) => ['Time ms: ' + k, Math.round(v)])]; }
function xlsx() { if (!S.D) return; const wb = XLSX.utils.book_new(), used = {};
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Item', 'Value'], ...runInfo()]), 'Run_info');
  const m = S.desc.multi; if (m && S.D.K > 1) XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Statistic', 'Estimate', 'CI_low', 'CI_high', 'p'], ...['f', 'theta', 'capF', 'Fis', 'Gst', 'Gst2', 'D'].map(k => [({ f: 'FIS f (W&C)', theta: 'FST theta (W&C)', capF: 'FIT F (W&C)', Fis: 'FIS (Nei)', Gst: 'GST (Nei)', Gst2: "G''ST", D: 'Jost D' })[k], m[k], S.ci[k] ? S.ci[k][0] : '', S.ci[k] ? S.ci[k][1] : '', k === 'theta' && ok(S.globalP) ? S.globalP : ''])]), 'Global');
  const clean = v => (v === null || v === undefined || (typeof v === 'number' && !isFinite(v))) ? '' : v;
  for (const id in S.tables) { const t = S.tables[id]; let nm = (t.sheet || id).slice(0, 31); if (used[nm]) continue; used[nm] = 1; XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([t.head, ...t.rows.map(r => r.map(clean))]), nm); }
  XLSX.writeFile(wb, 'MicroQuick_report.xlsx'); }
function genepop() { if (S.D) download('MicroQuick_genepop.txt', MQ.toGenepop(S.D, 'MicroQuick export of ' + S.fileName)); }
function structureFile() { if (S.D) download('MicroQuick_structure.txt', MQ.toStructure(S.D)); }
function template(kind) {
  const head = ['individual', 'Population', 'Locus1(1)', 'Locus1(2)', 'Locus2(1)', 'Locus2(2)', 'Locus3(1)', 'Locus3(2)'];
  const rows = [['Ind_01', 'PopA', 148, 150, 201, 201, 177, 183], ['Ind_02', 'PopA', 150, 150, 201, 205, 177, 177], ['Ind_03', 'PopA', 148, 152, 203, 205, '', ''], ['Ind_04', 'PopB', 152, 154, 205, 207, 181, 185], ['Ind_05', 'PopB', 150, 154, 0, 0, 179, 185], ['Ind_06', 'PopB', 148, 150, 203, 207, 177, 181]];
  if (kind === 'csv') { download('MicroQuick_template.csv', [head, ...rows].map(r => r.join(',')).join('\n') + '\n', 'text/csv'); return; }
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([head, ...rows]), 'Genotypes');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['MicroQuick input template'], ['One row per individual; two columns per locus named Locus(1) and Locus(2).'], ['Alleles are numbers (fragment size in bp or repeat count). Diploid data only.'], ['Missing genotype: leave both cells empty, or enter 0, NA, ? or -9. A genotype with one allele missing is treated as missing.'], ['"individual" and "Population" columns are optional but recommended. Only the first sheet is read.']]), 'README');
  XLSX.writeFile(wb, 'MicroQuick_template.xlsx'); }
function toggleTheme() { const d = document.documentElement.classList.toggle('dark'); $('themeBtn').textContent = d ? 'Light mode' : 'Dark mode'; if (S.D) { const t = S.tab; renderAll(); switchTab(t); } }

// ── wiring ─────────────────────────────────────────────────────────────────
$('verTag').textContent = 'v' + MQ.VERSION;
$('fileInput').addEventListener('change', e => loadFile(e.target.files[0]));
const dz = $('drop'); ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); })); dz.addEventListener('drop', e => loadFile(e.dataTransfer.files[0]));
return { S, run, switchTab, csv, tableCSV, png, xlsx, genepop, structureFile, template, toggleTheme, loadExample, loadText, loadFile, recluster, runInfo };
})();
