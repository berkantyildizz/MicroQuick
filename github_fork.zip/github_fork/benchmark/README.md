# Simulated benchmark data set

`SSR_Denizli_Gerze_simulated.xlsx` — 125 individuals, 12 loci, 5 subpopulations.

**This data set is simulated. No bird was genotyped to produce it.** It is the example file built into
MicroQuick and one of the twelve data sets used to validate it. It must not be cited as evidence about Denizli
or Gerze chickens.

Simulated data cannot show that software is *correct* — that is established by comparing its output with
reference software on the same input (see `../validation/`). What a simulation adds is a known structure, so
that one can see whether the analyses point in the right direction.

| Design element | Value | Basis |
|---|---|---|
| Sampling | 3 Denizli + 2 Gerze subpopulations × 25 birds | Kaya & Yıldız (2008) *Biochem Genet* 46:480–491 |
| Ancestral allele frequencies | Dirichlet(0.68, …) over 4–14 alleles per locus | — |
| Divergence ancestral → breed | Balding–Nichols, θ = 0.07 (Denizli), 0.30 (Gerze) | lower diversity reported for Gerze (He 0.475 vs 0.656) |
| Divergence breed → subpopulation | Balding–Nichols, θ = 0.045 | — |
| Loss of rare alleles (q < 0.08) | probability 0.10 / 0.45 (breed step), 0.05 (subpopulation step) | — |
| Within-subpopulation inbreeding | 0.18, 0.20, 0.17 (Denizli 1–3); 0.24, 0.22 (Gerze 1–2) | FIS ≈ 0.20 in Özdemir & Cassandro (2018) *Ital J Anim Sci* 17:312–320 |
| Missing genotypes | 2.5% | — |
| Seed | 20260818 (NumPy `default_rng`) | — |

Allele sizes lie on a 2 bp grid inside a size window per locus (listed in the README sheet of the spreadsheet).

```
python3 simulate_denizli_gerze.py      # needs numpy and openpyxl
```
