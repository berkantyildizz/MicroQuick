# MicroQuick user guide

This guide assumes no programming and no prior use of population-genetics software.

## 1. Before you start: what MicroQuick needs

A table in which each row is one animal or plant and the columns hold its microsatellite genotype: two allele
sizes per locus. Add a `Population` column if the individuals come from different sites, breeds, cohorts or
years — everything that compares groups depends on it. Add an `individual` column so that points in the plots
can be identified.

Use the **Template** buttons to get an empty table in the right layout.

## 2. Loading

Drop the file on the dashed box. Panel 2 then states what was understood. Check three things:

* **Counts.** Are the numbers of individuals, loci and populations what you expect? A locus count that is half
  or double the true one means the column headers were not recognised as pairs — name them `Locus(1)`, `Locus(2)`.
* **Warnings.** "Half-scored genotypes" are cells where one allele is present and the other empty. They are
  treated as missing. If there are many, the file probably codes homozygotes with a single value; fill in both.
* **Small populations.** Fewer than ten individuals gives very uncertain estimates and tests with almost no power.

## 3. Settings (the defaults are sensible)

| Setting | Default | When to change |
|---|---|---|
| Permutations | 999 | 9 999 for a final report; "none" for a quick look at a large file |
| Bootstrap replicates | 999 | 4 999 for a final report |
| Multiple-testing correction | Benjamini–Hochberg FDR | Bonferroni if your reporting standard asks for it |
| α | 0.05 | — |
| Random seed | 20260101 | keep it; write it down if you change it |

## 4. Reading the Data quality tab

**Hardy–Weinberg table.** Each cell is the p value of an exact test for one locus in one population. Red =
significant after correction for the number of tests. Read the table by rows and columns, not cell by cell
(Waples 2015):

| Pattern | Likely meaning | What to do |
|---|---|---|
| One locus red in most populations, heterozygote deficit (▾) | null allele or scoring problem at that locus | re-check scoring; run again without the locus and compare |
| One population red at most loci, deficit | inbreeding, or the "population" mixes two groups (Wahlund effect), or relatives were sampled | check sampling; look at PCA / clustering within that population |
| Scattered red cells, no pattern | chance, or weak effects | report the proportion; no action |
| Excess (▴) at many loci | very few breeders, or clonal/duplicate samples | check for duplicated individuals |

The "All pooled" column is the test on all individuals together. It rejects whenever populations differ and is
*not* evidence of a problem.

**Linkage disequilibrium.** Each row is a pair of loci. A pair that is significant after correction across
several populations may be physically linked; analyses that assume independent loci (bootstrap intervals,
assignment) then count the same information twice. A pair significant in one population only is more likely
due to that population's history (bottleneck, admixture, family structure).

**Null-allele table.** The number is the null-allele frequency that would explain the heterozygote deficit *if*
nothing else caused it. Inbreeding causes a deficit at every locus; a null allele causes it at one. Only a
locus-specific, repeatable deficit should be read as a null allele.

## 5. Diversity

*Populations* tab: `Ar` (allelic richness) is the number of alleles expected in a sample as small as your
smallest one, so it can be compared across populations of different size; raw `Na` cannot. `uHe` is the
expected heterozygosity corrected for sample size. `FIS` above zero means fewer heterozygotes than expected.

For monitoring, the quantities to track from year to year are `Ar`, `uHe`, `Ho` and `FIS` per population —
computed with the same loci, the same rarefaction size and the same settings (see `Run_info`).

## 6. Differentiation

`θ` (Weir & Cockerham's FST) and `GST` say how much of the variation lies between populations; with highly
variable markers they cannot reach 1 even when populations share no alleles, so "0.05 = little, 0.15 = great"
rules do not apply to microsatellites. `G″ST` and Jost's `D` are scaled from 0 (same alleles, same
frequencies) to 1 (no shared alleles). Report an FST-type and a D-type measure together, each with its
confidence interval, and the permutation p value.

A confidence interval that includes zero, or a non-significant p value, means the data cannot distinguish the
two populations — not that they are the same.

The optional "Nem equivalent" converts θ into the number of migrants per generation under an idealised model
(equal-sized islands, equal migration, equilibrium). Use it, if at all, as a re-expression of θ, never as a
measurement of current movement.

## 7. Structure

*PCA* shows individuals in the two directions of greatest genetic variation. Population labels only colour the
points; they do not influence the positions.

*Clustering & DAPC* then asks two different questions:

1. **Without labels** — k-means for K = 1, 2, 3 …; the BIC curve shows how much each extra cluster helps. A
   clear elbow suggests a number of groups worth examining; a smooth curve means there are no discrete groups.
   The cross-table shows how the clusters relate to your populations.
2. **With labels** — DAPC with your populations as groups shows how well they can be told apart, and which
   individuals look like members of another population.

Compare both. Do not report the K with the lowest BIC as "the number of populations", and do not describe the
membership bars as admixture proportions. For those questions export the data (**STRUCTURE** button) and use a
model-based program.

## 8. Reporting checklist

* software version, date, seed, permutations, correction method (all in `Run_info`)
* loci or populations excluded, and why
* number of HWE and LD tests performed and significant after correction
* estimator names: "FST estimated as θ (Weir & Cockerham 1984)", "Jost's D", etc.
* confidence intervals and p values for every differentiation value that is interpreted

## 9. Troubleshooting

| Symptom | Cause |
|---|---|
| "No locus columns were recognised" | headers are missing or not in pairs |
| Half the expected number of loci | single-column `a/b` format mixed with two-column format |
| Many "unreadable" genotypes | letters in allele cells; alleles must be numbers |
| DAPC not available | more components requested than individuals minus groups; lower the number |
| Slow run | reduce permutations, or exclude populations you do not need |
