#!/usr/bin/env python3
"""Writes the validation data sets in the input formats of Arlequin 3.5 (.arp) and GenAlEx 6.5 (.xlsx).
Usage: python3 validation/external/make_inputs.py   (from the repository root; needs openpyxl)"""
import csv, os, re, sys
from collections import OrderedDict
OUT = "validation/external/inputs"; os.makedirs(OUT, exist_ok=True)
SETS = {"benchmark_simulated": "data/benchmark_simulated.csv", "nancycats": "data/nancycats.csv", "microbov": "data/microbov.csv",
        "S1_balanced_reference": "data/scenarios/S1_balanced_reference.csv",
        "nancycats_no_fca45": "validation/external/inputs/nancycats_no_fca45.csv"}   # fca45 is untyped in colony P17

def read(path):
    rows = list(csv.reader(open(path, encoding="utf-8")))
    head, data = rows[0], rows[1:]
    loci = [h[:-3] for h in head if h.endswith("(1)")]
    pops = OrderedDict()
    for r in data:
        rec = dict(zip(head, r)); g = []
        for l in loci:
            a, b = rec[l + "(1)"].strip(), rec[l + "(2)"].strip()
            g.append((a, b) if a and b and a not in ("0", "?") and b not in ("0", "?") else (None, None))
        pops.setdefault(rec["Population"], []).append((rec["individual"], g))
    return loci, pops

def arp(name, loci, pops):
    safe = lambda s: re.sub(r"[^A-Za-z0-9_]", "_", s)
    L = ["[Profile]", f'  Title="{name} (MicroQuick validation)"', f"  NbSamples={len(pops)}", "  DataType=MICROSAT", "  GenotypicData=1",
         "  LocusSeparator=WHITESPACE", "  GameticPhase=0", "  MissingData='?'", "  RecessiveData=0", "", "[Data]", "  [[Samples]]"]
    for p, inds in pops.items():
        L += [f'    SampleName="{safe(p)}"', f"    SampleSize={len(inds)}", "    SampleData={"]
        for k, (iid, g) in enumerate(inds):
            a = " ".join(x if x else "?" for x, _ in g); b = " ".join(y if y else "?" for _, y in g)
            L += [f"{safe(iid)}_{k+1} 1 {a}", f"    {b}"]
        L += ["    }", ""]
    L += ["  [[Structure]]", f'    StructureName="{name}"', "    NbGroups=1", "    Group={"] + [f'      "{safe(p)}"' for p in pops] + ["    }", ""]
    open(f"{OUT}/{name}.arp", "w", newline="\n").write("\n".join(L) + "\n")

def genalex(name, loci, pops):
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Data"
    n = sum(len(v) for v in pops.values())
    ws.append([len(loci), n, len(pops)] + [len(v) for v in pops.values()])
    ws.append([name, "", ""] + list(pops.keys()))
    hdr = ["Sample", "Pop"]
    for l in loci: hdr += [l, ""]
    ws.append(hdr)
    for p, inds in pops.items():
        for iid, g in inds:
            row = [iid, p]
            for a, b in g: row += [int(a) if a else 0, int(b) if b else 0]
            ws.append(row)
    wb.save(f"{OUT}/{name}_genalex.xlsx")

for name, path in SETS.items():
    loci, pops = read(path); arp(name, loci, pops); genalex(name, loci, pops)
    print(name, len(loci), "loci", len(pops), "pops", sum(len(v) for v in pops.values()), "ind")
