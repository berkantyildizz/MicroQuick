# Comparison with GenAlEx 6.51b2

GenAlEx (Peakall & Smouse 2012) is an Excel add-in in which every analysis is started from a dialog box,
so this comparison is run by hand. GenAlEx is not redistributed here; download `GenAlEx 6.51b2.xlam`
from the official site (https://biology-assets.anu.edu.au/GenAlEx/) and open it in Microsoft Excel.

Input workbooks in GenAlEx layout are in this folder (`benchmark_simulated_genalex.xlsx`,
`nancycats_genalex.xlsx`, `microbov_genalex.xlsx`). For each data set:

1. Open the add-in (enable macros), then open the data workbook with the `Data` sheet active.
2. **GenAlEx → Frequency**: accept the data parameters; tick **Het by Pop** → OK.
3. Back on `Data`: **GenAlEx → HWE**: accept the data parameters; **Summary** ticked → OK.
4. Back on `Data`: **GenAlEx → G-Statistics**: accept the data parameters; **Full** and
   **Summary by Locus** ticked, 0 permutations and bootstraps → OK.
5. Save the workbook as `.xlsx`.

The workbooks produced in this way for the manuscript are in `results/`. To compare them with MicroQuick:

```
python3 validation/external/compare_genalex.py benchmark_simulated validation/external/genalex/results/benchmark_simulated_genalex_results.xlsx
python3 validation/external/compare_genalex.py nancycats validation/external/genalex/results/nancycats_genalex_results.xlsx
```

The concordance tables are written to `validation/out/external/<name>_genalex_concordance.csv`.
