// Pairwise FST from a two-level AMOVA on gene copies (populations / gene copies within populations), with the
// "number of different alleles" distance, summed over loci: the definition Arlequin uses for its pairwise FST matrix.
// Used only to explain the difference between Arlequin's pairwise FST and Weir & Cockerham's theta.
// Usage: node validation/external/amova_gene_level.js <csv>
const MQ = require('../../src/microquick_core.js'), fs = require('fs');
const { rows } = MQ.parseDelimited(fs.readFileSync(process.argv[2], 'utf8')); const P = MQ.parseGenotypes(rows[0], rows.slice(1));
const D = MQ.encode(P.records, P.lociNames), out = [];
for (let i = 0; i < D.K; i++) for (let j = i + 1; j < D.K; j++) {
  let sa = 0, sb = 0;
  for (let l = 0; l < D.L; l++) {
    const k = D.alleles[l].length, c = [new Float64Array(k), new Float64Array(k)], G = [0, 0];
    [i, j].forEach((p, q) => D.popIdx[p].forEach(x => { if (D.A[l][x] >= 0) { c[q][D.A[l][x]]++; c[q][D.B[l][x]]++; G[q] += 2; } }));
    const Gt = G[0] + G[1]; if (!G[0] || !G[1]) continue;
    const ssd = (cnt, g) => (g * g - cnt.reduce((s, v) => s + v * v, 0)) / 2 / g;
    const tot = c[0].map((v, a) => v + c[1][a]), sst = ssd(tot, Gt), ssw = ssd(c[0], G[0]) + ssd(c[1], G[1]);
    const msw = ssw / (Gt - 2), msa = (sst - ssw) / 1, n0 = Gt - (G[0] * G[0] + G[1] * G[1]) / Gt;
    sa += (msa - msw) / n0; sb += msw;
  }
  out.push([D.popNames[i], D.popNames[j], sa / (sa + sb)]);
}
console.log(JSON.stringify(out));
