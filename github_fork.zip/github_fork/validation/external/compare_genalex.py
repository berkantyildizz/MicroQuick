#!/usr/bin/env python3
"""Compares GenAlEx 6.51b2 output with MicroQuick for the same data set.
GenAlEx writes its results as new worksheets into the data workbook; this script finds the per-population
heterozygosity table (header: Pop, Locus, N, Na, Ne, I, Ho, He, uHe, F) and the Hardy-Weinberg chi-square table
(rows Pop / Locus / ChiSq / DF / Prob, one column per locus x population) wherever they are.
Usage: python3 validation/external/compare_genalex.py <dataset>   (reads validation/external/genalex/<dataset>_genalex.xlsx)"""
import json, sys, math, csv, os
from openpyxl import load_workbook
name = sys.argv[1]
src = sys.argv[2] if len(sys.argv) > 2 else f"validation/external/genalex/{name}_genalex.xlsx"
wb = load_workbook(src, data_only=True)
mq = json.load(open(f"validation/out/{name}.json"))
pops, loci = mq["pops"], mq["loci"]
num = lambda v: float(v) if isinstance(v, (int, float)) else (float(v) if isinstance(v, str) and v.strip().replace(".", "", 1).replace("-", "", 1).isdigit() else None)
het, hwe = {}, {}
for ws in wb.worksheets:
    rows = [list(r) for r in ws.iter_rows(values_only=True)]
    for i, r in enumerate(rows):
        s = [str(c).strip() if c is not None else "" for c in r]
        if "uHe" in s and "Ho" in s and "Locus" in s and "Pop" in s:          # heterozygosity by population
            col = {h: s.index(h) for h in ["Pop", "Locus", "N", "Na", "Ne", "I", "Ho", "He", "uHe", "F"] if h in s}
            cur = None
            for r2 in rows[i + 1:]:
                if r2 is None or all(c is None for c in r2): break      # the table ends at the first empty row
                if r2[col["Pop"]] not in (None, ""): cur = r2[col["Pop"]]   # GenAlEx writes the population only on its first row
                p, l = cur, r2[col["Locus"]]
                if p in (None, "") or l in (None, "") or str(l) in ("Mean", "SE", "Total"): continue
                het[(str(p), str(l))] = {h: num(r2[c]) for h, c in col.items() if h not in ("Pop", "Locus")}
        if "Pop" in s and "Locus" in s and "DF" in s and "Prob" in s and any(h.lower().startswith("chi") for h in s):   # HWS sheet: one test per row
            col = {h: s.index(h) for h in s if h}; cs = next(h for h in s if h.lower().startswith("chi"))
            for r2 in rows[i + 1:]:
                if not r2 or r2[col["Pop"]] in (None, "") or r2[col["Locus"]] in (None, ""): continue
                hwe[(str(r2[col["Pop"]]), str(r2[col["Locus"]]))] = dict(df=num(r2[col["DF"]]), p=num(r2[col["Prob"]]), chi2=num(r2[col[cs]]))
# ---- G-statistics (MenuGStats): per-locus table on sheet "Gst", by-locus summary on "GstS" ----
gs, gsb = {}, {}
for ws in wb.worksheets:
    rows = [list(r) for r in ws.iter_rows(values_only=True)]
    for i, r in enumerate(rows):
        s = [str(c).strip() if c is not None else "" for c in r]
        if s[:2] == ["Locus", "Mean N"] and "cHs" in s:
            col = {h: k for k, h in enumerate(s) if h}
            for r2 in rows[i + 1:]:
                if not r2 or r2[0] in (None, "") or str(r2[0]) in ("SE", "CIU", "CIL"): break
                gs[str(r2[0])] = {h: num(r2[k]) for h, k in col.items() if h != "Locus"}
        if s and s[0] == "" and len(s) > 2 and "Tot" in s and i + 1 < len(rows) and str(rows[i + 1][0]).strip() == "Fis" and not gsb:
            for r2 in rows[i + 1:i + 20]:
                if r2 and str(r2[0]).startswith("Probabilities"): break
                if not r2 or r2[0] in (None, ""): continue      # GenAlEx leaves blank rows inside this block
                gsb[str(r2[0]).strip()] = {s[k]: num(r2[k]) for k in range(1, len(s)) if s[k]}
print(f"{name}: GenAlEx heterozygosity rows {len(het)}, HWE tests {len(hwe)}, G-statistics loci {len(gs)}")
out, cmp = [], {}
def add(stat, a, b):
    if a is None or b is None or (isinstance(a, float) and math.isnan(a)): return
    cmp.setdefault(stat, []).append(abs(a - b))
for li, l in enumerate(loci):
    for pi, p in enumerate(pops):
        c = mq["cells"][li][pi]; g = het.get((p, l)); h = mq["hwe"]["byPop"][li][pi]; x = hwe.get((p, l))
        if g:
            add("N (typed individuals)", c["N"], g.get("N")); add("Na", c["Na"], g.get("Na")); add("Ne", c["Ne"], g.get("Ne")); add("Shannon I", c["I"], g.get("I"))
            add("Ho", c["Ho"], g.get("Ho")); add("He", c["He"], g.get("He")); add("uHe", c["uHe"], g.get("uHe"))
            if c["He"] and g.get("F") is not None: add("F = 1 - Ho/He", 1 - c["Ho"] / c["He"], g.get("F"))
        if x and h.get("chi2") is not None:
            add("HWE chi-square statistic", h["chi2"], x["chi2"]); add("HWE degrees of freedom", h["df"], x["df"]); add("HWE chi-square p value", h["pChi"], x["p"])
for li, l in enumerate(loci):
    m, g, b = mq["locus"][li], gs.get(l), {k: v.get(l) for k, v in gsb.items()}
    if g:
        add("Ho, mean over populations (G-statistics)", m.get("HoS"), g.get("Mean Ho")); add("Hs, Nei-Chesser corrected (cHs)", m.get("Hs"), g.get("cHs")); add("Ht, Nei-Chesser corrected (cHt)", m.get("Ht"), g.get("cHt"))
        add("Gis (FIS from corrected Hs)", m.get("Fis"), g.get("Gis")); add("GST (Nei, corrected)", m.get("Gst"), g.get("Gst"))
        add("G'ST (Nei)", m.get("GstP"), g.get("G'stN")); add("G''ST", m.get("Gst2"), g.get("G''st"))
    if b.get("G'stH") is not None:
        add("G'ST (Hedrick)", m.get("GstH"), b.get("G'stH")); add("Jost D (Dest)", m.get("D"), b.get("Dest"))
if gsb:
    mm = mq["multi"]
    for k, gk in (("Fis", "Gis"), ("Gst", "Gst"), ("GstP", "G'stN"), ("GstH", "G'stH"), ("Gst2", "G''st"), ("D", "Dest")):
        add("Multilocus (Tot) " + gk, mm.get(k), gsb.get(gk, {}).get("Tot"))
rows = [[name, k, "GenAlEx 6.51b2", len(v), max(v), sum(v) / len(v)] for k, v in cmp.items()]
for r in rows: print(f"  {r[1]:28s} n={r[3]:4d}  max|diff|={r[4]:.2e}  mean={r[5]:.2e}")
os.makedirs("validation/out/external", exist_ok=True)
with open(f"validation/out/external/{name}_genalex_concordance.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["dataset", "statistic", "reference", "n", "max_abs_diff", "mean_abs_diff"]); w.writerows(rows)
