#!/usr/bin/env python3
"""Compares Arlequin 3.5.2.2 (arlecore) results with MicroQuick for the same data set.
Reads validation/out/external/arlequin/<name>.res/<name>.xml and validation/out/<name>.json (or scenarios/<name>.json).
Usage: python3 validation/external/compare_arlequin.py <name>"""
import json, re, sys, os, csv, math
name = sys.argv[1]
xml = open(f"validation/out/external/arlequin/{name}.res/{name}.xml", encoding="latin-1").read()
jp = f"validation/out/{name}.json"
for jp in (f"validation/out/{name}.json", f"validation/out/scenarios/{name}.json", f"validation/out/external/{name}.json"):
    if os.path.exists(jp): break
mq = json.load(open(jp))
pops, loci, L, K = mq["pops"], mq["loci"], len(mq["loci"]), len(mq["pops"])
num = r"(-?\d+\.?\d*(?:[eE][-+]?\d+)?)"

# ---- per-sample blocks: standard diversity indices, HWE, LD -------------------------------------------
blocks = re.split(r"== Sample : \s*", xml)[1:]
arl = {}
for b in blocks:
    p = b.split("\n", 1)[0].strip(); d = arl.setdefault(p, {"div": {}, "hwe": {}, "ld": {}})
    m = re.search(r"Locus#\s+copies\s+alleles.*?\n-+\n(.*?)\n-+", b, flags=re.S)
    if m:
        for line in m.group(1).split("\n"):
            f = line.split()
            if len(f) >= 5 and f[0].isdigit(): d["div"][int(f[0]) - 1] = dict(copies=float(f[1]), Na=float(f[2]), Ho=float(f[3]), He=float(f[4]))
    m = re.search(r"Locus\s+#Genot\s+Obs\.Het\.\s+Exp\.Het\.\s+P-value.*?\n-+\n(.*?)\n-+", b, flags=re.S)
    if m:
        for line in m.group(1).split("\n"):
            f = line.split()
            if len(f) >= 5 and f[0].isdigit():
                try: d["hwe"][int(f[0]) - 1] = dict(n=float(f[1]), Ho=float(f[2]), He=float(f[3]), p=float(f[4]), se=float(f[5]))
                except ValueError: pass
    for m in re.finditer(r"Pair\((\d+), (\d+)\)\s*\n.*?\n\s*Exact P=\s*" + num, b):
        d["ld"][(int(m.group(1)), int(m.group(2)))] = float(m.group(3))

# ---- locus-by-locus AMOVA and global F-statistics --------------------------------------------------------
amova = {}
m = re.search(r"AMOVA Results for polymorphic loci only:.*?FIT\s+P-value\s*\n(.*?)\n\s*\n", xml, flags=re.S)
if m:
    for line in m.group(1).split("\n"):
        f = line.split()
        if len(f) >= 19 and f[0].isdigit(): amova[int(f[0]) - 1] = dict(f=float(f[13]), theta=float(f[15]), F=float(f[17]))
glob = {k: float(v) for k, v in re.findall(r"\b(FIS|FST|FIT)\s*:\s*" + num, xml.split("Average F-Statistics over all loci")[-1][:400])}
boot = {}
for stat in ("FIT", "FST", "FIS"):
    m = re.search(stat + r" bootstrap percentile values.*?2\.5 %\s*:\s*" + num + r".*?97\.5 %\s*:\s*" + num, xml, flags=re.S)
    if m: boot[stat] = (float(m.group(1)), float(m.group(2)))
pw = {}
m = re.search(r"<PairFstMat[^>]*>(.*?)</PairFstMat>", xml, flags=re.S)
if m:
    for line in m.group(1).split("\n"):
        f = line.split()
        if f and f[0].isdigit() and len(f) > 1:
            i = int(f[0]) - 1
            for j, v in enumerate(f[1:i + 1]): pw[(j, i)] = float(v)
pwp = {}
m = re.search(r"<PairFstPvalMat[^>]*>(.*?)</PairFstPvalMat>", xml, flags=re.S)
if m:
    for line in m.group(1).split("\n"):
        f = line.split()
        if f and f[0].isdigit():
            i = int(f[0]) - 1
            for j, v in enumerate(f[1:i + 1]): pwp[(j, i)] = float(v.split("+")[0])

# ---- comparisons ----------------------------------------------------------------------------------------
res = {}
def add(stat, a, b, kind="same estimator"):
    if a is None or b is None or (isinstance(a, float) and math.isnan(a)) or (isinstance(b, float) and math.isnan(b)): return
    res.setdefault((stat, kind), []).append((a, b))
popidx = {re.sub(r"[^A-Za-z0-9_]", "_", p): i for i, p in enumerate(pops)}
for p, d in arl.items():
    pi = popidx[p]
    for li in range(L):
        c, h = mq["cells"][li][pi], mq["hwe"]["byPop"][li][pi]
        if li in d["div"]:
            add("Number of alleles (locus x population)", c["Na"], d["div"][li]["Na"]); add("Ho (locus x population)", c["Ho"], d["div"][li]["Ho"])
            add("Unbiased expected heterozygosity (locus x population)", c["uHe"], d["div"][li]["He"])
        if li in d["hwe"] and h.get("pExact") is not None:
            add("HWE exact p (locus x population)", h["pExact"], d["hwe"][li]["p"], "Monte Carlo vs Markov chain")
    for (i, j), p_arl in d["ld"].items():
        x = next((x for x in mq["ld"] if x["i"] == i and x["j"] == j), None)
        if x and x["byPop"][pi] is not None: add("LD p (locus pair x population)", x["byPop"][pi], p_arl, "different test")
for li, a in amova.items():
    l = mq["locus"][li]
    add("f (FIS) per locus", l.get("f"), a["f"]); add("theta (FST) per locus", l.get("theta"), a["theta"]); add("F (FIT) per locus", l.get("capF"), a["F"])
import subprocess
csvp = next(c for c in (f"data/{name}.csv", f"data/scenarios/{name}.csv", f"validation/external/inputs/{name}.csv") if os.path.exists(c))
mqm, mqci, sub = mq["multi"], mq["ci"], ""
if amova and len(amova) < L:   # Arlequin leaves out a locus that is untyped in a whole population; compare over the same loci
    o = json.loads(subprocess.run(["node", "validation/external/mq_subset.js", csvp, ",".join(str(i) for i in sorted(amova))], capture_output=True, text=True, check=True).stdout)
    mqm, mqci, sub = o["multi"], o["ci"], f" (same {len(amova)} loci)"
for k, mk in (("FIS", "f"), ("FST", "theta"), ("FIT", "capF")):
    if k in glob: add(f"Multilocus {k}{sub}", mqm[mk], glob[k])
    if k in boot and mqci.get(mk): add(f"95% CI limits of multilocus {k} (bootstrap over loci)", mqci[mk][0], boot[k][0], "Monte Carlo"); add(f"95% CI limits of multilocus {k} (bootstrap over loci)", mqci[mk][1], boot[k][1], "Monte Carlo")
import subprocess
gl = {(pops.index(a), pops.index(b)): v for a, b, v in json.loads(subprocess.run(["node", "validation/external/amova_gene_level.js", csvp], capture_output=True, text=True, check=True).stdout)}
gap = {pi for pi in range(K) if any(mq["cells"][l][pi]["N"] == 0 for l in range(L))}   # populations with a locus untyped throughout
hasmiss = {pi for pi, p in enumerate(mq["perPop"]) if p["missing"] > 0}
only_pairwise = name.endswith("_no_fca45")   # re-run without the untyped locus: used only for the pairwise comparison
if only_pairwise: res.clear()
for x in mq["pairwise"]:
    k = (x["i"], x["j"])
    if k not in pw: continue
    if x["i"] in gap or x["j"] in gap:
        add("Pairwise FST, pairs involving a population in which a locus is entirely untyped", x["theta"], pw[k], "missing-data handling differs")
        if k in pwp: add("Pairwise FST permutation p, pairs involving a population with an untyped locus", x["p"], pwp[k], "missing-data handling differs")
        continue
    add("Pairwise FST vs MicroQuick theta (individual level included)", x["theta"], pw[k], "estimator differs")
    if x["i"] in hasmiss or x["j"] in hasmiss:   # Arlequin's pairwise FST comes from a multilocus AMOVA; with missing genotypes it departs from the locus-by-locus sum (Arlequin manual 8.2.3)
        add("Pairwise FST vs gene-level AMOVA, pairs with missing genotypes", gl[k], pw[k], "estimator differs")
    else:
        add("Pairwise FST vs gene-level AMOVA (Arlequin's definition), pairs without missing genotypes", gl[k], pw[k])
    if k in pwp: add("Pairwise FST permutation p", x["p"], pwp[k], "Monte Carlo")
rows = []
for (stat, kind), v in res.items():
    d = [abs(a - b) for a, b in v]; n = len(v)
    same = sum((a < 0.05) == (b < 0.05) for a, b in v) if ("p" in stat.split() or stat.endswith(" p") or "p (" in stat) else None
    r = None
    if n > 2:
        ma, mb = sum(a for a, _ in v) / n, sum(b for _, b in v) / n
        sa, sb = math.sqrt(sum((a - ma) ** 2 for a, _ in v)), math.sqrt(sum((b - mb) ** 2 for _, b in v))
        r = sum((a - ma) * (b - mb) for a, b in v) / (sa * sb) if sa > 0 and sb > 0 else None
    rows.append([name, stat, "Arlequin 3.5.2.2", kind, n, max(d), sum(d) / n, r, f"same decision at alpha 0.05 in {same} of {n}" if same is not None else ""])
os.makedirs("validation/out/external", exist_ok=True)
with open(f"validation/out/external/{name}_arlequin_concordance.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["dataset", "statistic", "reference", "kind", "n", "max_abs_diff", "mean_abs_diff", "r", "note"]); w.writerows(rows)
print(f"{name}: Arlequin samples {len(arl)}, AMOVA loci {len(amova)}, pairwise {len(pw)}; global {glob}")
for r in rows: print(f"  {r[1]:58s} {r[3]:28s} n={r[4]:5d} max={r[5]:.2e} mean={r[6]:.2e} r={'' if r[7] is None else f'{r[7]:.4f}'} {r[8]}")
