#!/usr/bin/env python3
"""Writes Arlequin settings files from the template distributed with arlecore 3.5.2.2.
Usage: python3 validation/external/make_ars.py <template arl_run.ars>"""
import re, sys
tpl = open(sys.argv[1], encoding="latin-1").read().replace("\r\n", "\n")
# arlecore 3.5.2.2 reports 0.05 when given 0.5 and 0.03 when given 0.3, but 5 when given 5; a value above 1
# switches the missing-data filter off (every locus is used, missing genotypes are skipped locus by locus, as in MicroQuick).
common = dict(XMLOutput=1, AllowedLevelOfMissingData="5.000000", ComputeStandardDiversityIndices=1, MakeHWExactTest=1, TypeOfTestHW=0,
              MarkovChainStepsHW=1000000, MarkovChainDememorisationStepsHW=100000, LocByLocAMOVA=1, IncludeIndividualLevel=1,
              TestSignificanceAMOVA=1, NumPermutationsAMOVA=1000, ComputeDistanceMatrixAMOVA=1, DistanceMethodAMOVA=0,
              ComputePairwiseFST=1, TestSignificancePairewiseFST=1, NumPermutationsFST=1000, PrintFstVals=1)
variants = {"withLD": dict(common, TaskNumber=1 + 16 + 32 + 512 + 1024, MakeExactTestLD=1, MarkovChainStepsLD=1000, InitialCondEMLD=2),
            "noLD": dict(common, TaskNumber=1 + 32 + 512 + 1024, MakeExactTestLD=0),
            "structure": dict(common, TaskNumber=1 + 512 + 1024, MakeExactTestLD=0, MakeHWExactTest=0)}
for name, keys in variants.items():
    t = tpl
    for k, v in keys.items():
        t, n = re.subn(rf"(?m)^{k}=.*$", f"{k}={v}", t)
        assert n == 1, (k, n)
    open(f"validation/external/inputs/arl_{name}.ars", "w", newline="\r\n").write(t)
    print("written", name, keys["TaskNumber"])
