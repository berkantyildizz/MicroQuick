#!/usr/bin/env bash
# Runs Arlequin 3.5.2.2 (arlecore, statically linked Linux x86_64 build from cmpg.unibe.ch) on the validation
# data sets inside a Lima x86_64 Linux VM, for hosts that cannot run the Intel macOS build.
# Usage (repository root):  bash validation/external/run_arlequin_lima.sh <path to arlecore3522_64bit> [vm name]
set -euo pipefail
BIN="$1"; VM="${2:-arlequin}"; IN=validation/external/inputs; OUT=validation/out/external/arlequin
mkdir -p "$OUT"
limactl shell --workdir / "$VM" sh -c 'rm -rf /tmp/arl && mkdir -p /tmp/arl'
limactl copy "$BIN" "$VM":/tmp/arl/arlecore
for f in "$IN"/*.arp "$IN"/*.ars; do limactl copy "$f" "$VM":/tmp/arl/; done
limactl shell --workdir / "$VM" sh -c 'chmod +x /tmp/arl/arlecore && /tmp/arl/arlecore 2>&1 | head -3 || true'
run() {  # dataset settings
  local t0=$(date +%s)
  limactl shell --workdir /tmp/arl "$VM" sh -c "./arlecore $1.arp arl_$2.ars run_silent > $1.log 2>&1; ls $1.res"
  echo "$1 ($2): $(( $(date +%s) - t0 )) s"
  rm -rf "$OUT/$1.res"; limactl copy -r "$VM":/tmp/arl/$1.res "$OUT/"; limactl copy "$VM":/tmp/arl/$1.log "$OUT/"
}
run S1_balanced_reference withLD
run benchmark_simulated withLD
run nancycats withLD
run microbov noLD
