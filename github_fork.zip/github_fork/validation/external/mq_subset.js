// MicroQuick multilocus f, theta, F and their bootstrap 95% CIs over a subset of loci (to match the loci Arlequin kept).
// Usage: node validation/external/mq_subset.js <csv> <comma-separated 0-based locus indices>
const MQ = require('../../src/microquick_core.js'), fs = require('fs');
const { rows } = MQ.parseDelimited(fs.readFileSync(process.argv[2], 'utf8')); const P = MQ.parseGenotypes(rows[0], rows.slice(1));
const keep = process.argv[3].split(',').map(Number).map(i => P.lociNames[i]);
const D = MQ.encode(P.records, P.lociNames, { loci: keep }), d = MQ.describe(D);
const ci = MQ.bootLoci(d.per, 9999, MQ.rng(20260101), ['f', 'theta', 'capF']);
console.log(JSON.stringify({ multi: d.multi, ci }));
