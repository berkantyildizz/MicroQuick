# Collects all concordance tables into validation/out/concordance_all.csv and prints a per-data-set summary.
f <- list.files("validation/out", pattern = "_concordance\\.csv$", recursive = TRUE, full.names = TRUE)
all <- do.call(rbind, lapply(f, read.csv, check.names = FALSE))
write.csv(all, "validation/out/concordance_all.csv", row.names = FALSE)
det <- subset(all, kind == "deterministic")
s <- do.call(rbind, lapply(split(det, det$dataset), function(d) data.frame(dataset = d$dataset[1], statistics = nrow(d), values = sum(d$n),
  worst_abs_diff = max(d$max_abs_diff, na.rm = TRUE), worst_statistic = d$statistic[which.max(d$max_abs_diff)], na_mismatches = sum(d$n_na_mismatch))))
options(width = 220); cat("\nDeterministic statistics (identical estimator in the reference):\n"); print(s, row.names = FALSE)
cat("\nStochastic / differently defined statistics:\n"); print(subset(all, kind != "deterministic")[, c("dataset", "statistic", "reference", "n", "max_abs_diff", "mean_abs_diff", "r", "note")], row.names = FALSE)
write.csv(s, "validation/out/concordance_summary.csv", row.names = FALSE)
