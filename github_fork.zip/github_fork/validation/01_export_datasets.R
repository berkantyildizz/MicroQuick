# Exports the three validation data sets to MicroQuick's two-column CSV layout.
#   benchmark  : simulated Denizli/Gerze benchmark (benchmark/SSR_Denizli_Gerze_simulated.xlsx)
#   nancycats  : 237 cats, 9 loci, 17 colonies  (empirical; distributed with adegenet)
#   microbov   : 704 cattle, 30 loci, 15 breeds (empirical; distributed with adegenet)
suppressMessages({library(adegenet); library(readxl)})
dir.create("data", showWarnings = FALSE)
gi2csv <- function(gi, file) {
  df <- genind2df(gi, sep = "/", usepop = TRUE)
  out <- data.frame(Population = as.character(df$pop), individual = rownames(df))
  for (l in locNames(gi)) {
    s <- strsplit(as.character(df[[l]]), "/")
    out[[paste0(l, "(1)")]] <- sapply(s, function(x) if (length(x) == 2) x[1] else "")
    out[[paste0(l, "(2)")]] <- sapply(s, function(x) if (length(x) == 2) x[2] else "")
  }
  write.csv(out, file, row.names = FALSE, na = "")
}
data(nancycats); gi2csv(nancycats, "data/nancycats.csv")
data(microbov);  pop(microbov) <- microbov$other$breed; gi2csv(microbov, "data/microbov.csv")
tmp <- tempfile(fileext = ".xlsx")   # readxl cannot open paths containing non-ASCII characters on some systems
file.copy("benchmark/SSR_Denizli_Gerze_simulated.xlsx", tmp)
b <- as.data.frame(read_excel(tmp, sheet = 1, col_types = "text"))
b[b == "?"] <- ""; b[is.na(b)] <- ""
write.csv(b, "data/benchmark_simulated.csv", row.names = FALSE)
for (f in list.files("data", pattern = "[.]csv$", full.names = TRUE)) cat(f, nrow(read.csv(f)), "rows\n")
