# Simulated scenarios that leave the idealised benchmark: unequal sample sizes, 0-20 % missing genotypes,
# weak to strong differentiation, inbreeding, and degenerate loci (monomorphic overall; fixed in one population).
# Writes data/scenarios/*.csv; each is then analysed by MicroQuick and by the reference R packages.
set.seed(20261112); dir.create("data/scenarios", recursive = TRUE, showWarnings = FALSE)
rdir <- function(a) { x <- rgamma(length(a), a); x / sum(x) }
sim <- function(name, n, fst, miss, fis = 0, L = 10, k = 8, degenerate = FALSE) {
  P <- length(n); out <- data.frame(Population = rep(paste0("Pop", seq_len(P)), n), individual = sprintf("%s_%03d", name, seq_len(sum(n))))
  for (l in seq_len(L)) {
    anc <- rdir(rep(1, k)); a1 <- a2 <- character(0)
    for (p in seq_len(P)) {
      q <- rdir(anc * (1 - fst) / fst)                       # Balding-Nichols
      if (degenerate && l == L) q <- c(1, rep(0, k - 1))           # locus monomorphic everywhere
      if (degenerate && l == L - 1 && p == 1) q <- c(1, rep(0, k - 1))  # locus fixed in one population only
      x <- sample(k, n[p], TRUE, q); y <- ifelse(runif(n[p]) < fis, x, sample(k, n[p], TRUE, q))
      m <- runif(n[p]) < miss; x[m] <- NA; y[m] <- NA
      a1 <- c(a1, ifelse(is.na(x), "", 100 + 2 * x)); a2 <- c(a2, ifelse(is.na(y), "", 100 + 2 * y))
    }
    out[[sprintf("L%02d(1)", l)]] <- a1; out[[sprintf("L%02d(2)", l)]] <- a2
  }
  write.csv(out, file.path("data/scenarios", paste0(name, ".csv")), row.names = FALSE)
  data.frame(scenario = name, populations = P, sample_sizes = paste(n, collapse = "/"), loci = L, FST_generating = fst, FIS_generating = fis, missing_rate = miss, degenerate_loci = degenerate)
}
design <- rbind(
  sim("S1_balanced_reference",   rep(30, 4),            0.10, 0.00),
  sim("S2_unequal_n",            c(8, 15, 40, 90),      0.10, 0.00),
  sim("S3_missing_05",           rep(30, 4),            0.10, 0.05),
  sim("S4_missing_20",           rep(30, 4),            0.10, 0.20),
  sim("S5_weak_FST_001",         rep(30, 4),            0.01, 0.00),
  sim("S6_strong_FST_030",       rep(30, 4),            0.30, 0.00),
  sim("S7_inbred_FIS_025",       rep(30, 4),            0.10, 0.02, fis = 0.25),
  sim("S8_degenerate_loci",      rep(30, 4),            0.10, 0.02, degenerate = TRUE),
  sim("S9_small_unequal_missing", c(6, 10, 25, 60, 12), 0.05, 0.10, fis = 0.10))
write.csv(design, "validation/out/scenario_design.csv", row.names = FALSE); print(design, row.names = FALSE)
