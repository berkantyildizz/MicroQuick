#!/usr/bin/env bash
# Reproduces every validation table of the paper. Requires Node.js (>= 18) and R (>= 4.2) with
# adegenet, hierfstat, pegas, mmod, genepop, jsonlite, readxl.
# Usage (from the repository root):  bash validation/run_all.sh
set -euo pipefail
B=${B:-9999}; SEED=${SEED:-20260101}
Rscript validation/01_export_datasets.R
Rscript validation/03_scenarios.R
mkdir -p validation/out/scenarios
for d in benchmark_simulated nancycats microbov $(cd data && ls scenarios/*.csv | sed 's/\.csv$//'); do
  node tests/run_core.js "data/$d.csv" "validation/out/$d" "$B" "$SEED"
  Rscript validation/02_compare_reference.R "$d" > "validation/out/${d}_log.txt" 2>&1 || { echo "FAILED: $d"; tail -5 "validation/out/${d}_log.txt"; }
done
Rscript validation/04_summarise.R
