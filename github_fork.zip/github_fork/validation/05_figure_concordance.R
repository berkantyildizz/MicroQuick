# Figure 6 of the paper: MicroQuick against reference implementations (three main data sets).
ds <- c(benchmark_simulated = "Simulated benchmark", microbov = "microbov (cattle)", nancycats = "nancycats (cats)")
col <- c("#0072B2", "#D55E00", "#009E73"); V <- lapply(names(ds), function(n) readRDS(file.path("validation/out", paste0(n, "_values.rds"))))
out <- commandArgs(TRUE)[1]; if (is.na(out)) out <- "validation/out/Fig6_concordance.png"
png(out, width = 2400, height = 2300, res = 300); par(mfrow = c(2, 2), mar = c(4.2, 4.4, 2.2, 1), mgp = c(2.5, 0.8, 0), cex = 0.85)
panel <- function(a, b, xl, yl, main, lim = NULL, leg = FALSE) {
  x <- unlist(lapply(V, `[[`, b)); y <- unlist(lapply(V, `[[`, a)); if (is.null(lim)) lim <- range(c(x, y), na.rm = TRUE)
  plot(NA, xlim = lim, ylim = lim, xlab = xl, ylab = yl, main = main, font.main = 1, cex.main = 1, las = 1); abline(0, 1, col = "grey60")
  for (i in rev(seq_along(V))) points(V[[i]][[b]], V[[i]][[a]], pch = 16, cex = 0.55, col = adjustcolor(col[i], 0.6))
  ok <- is.finite(x) & is.finite(y); legend("bottomright", bty = "n", cex = 0.85, legend = sprintf("n = %d\nmax |diff| = %.1e", sum(ok), max(abs(x[ok] - y[ok]))))
  if (leg) legend("topleft", bty = "n", pch = 16, col = col, legend = ds, cex = 0.85)
}
panel("ar_mq", "ar_ref", "hierfstat", "MicroQuick", "(a) Allelic richness, locus x population", leg = TRUE)
panel("pw_mq", "pw_ref", "hierfstat", "MicroQuick", expression("(b) Pairwise " * theta))
panel("post_mq", "post_ref", "adegenet", "MicroQuick", "(c) DAPC posterior membership probability", c(0, 1))
panel("hw_mq", "hw_gp", "Genepop (Markov chain)", "MicroQuick (9 999 permutations)", "(d) Hardy-Weinberg exact p, locus x population", c(0, 1))
invisible(dev.off()); cat("written", out, "\n")
