# Numerical comparison of MicroQuick (JSON written by tests/run_core.js) with reference software.
#   adegenet 2.1 (Jombart 2008)      allele counts, Ho, He, PCA, DAPC
#   hierfstat 0.5 (Goudet 2005)      Nei (1987) and Weir & Cockerham (1984) F-statistics, allelic richness
#   pegas 1.4 (Paradis 2010)         HWE chi-square (df = k(k-1)/2) and Monte Carlo exact test; W&C F-statistics
#   mmod 1.3 (Winter 2012)           Hedrick G'ST, Jost D
#   Genepop 4.8 (Rousset 2008)       HWE probability test and genotypic linkage disequilibrium, via the genepop R package
# Usage: Rscript validation/02_compare_reference.R <name>      (reads data/<name>.csv and validation/out/<name>.json)
suppressMessages({library(adegenet); library(hierfstat); library(pegas); library(mmod); library(genepop); library(jsonlite)})
name <- commandArgs(TRUE)[1]; set.seed(1)
mq  <- fromJSON(file.path("validation/out", paste0(name, ".json")), simplifyVector = TRUE)
raw <- read.csv(file.path("data", paste0(name, ".csv")), check.names = FALSE, colClasses = "character")
loc <- sub("\\(1\\)$", "", grep("\\(1\\)$", names(raw), value = TRUE))
geno <- as.data.frame(lapply(loc, function(l) { a <- raw[[paste0(l, "(1)")]]; b <- raw[[paste0(l, "(2)")]]; ifelse(a == "" | b == "", NA, paste(a, b, sep = "/")) }))
names(geno) <- gsub("[.]", "_", loc)
gi <- df2genind(geno, sep = "/", ind.names = make.unique(raw$individual), pop = factor(raw$Population, levels = unique(raw$Population)), ploidy = 2)
stopifnot(all(popNames(gi) == mq$pops), nLoc(gi) == mq$L)
K <- nPop(gi); L <- nLoc(gi); res <- list()
add <- function(stat, ref, a, b, kind = "deterministic") {
  a <- as.numeric(a); b <- as.numeric(b); ok <- is.finite(a) & is.finite(b)
  res[[length(res) + 1]] <<- data.frame(dataset = name, statistic = stat, reference = ref, kind = kind, n = sum(ok),
    max_abs_diff = if (any(ok)) max(abs(a[ok] - b[ok])) else NA, mean_abs_diff = if (any(ok)) mean(abs(a[ok] - b[ok])) else NA,
    r = if (sum(ok) > 2 && sd(a[ok]) > 0 && sd(b[ok]) > 0) cor(a[ok], b[ok]) else NA, n_na_mismatch = sum(is.finite(a) != is.finite(b)))
}
## 1. pooled per-locus diversity -------------------------------------------------
sm <- summary(gi); fr <- lapply(seploc(gi), function(x) { cn <- colSums(tab(x), na.rm = TRUE); cn[cn > 0] / sum(cn) })
add("Na (pooled)", "adegenet", mq$locus$Na, sm$loc.n.all)
add("Ho (pooled)", "direct count in R", mq$locus$Ho, sapply(geno, function(g) { s <- strsplit(as.character(na.omit(g)), "/"); mean(sapply(s, function(x) x[1] != x[2])) }))
add("Ho (pooled)", "adegenet summary()", mq$locus$Ho, sm$Hobs, "estimator differs")
add("He (pooled)", "adegenet", mq$locus$He, sm$Hexp)
al <- lapply(seq_len(L), function(i) na.omit(unlist(strsplit(as.character(geno[[i]]), "/"))))
add("uHe (pooled)", "pegas", mq$locus$uHe, sapply(al, pegas::heterozygosity))
add("Ne (pooled)", "formula in R", mq$locus$Ne, sapply(fr, function(p) 1 / sum(p^2)))
add("Shannon I (pooled)", "formula in R", mq$locus$I, sapply(fr, function(p) -sum(p * log(p))))
add("PIC (pooled)", "formula in R", mq$locus$PIC, sapply(fr, function(p) { s <- 0; k <- length(p); if (k > 1) for (i in 1:(k - 1)) for (j in (i + 1):k) s <- s + 2 * p[i]^2 * p[j]^2; 1 - sum(p^2) - s }))
## 2. Nei (1987) statistics --------------------------------------------------------
if (K > 1) {
  bs <- basic.stats(gi, digits = 10); pl <- bs$perloc
  for (s in list(c("HoS", "Ho"), c("Hs", "Hs"), c("Ht", "Ht"), c("Fis", "Fis"), c("Gst", "Fst"), c("GstP", "Fstp"), c("D", "Dest")))
    add(paste0(s[1], " per locus (Nei 1987)"), "hierfstat", mq$locus[[s[1]]], pl[[s[2]]])
  ov <- bs$overall
  add("Multilocus Ho, Hs, Ht, FIS, GST, G'ST(Nei), Dest", "hierfstat", unlist(mq$multi[c("HoS", "Hs", "Ht", "Fis", "Gst", "GstP", "D")]), ov[c("Ho", "Hs", "Ht", "Fis", "Fst", "Fstp", "Dest")])
  hs <- pl$Hs; ht <- pl$Ht
  npl <- rowSums(sapply(seppop(gi), function(x) colSums(!is.na(genind2df(x, usepop = FALSE)))) > 0)   # populations typed at each locus
  add("G''ST per locus (Meirmans & Hedrick 2011)", "formula in R on hierfstat Hs, Ht", mq$locus$Gst2, npl * (ht - hs) / ((npl * ht - hs) * (1 - hs)))
  ds <- diff_stats(gi)
  add("G'ST per locus (Hedrick 2005)", "mmod", mq$locus$GstH, ds$per.locus[, "Gprime_st"], "estimator differs")
  add("Jost D per locus", "mmod", mq$locus$D, ds$per.locus[, "D"], "estimator differs")
  add("Jost D multilocus", "mmod (D_het)", mq$multi$D, ds$global["D_het"], "estimator differs")
  ## 3. Weir & Cockerham (1984) ------------------------------------------------------
  w <- wc(gi)
  add("theta per locus (W&C 1984)", "hierfstat", mq$locus$theta, w$per.loc$FST)
  add("f per locus (W&C 1984)", "hierfstat", mq$locus$f, w$per.loc$FIS)
  add("Multilocus theta, f (W&C 1984)", "hierfstat", c(mq$multi$theta, mq$multi$f), c(w$FST, w$FIS))
  pf <- pegas::Fst(as.loci(gi))
  add("theta, f, F per locus (W&C 1984)", "pegas", c(mq$locus$theta, mq$locus$f, mq$locus$capF), c(pf[, "Fst"], pf[, "Fis"], pf[, "Fit"]))
  ## 4. allelic richness ---------------------------------------------------------------
  ar <- allelic.richness(gi)
  stopifnot(ar$min.all == mq$rareG)
  add("Allelic richness, locus x population", "hierfstat", unlist(lapply(seq_len(L), function(l) mq$cells[[l]]$Ar)), as.vector(t(ar$Ar)))
  ## 5. pairwise -----------------------------------------------------------------------
  pw <- mq$pairwise; ij <- cbind(pw$i + 1, pw$j + 1)
  typed <- sapply(seppop(gi), function(x) colSums(!is.na(genind2df(x, usepop = FALSE))))            # L x K
  gap <- apply(ij, 1, function(v) any(typed[, v[1]] == 0 | typed[, v[2]] == 0)); refw <- pairwise.WCfst(gi)[ij]
  add("Pairwise theta (W&C 1984)", "hierfstat", pw$theta[!gap], refw[!gap])
  if (any(gap)) {   # hierfstat keeps a locus that is untyped in one of the two populations; MicroQuick drops it for that pair
    add("Pairwise theta, pairs with a locus untyped in one population", "hierfstat (as is)", pw$theta[gap], refw[gap], "estimator differs")
    ref2 <- sapply(which(gap), function(r) { v <- ij[r, ]; keep <- which(typed[, v[1]] > 0 & typed[, v[2]] > 0); pairwise.WCfst(gi[pop = v, loc = keep, drop = TRUE])[1, 2] })
    add("Pairwise theta, same pairs, untyped locus removed", "hierfstat", pw$theta[gap], ref2)
  }
  add("Pairwise G'ST (Nei 1987; hierfstat pairwise.neifst)", "hierfstat", pw$GstP, pairwise.neifst(gi)[ij])
  add("Pairwise Jost D", "mmod", pw$D, as.matrix(pairwise_D(gi))[ij], "estimator differs")
  bp <- boot.ppfst(gi, nboot = 999)
  cith <- pw$ci$theta; if (is.list(cith)) cith <- do.call(rbind, cith)
  add("Pairwise theta 95% CI limits (bootstrap over loci)", "hierfstat", c(cith[, 1], cith[, 2]), c(bp$ll[ij], bp$ul[ij]), "stochastic")
  bv <- boot.vc(genind2hierfstat(gi)[, 1, drop = FALSE], genind2hierfstat(gi)[, -1], nboot = 999)$ci
  add("Global theta and f 95% CI limits (bootstrap over loci)", "hierfstat", c(mq$ci$theta, mq$ci$f), c(bv[c(1, 3), "F-pop/Total"], bv[c(1, 3), "F-Ind/pop"]), "stochastic")
}
## 6. per-population diversity ----------------------------------------------------------
sp <- seppop(gi)
add("Ho, locus x population", "adegenet", unlist(lapply(seq_len(L), function(l) mq$cells[[l]]$Ho)), as.vector(t(sapply(sp, function(x) summary(x)$Hobs))))
add("He, locus x population", "adegenet", unlist(lapply(seq_len(L), function(l) mq$cells[[l]]$He)), as.vector(t(sapply(sp, function(x) summary(x)$Hexp))))
## 7. Hardy-Weinberg ------------------------------------------------------------------------
hw <- lapply(sp, function(x) suppressWarnings(hw.test(x, B = 9999)))
g <- function(col) as.vector(t(sapply(hw, function(h) h[, col])))
mh <- function(f) unlist(lapply(seq_len(L), function(l) mq$hwe$byPop[[l]][[f]]))
tested <- is.finite(mh("chi2"))
add("HWE chi-square statistic, locus x population", "pegas", mh("chi2")[tested], g("chi^2")[tested])
add("HWE chi-square df, locus x population", "pegas", mh("df")[tested], g("df")[tested])
add("HWE chi-square p, locus x population", "pegas", mh("pChi")[tested], g("Pr(chi^2 >)")[tested])
add("HWE exact p (Monte Carlo), locus x population", "pegas (B = 9999)", mh("pExact")[tested], g("Pr.exact")[tested], "stochastic")
gp <- file.path("validation/out", paste0(name, ".genepop.txt")); tmp <- tempfile(); dir.create(tmp)
gpf <- file.path(tmp, "in.txt"); file.copy(gp, gpf)
of <- file.path(tmp, "hw.txt"); test_HW(gpf, which = "Proba", outputFile = of, dememorization = 10000, batches = 100, iterations = 5000)
tx <- readLines(of); st <- grep("^Locus \"", tx); stopifnot(length(st) == L); gph <- matrix(NA, L, K)   # "Results by locus" section
for (l in seq_len(L)) { blk <- tx[(st[l] + 6):(st[l] + 5 + K)]; f <- strsplit(trimws(blk), "\\s+"); gph[l, ] <- suppressWarnings(as.numeric(sapply(f, `[`, 2))) }
gpv <- as.vector(t(gph)); mqe <- mh("pExact")
add("HWE exact p, locus x population", "Genepop 4.8 (probability test)", mqe, gpv, "stochastic")
alpha <- 0.05; ok <- is.finite(mqe) & is.finite(gpv)
res[[length(res)]]$note <- sprintf("same decision at alpha 0.05 in %d of %d tests", sum((mqe[ok] < alpha) == (gpv[ok] < alpha)), sum(ok))
if (any(is.finite(mqe) != is.finite(gpv))) { cat("HWE tests reported by only one program:\n"); bad <- which(is.finite(mqe) != is.finite(gpv)); print(data.frame(locus = rep(locNames(gi), each = K)[bad], pop = rep(popNames(gi), L)[bad], MicroQuick = mqe[bad], Genepop = gpv[bad], n = mh("n")[bad], k = mh("k")[bad])) }
## 8. linkage disequilibrium -------------------------------------------------------------------
if (length(mq$ld) && nrow(mq$ld)) {
  of <- file.path(tmp, "ld.txt"); test_LD(gpf, outputFile = of, dememorization = 10000, batches = 100, iterations = 5000)
  tx <- readLines(of); h <- grep("^Locus pair", tx); blk <- tx[(h + 2):length(tx)]; blk <- blk[grepl("&", blk)]
  f <- strsplit(trimws(gsub("&", " ", blk)), "\\s+")
  gl <- data.frame(a = sapply(f, `[`, 1), b = sapply(f, `[`, 2), p = suppressWarnings(as.numeric(sub("^<", "", sub("Highly sign\\.", "0", sapply(f, function(x) x[length(x)]))))))   # "<p" = upper bound when a population p value is 0
  cl <- function(x) gsub("[^A-Za-z0-9]", "", x)
  m <- match(paste(cl(mq$loci[mq$ld$i + 1]), cl(mq$loci[mq$ld$j + 1])), paste(cl(gl$a), cl(gl$b))); stopifnot(!anyNA(m))
  a <- mq$ld$p; b <- gl$p[m]
  add("LD p per locus pair (Fisher across populations)", "Genepop 4.8", a, b, "stochastic")
  iF <- length(res)
  # population-level p values (before Fisher's combination), with Genepop's own Markov-chain standard error
  h <- grep("^Pop +Locus#1", tx); e <- grep("^P-value for each locus pair", tx); pb <- tx[(h + 2):(e - 1)]; pb <- pb[nchar(trimws(pb)) > 0]; pf <- strsplit(trimws(pb), "[ ]+")
  gpp <- data.frame(pop = sapply(pf, `[`, 1), a = sapply(pf, `[`, 2), b = sapply(pf, `[`, 3), p = suppressWarnings(as.numeric(sapply(pf, `[`, 4))), se = suppressWarnings(as.numeric(sapply(pf, `[`, 5))))
  byp <- mq$ld$byPop; if (is.list(byp)) byp <- do.call(rbind, byp); mk <- paste(cl(mq$loci[mq$ld$i + 1]), cl(mq$loci[mq$ld$j + 1]))
  Gm <- sapply(unique(gpp$pop), function(pp) { x <- gpp[gpp$pop == pp, ]; x$p[match(mk, paste(cl(x$a), cl(x$b)))] })
  if (ncol(Gm) == ncol(byp)) { add("LD p per locus pair within population", "Genepop 4.8", as.vector(byp), as.vector(Gm), "stochastic"); okp <- is.finite(Gm) & is.finite(byp)
    res[[length(res)]]$note <- sprintf("same decision at alpha 0.05 in %d of %d tests; mean Genepop S.E. = %.4f", sum((Gm[okp] < alpha) == (byp[okp] < alpha)), sum(okp), mean(gpp$se, na.rm = TRUE)) }
  ok <- is.finite(a) & is.finite(b)
  res[[iF]]$note <- sprintf("same decision at alpha 0.05 in %d of %d pairs; Spearman rho = %.3f", sum((a[ok] < alpha) == (b[ok] < alpha)), sum(ok), cor(a[ok], b[ok], method = "spearman"))
}
## 9. PCA / k-means / DAPC ------------------------------------------------------------------------
X <- tab(gi, freq = TRUE, NA.method = "mean"); pc <- ade4::dudi.pca(X, center = TRUE, scale = FALSE, scannf = FALSE, nf = 10)
add("PCA % variance, PC1-PC10", "adegenet/ade4", mq$pca$varExp[1:10], 100 * pc$eig[1:10] / sum(pc$eig))
add("PCA scores PC1-PC5 (|r|, sign-free)", "adegenet/ade4", rep(1, 5), sapply(1:5, function(i) abs(cor(mq$pca$scores[, i], pc$li[, i]))))
add("PCA scores PC1-PC5 (absolute values)", "adegenet/ade4", abs(as.vector(mq$pca$scores[, 1:5])), abs(as.vector(as.matrix(pc$li[, 1:5]))))
nPC <- mq$nPC; pcs <- ade4::dudi.pca(X, center = TRUE, scale = FALSE, scannf = FALSE, nf = nPC)$li
km <- sapply(2:6, function(k) kmeans(pcs, centers = k, nstart = 200, iter.max = 200, algorithm = "Lloyd")$tot.withinss)
add("k-means within-cluster SS, K = 2-6 (relative difference)", "stats::kmeans (Lloyd), 200 starts", mq$kmeans$wss[2:6] / km, rep(1, 5), "stochastic")
if (K > 1 && !is.null(mq$dapc)) {
  da <- dapc(gi, pop(gi), n.pca = nPC, n.da = K - 1)
  nd <- min(3, K - 1)
  add("DAPC coordinates LD1-LD3 (|r|, sign-free)", "adegenet", rep(1, nd), sapply(1:nd, function(i) abs(cor(mq$dapc$coords[, i], da$ind.coord[, i]))))
  add("DAPC coordinates LD1-LD3 (absolute values)", "adegenet", abs(as.vector(mq$dapc$coords[, 1:nd])), abs(as.vector(da$ind.coord[, 1:nd])))
  add("DAPC posterior membership probabilities", "adegenet", as.vector(mq$dapc$posterior), as.vector(da$posterior))
  add("DAPC proportion correctly reassigned", "adegenet", mq$dapc$assignProp, mean(as.integer(da$assign) == as.integer(pop(gi))))
}
out <- do.call(plyr_rbind <- function(...) { l <- list(...); for (i in seq_along(l)) if (is.null(l[[i]]$note)) l[[i]]$note <- ""; do.call(rbind, l) }, res)
write.csv(out, file.path("validation/out", paste0(name, "_concordance.csv")), row.names = FALSE)
op <- options(width = 250, digits = 4); print(out[, -1], row.names = FALSE); options(op)
# per-value export for the concordance figure
if (K > 1) saveRDS(list(pw_mq = mq$pairwise$theta, pw_ref = pairwise.WCfst(gi)[ij], th_mq = mq$locus$theta, th_ref = w$per.loc$FST, hw_mq = mqe, hw_gp = gpv,
  he_mq = unlist(lapply(seq_len(L), function(l) mq$cells[[l]]$He)), he_ref = as.vector(t(sapply(sp, function(x) summary(x)$Hexp))),
  ar_mq = unlist(lapply(seq_len(L), function(l) mq$cells[[l]]$Ar)), ar_ref = as.vector(t(ar$Ar)), post_mq = as.vector(mq$dapc$posterior), post_ref = as.vector(da$posterior)),
  file.path("validation/out", paste0(name, "_values.rds")))
