#!/usr/bin/env python3
"""Assembles the single-file release MicroQuick.html from src/ and vendor/.
No transpiling, no minifying: the statistical core is inlined verbatim, so the file that is
tested (src/microquick_core.js) is the code that runs in the browser.   Usage: python3 build.py"""
import json, pathlib, re
root = pathlib.Path(__file__).parent
rd = lambda p: (root / p).read_text(encoding="utf-8")
g = lambda s: s.replace("</script>", "<\\/script>")
html = rd("src/shell.html")
vendor = "<script>" + g(rd("vendor/xlsx.full.min.js")) + "</script>\n<script>" + g(rd("vendor/chart.umd.js")) + "</script>"
def put(tag, body):
    global html
    a, b = f"/*<{tag}>*/", f"/*</{tag}>*/"
    i, j = html.index(a), html.index(b)
    html = html[: i + len(a)] + "\n" + body + "\n" + html[j:]
html = html.replace("<!--VENDOR-->", vendor)
put("MQ-CORE", rd("src/microquick_core.js"))
put("MQ-EXAMPLE", "const EXAMPLE_CSV = " + json.dumps(rd("data/benchmark_simulated.csv")) + ";")
put("MQ-UI", rd("src/ui.js"))
left = re.findall(r'(?:src|href)="https?://[^"]+"', html)
assert not left, f"external references remain: {left}"
(root / "MicroQuick.html").write_text(html, encoding="utf-8")
print(f"MicroQuick.html: {len(html.encode()) / 1048576:.2f} MB, no external references")
