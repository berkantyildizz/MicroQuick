#!/usr/bin/env node
/* Runs the MicroQuick core (the same file that is embedded in MicroQuick.html) on a CSV file
 * and writes every result as JSON, plus a Genepop export.
 * Usage: node tests/run_core.js data/nancycats.csv out/nancycats [perm=999] [seed=20260101] */
const fs = require('fs'), path = require('path');
const MQ = require(path.join(__dirname, '..', 'src', 'microquick_core.js'));
const [, , csv, outBase, permArg, seedArg, pairArg] = process.argv;
const B = permArg === undefined ? 999 : +permArg, seed = seedArg === undefined ? 20260101 : +seedArg;
const t0 = process.hrtime.bigint(), ms = () => Number(process.hrtime.bigint() - t0) / 1e6, T = {};
const { rows } = MQ.parseDelimited(fs.readFileSync(csv, 'utf8'));
const P = MQ.parseGenotypes(rows[0], rows.slice(1));
const D = MQ.encode(P.records, P.lociNames);
const rnd = MQ.rng(seed), Bp = pairArg === undefined ? Math.min(B, 999) : +pairArg;
let t = ms(); const desc = MQ.describe(D); T.describe = ms() - t;
t = ms(); const hw = MQ.hweAll(D, B, rnd); T.hwe = ms() - t;
t = ms(); const ci = D.K > 1 && B > 0 ? MQ.bootLoci(desc.per, Math.min(B, 999), rnd, ['theta', 'f', 'capF', 'Gst', 'Gst2', 'D', 'Fis']) : {};
const glob = D.K > 1 && B > 0 ? MQ.permTheta(D, D.pop, D.K, B, rnd) : { p: NaN }; T.global = ms() - t;
t = ms(); const pw = D.K > 1 ? MQ.pairwise(D, { boot: Math.min(B, 999), perm: Bp, rnd }) : []; T.pairwise = ms() - t;
t = ms(); const ld = B > 0 ? MQ.ldAll(D, B, rnd) : []; T.ld = ms() - t;
t = ms(); const pc = MQ.pca(D, 80); T.pca = ms() - t;
t = ms(); const nPC = MQ.defaultNPC(pc, D.n, D.K);
const km = []; for (let K = 1; K <= Math.min(10, D.n - 1); K++) { const r = MQ.kmeans(pc.scores, nPC, K, MQ.defaultRestarts(D.n), rnd); km.push({ K, wss: r.wss, bic: r.bic, assign: Array.from(r.assign) }); }
const da = D.K > 1 ? MQ.dapc(pc.scores, nPC, D.pop, D.K) : null; T.cluster = ms() - t;
const clean = o => JSON.parse(JSON.stringify(o, (k, v) => (typeof v === 'number' && !isFinite(v)) ? null : (ArrayBuffer.isView(v) ? Array.from(v) : v)));
fs.mkdirSync(path.dirname(outBase), { recursive: true });
fs.writeFileSync(outBase + '.json', JSON.stringify(clean({
  version: MQ.VERSION, file: path.basename(csv), seed, B, n: D.n, L: D.L, K: D.K, pops: D.popNames, loci: D.loci, warn: P.warn, timing_ms: T,
  locus: desc.locus.map(l => { const o = Object.assign({}, l); delete o.nei; delete o.wc; return o; }), cells: desc.cells, perPop: desc.perPop, multi: desc.multi, rareG: desc.rareG, missing: desc.missing,
  ci, globalP: glob.p, hwe: hw, pairwise: pw, ld, ids: D.ids, popOf: Array.from(D.pop),
  pca: { varExp: pc.varExp.slice(0, 20), nFeatures: pc.nFeatures, scores: pc.scores.map(s => Array.from(s.subarray(0, 10))) }, nPC, kmeans: km,
  dapc: da ? { nPC: da.nPC, nDA: da.nDA, eig: da.eig, assignProp: da.assignProp, coords: da.coords.map(c => Array.from(c)), posterior: da.posterior.map(c => Array.from(c)), assign: Array.from(da.assign) } : null })));
fs.writeFileSync(outBase + '.genepop.txt', MQ.toGenepop(D, 'MicroQuick export of ' + path.basename(csv)));
console.log(`${path.basename(csv)}: n=${D.n} L=${D.L} K=${D.K} | ` + Object.entries(T).map(([k, v]) => `${k} ${v.toFixed(0)} ms`).join(', '), '| warnings', JSON.stringify(P.warn));
