#!/usr/bin/env node
/* Runtime benchmark in a real browser. Simulated data sets of increasing size (Balding-Nichols, FST 0.08,
 * 8 alleles per locus, 3 % missing) are analysed through the user interface of the built MicroQuick.html;
 * the median of three runs is reported per step.   Usage: node tests/benchmark_runtime.js > validation/out/runtime.csv */
const path = require('path'), os = require('os'), { launch } = require('./cdp.js'), MQ = require('../src/microquick_core.js');
function simulate(n, L, K, seed) {
  const r = MQ.rng(seed), gam = a => { let s = 0; for (let i = 0; i < 12; i++) s += -Math.log(1 - r()); return s * a / 12; };   // crude positive draw; only sizes matter here
  const dir = al => { const x = al.map(a => Math.max(1e-6, gam(a))), t = x.reduce((p, q) => p + q, 0); return x.map(v => v / t); }, k = 8, fst = 0.08;
  const draw = q => { let u = r(), c = 0; for (let i = 0; i < q.length; i++) { c += q[i]; if (u < c) return 100 + 2 * i; } return 100 + 2 * (q.length - 1); };
  const head = ['Population', 'individual'], freqs = []; for (let l = 0; l < L; l++) { head.push(`L${l + 1}(1)`, `L${l + 1}(2)`); const anc = dir(new Array(k).fill(1)); freqs.push([...Array(K).keys()].map(() => dir(anc.map(a => a * (1 - fst) / fst)))); }
  const rows = [head.join(',')];
  for (let i = 0; i < n; i++) { const p = i % K, row = ['Pop' + (p + 1), 'ind' + (i + 1)]; for (let l = 0; l < L; l++) { if (r() < 0.03) row.push('', ''); else row.push(draw(freqs[l][p]), draw(freqs[l][p])); } rows.push(row.join(',')); }
  return rows.join('\n');
}
(async () => {
  const b = await launch('file://' + encodeURI(path.join(__dirname, '..', 'MicroQuick.html')));
  const sizes = [[100, 10, 4], [250, 15, 5], [500, 20, 8], [1000, 30, 10], [2000, 50, 10]], steps = ['diversity_Fstatistics', 'HWE', 'global_CI_test', 'pairwise', 'LD', 'PCA', 'clustering_DAPC', 'total'];
  console.log(`# ${await b.version()}; ${os.cpus()[0].model}; ${(os.totalmem() / 2 ** 30).toFixed(0)} GB RAM; ${os.type()} ${os.release()}; median of 3 runs; times in ms`);
  console.log(['individuals', 'loci', 'populations', 'permutations', ...steps].join(','));
  for (const [n, L, K] of sizes) { const csv = simulate(n, L, K, 1000 + n);
    for (const perm of [0, 999]) { const runs = [];
      for (let rep = 0; rep < 3; rep++) { await b.ev(`UI.loadText(${JSON.stringify(csv)}, 'bench.csv')`); await b.ev(`document.getElementById('setPerm').value='${perm}'; document.getElementById('setBoot').value='${perm ? 999 : 0}'; UI.run()`); runs.push(await b.ev(`UI.S.timing`)); }
      const med = s => { const v = runs.map(x => x[s] || 0).sort((x, y) => x - y); return Math.round(v[1]); };
      console.log([n, L, K, perm, ...steps.map(med)].join(','));
    } }
  if (b.errors.length) console.error('errors', b.errors); await b.close();
})().catch(e => { console.error(e); process.exit(1); });
