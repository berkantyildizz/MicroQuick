#!/usr/bin/env node
/* Type-I error check. Data are simulated under the null hypotheses (one panmictic population in Hardy-Weinberg
 * and linkage equilibrium, split at random into four samples of 30), analysed with 499 permutations, and the
 * proportion of p values below 0.05 is reported. Expected: about 0.05 for each test.
 * Usage: node tests/null_calibration.js [replicates=300] > validation/out/null_calibration.csv */
const MQ = require('../src/microquick_core.js'), R = +process.argv[2] || 300, r = MQ.rng(424242), B = 499;
const cnt = { hwe: [0, 0], ld: [0, 0], global: [0, 0], pair: [0, 0] };
for (let rep = 0; rep < 5 * R; rep++) {     // theta tests give one (global) or six (pairwise) values per data set, so five times as many data sets are used for them
  const L = 8, k = 6, n = 120, rows = [], head = ['pop', 'id'];
  const fr = []; for (let l = 0; l < L; l++) { head.push(`L${l}(1)`, `L${l}(2)`); const x = [...Array(k)].map(() => -Math.log(1 - r())), s = x.reduce((a, b) => a + b, 0); fr.push(x.map(v => v / s)); }
  const draw = q => { let u = r(), c = 0; for (let i = 0; i < q.length; i++) { c += q[i]; if (u < c) return 100 + 2 * i; } return 100 + 2 * (q.length - 1); };
  for (let i = 0; i < n; i++) { const row = ['P' + (i % 4), i]; for (let l = 0; l < L; l++) row.push(draw(fr[l]), draw(fr[l])); rows.push(row); }
  const P = MQ.parseGenotypes(head, rows), D = MQ.encode(P.records, P.lociNames), rnd = MQ.rng(1000003 * (rep + 1));
  const add = (key, p) => { if (isFinite(p)) { cnt[key][1]++; if (p < 0.05) cnt[key][0]++; } };
  if (rep < R) { MQ.hweAll(D, B, rnd).byPop.forEach(x => x.forEach(c => add('hwe', c.pExact))); MQ.ldAll(D, B, rnd).forEach(x => x.byPop.forEach(p => add('ld', p))); }
  add('global', MQ.permTheta(D, D.pop, D.K, B, rnd).p);
  MQ.pairwise(D, { boot: 0, perm: B, rnd }).forEach(x => add('pair', x.p));
}
console.log('test,tests,p_below_0.05,proportion');
const nm = { hwe: 'HW exact test (locus x population)', ld: 'LD test (locus pair within population)', global: 'Global theta permutation test', pair: 'Pairwise theta permutation test' };
for (const k in cnt) console.log([nm[k], cnt[k][1], cnt[k][0], (cnt[k][0] / cnt[k][1]).toFixed(4)].join(','));
