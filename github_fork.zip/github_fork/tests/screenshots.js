#!/usr/bin/env node
/* Regenerates the interface figures of the paper from the built application (benchmark data set, default settings).
 * Usage: node tests/screenshots.js <output dir> */
const path = require('path'), fs = require('fs'), { launch } = require('./cdp.js');
(async () => {
  const out = process.argv[2] || path.join(__dirname, '..', 'figures'), root = path.join(__dirname, '..'); fs.mkdirSync(out, { recursive: true });
  const b = await launch('file://' + encodeURI(path.join(root, 'MicroQuick.html')), { width: 1400, height: 900, scale: 2 });
  await b.ev(`UI.loadExample()`); await b.shot(path.join(out, 'ui_1_load_select.png'), 'main');
  await b.ev(`UI.run()`); await b.ev(`document.getElementById('msgArea').innerHTML='';1`);
  for (const t of ['overview', 'qc', 'locus', 'pops', 'fstats', 'diff', 'pca', 'cluster', 'charts', 'guide']) {
    await b.ev(`UI.switchTab('${t}'); document.querySelectorAll('#tab-${t} .tscroll').forEach((e,i)=>{e.style.maxHeight=('${t}'==='qc'&&i>0)?'230px':'none'}); 1`);
    if (t === 'diff') await b.ev(`document.getElementById('showNm').checked=false;1`);
    await new Promise(r => setTimeout(r, 400)); await b.shot(path.join(out, `ui_tab_${t}.png`), '#results');
  }
  console.log('errors:', b.errors.length ? b.errors : 'none'); await b.close();
})().catch(e => { console.error(e); process.exit(1); });
