#!/usr/bin/env node
/* Every number quoted in the paper for the three main data sets, taken from the built application run with
 * its default settings (999 permutations, 999 bootstrap replicates, BH correction, seed 20260101).
 * Usage: node tests/paper_numbers.js > validation/out/paper_numbers.json */
const path = require('path'), fs = require('fs'), { launch } = require('./cdp.js');
(async () => {
  const root = path.join(__dirname, '..'), b = await launch('file://' + encodeURI(path.join(root, 'MicroQuick.html'))), out = { browser: await b.version() };
  for (const name of ['benchmark_simulated', 'nancycats', 'microbov']) {
    await b.ev(`UI.loadText(${JSON.stringify(fs.readFileSync(path.join(root, 'data', name + '.csv'), 'utf8'))}, '${name}.csv')`); await b.ev('UI.run()');
    out[name] = await b.ev(`(()=>{const S=UI.S,D=S.D,d=S.desc,a=S.set.alpha,k=S.hwKey,L=d.locus,rng=v=>[Math.min(...v),Math.max(...v)];
      const hw=[];S.hw.byPop.forEach((r,l)=>r.forEach((c,p)=>{if(isFinite(c[k]))hw.push({l,p,p0:c[k],adj:c.adj,F:c.Fis})}));
      const sig=hw.filter(x=>x.adj<a);
      const byLoc=D.loci.map((nm,l)=>[nm,sig.filter(x=>x.l===l).length,hw.filter(x=>x.l===l).length]),byPop=D.popNames.map((nm,p)=>[nm,sig.filter(x=>x.p===p).length,hw.filter(x=>x.p===p).length]);
      const da=MQ.dapc(S.pca.scores,Math.min(S.nPC,D.n-D.K-1),D.pop,D.K);
      const km2=S.km[1],ct2=D.popNames.map((p,pi)=>[p,D.popIdx[pi].filter(i=>km2.assign[i]===0).length,D.popIdx[pi].filter(i=>km2.assign[i]===1).length]);
      const best=S.km.reduce((b,x,i)=>x.bic<S.km[b].bic?i:b,0)+1;
      return {n:D.n,L:D.L,K:D.K,pops:D.popNames,popN:D.popIdx.map(x=>x.length),missing:d.missing,rareG:d.rareG,
        pooled:{Na:MQ.mean(L.map(l=>l.Na)),NaRange:rng(L.map(l=>l.Na)),Ne:MQ.mean(L.map(l=>l.Ne)),I:MQ.mean(L.map(l=>l.I)),Ho:MQ.mean(L.map(l=>l.Ho)),He:MQ.mean(L.map(l=>l.He)),uHe:MQ.mean(L.map(l=>l.uHe)),PIC:MQ.mean(L.map(l=>l.PIC)),PICrange:rng(L.map(l=>l.PIC)),PICbelow05:L.filter(l=>l.PIC<0.5).map(l=>l.locus+' '+l.PIC.toFixed(3))},
        locus:L.map(l=>({locus:l.locus,N:l.N,Na:l.Na,Ne:l.Ne,I:l.I,Ho:l.Ho,He:l.He,uHe:l.uHe,PIC:l.PIC,Ar:l.Ar,Fis:l.Fis,Gst:l.Gst,Gst2:l.Gst2,D:l.D,f:l.f,theta:l.theta})),
        multi:d.multi,meanPerLocus:{Fis:MQ.mean(L.map(l=>l.Fis)),Gst:MQ.mean(L.map(l=>l.Gst)),theta:MQ.mean(L.map(l=>l.theta)),f:MQ.mean(L.map(l=>l.f)),D:MQ.mean(L.map(l=>l.D))},ci:S.ci,globalP:S.globalP,
        perPop:d.perPop,hwe:{tested:hw.length,sigAdj:sig.length,sigNominal:hw.filter(x=>x.p0<a).length,deficitAmongSig:sig.filter(x=>x.F>0).length,byLoc,byPop,pooledSig:S.hw.pooled.filter(c=>c.adj<a).length,pooledTested:S.hw.pooled.filter(c=>isFinite(c[k])).length},
        ld:{tested:S.ld.filter(x=>isFinite(x.p)).length,sigAdj:S.ld.filter(x=>x.adj<a).length,sigNominal:S.ld.filter(x=>x.p<a).length,top:S.ld.slice().sort((x,y)=>x.p-y.p).slice(0,4).map(x=>[D.loci[x.i],D.loci[x.j],x.p,x.adj])},
        pw:{n:S.pw.length,sigAdj:S.pw.filter(x=>x.adj<a).length,theta:rng(S.pw.map(x=>x.theta)),D:rng(S.pw.map(x=>x.D)),Gst2:rng(S.pw.map(x=>x.Gst2)),all:S.pw.map(x=>[D.popNames[x.i],D.popNames[x.j],x.theta,x.ci.theta,x.p,x.adj,x.Gst2,x.D,x.ci.D])},
        nullMax:Math.max(...d.cells.flat().map(c=>isFinite(c.nullF)?c.nullF:0)),
        pca:{varExp:S.pca.varExp.slice(0,4),nFeatures:S.pca.nFeatures},nPC:S.nPC,cumVar:S.pca.cumVar[S.nPC-1],bic:S.km.map(x=>x.bic),bestK:best,kmeansK2:ct2,
        dapc:da?{assignProp:da.assignProp,nDA:da.nDA,daVar:da.daVar.slice(0,3),meanOwn:D.popNames.map((p,pi)=>MQ.mean(D.popIdx[pi].map(i=>da.posterior[i][pi])))}:null,timing:S.timing}})()`);
  }
  console.log(JSON.stringify(out, (k, v) => typeof v === 'number' && !Number.isInteger(v) ? +v.toPrecision(6) : v, 1)); if (b.errors.length) console.error(b.errors); await b.close();
})().catch(e => { console.error(e); process.exit(1); });
