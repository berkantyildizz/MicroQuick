/* Minimal Chrome DevTools Protocol driver (no dependencies; Node >= 22).
 * Used for the end-to-end test, the runtime benchmark and the figures. */
const { spawn } = require('child_process'), fs = require('fs'), os = require('os'), path = require('path');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
async function launch(url, { width = 1500, height = 1000, scale = 2 } = {}) {
  const port = 9300 + Math.floor(Math.random() * 500), dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mq-chrome-'));
  const proc = spawn(CHROME, ['--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${dir}`, '--no-first-run', '--disable-extensions', '--hide-scrollbars', `--window-size=${width},${height}`, `--force-device-scale-factor=${scale}`, '--allow-file-access-from-files', 'about:blank'], { stdio: 'ignore' });
  let target; for (let i = 0; i < 80 && !target; i++) { await new Promise(r => setTimeout(r, 150)); try { target = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find(t => t.type === 'page'); } catch (e) {} }
  if (!target) throw new Error('Chrome did not start');
  const ws = new WebSocket(target.webSocketDebuggerUrl); await new Promise(r => ws.addEventListener('open', r));
  let id = 0; const pending = new Map(), errors = [], offline = [];
  ws.addEventListener('message', ev => { const m = JSON.parse(ev.data); if (m.id && pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result); }
    else if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails.exception ? m.params.exceptionDetails.exception.description : m.params.exceptionDetails.text);
    else if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map(a => a.value || a.description).join(' '));
    else if (m.method === 'Network.requestWillBeSent' && !/^(file|data|blob|about):/.test(m.params.request.url)) offline.push(m.params.request.url); });
  const send = (method, params = {}) => new Promise((resolve, reject) => { pending.set(++id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })); });
  await send('Runtime.enable'); await send('Page.enable'); await send('Network.enable');
  await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: scale, mobile: false });
  await send('Page.navigate', { url }); await new Promise(r => setTimeout(r, 1200));
  const ev = async (expression) => { const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }); if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception ? r.exceptionDetails.exception.description : r.exceptionDetails.text); return r.result.value; };
  const shot = async (file, selector, pad = 0) => { let clip; if (selector) { const b = await ev(`(()=>{const r=document.querySelector(${JSON.stringify(selector)}).getBoundingClientRect();return {x:r.left+window.scrollX,y:r.top+window.scrollY,width:r.width,height:r.height}})()`); clip = { x: Math.max(0, b.x - pad), y: Math.max(0, b.y - pad), width: b.width + 2 * pad, height: b.height + 2 * pad, scale: 1 }; }
    const r = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true, clip }); fs.writeFileSync(file, Buffer.from(r.data, 'base64')); };
  const close = async () => { try { await send('Browser.close'); } catch (e) {} proc.kill(); try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {} };
  return { ev, shot, send, close, errors, offline, version: async () => (await send('Browser.getVersion')).product };
}
module.exports = { launch };
