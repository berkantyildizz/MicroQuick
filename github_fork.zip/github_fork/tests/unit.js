#!/usr/bin/env node
/* Hand-checkable unit tests of the MicroQuick core.  Usage: node tests/unit.js */
const MQ = require('../src/microquick_core.js'); let fail = 0, n = 0;
const eq = (name, got, want, tol = 1e-9) => { n++; const ok = (Number.isNaN(want) && Number.isNaN(got)) || Math.abs(got - want) <= tol; if (!ok) { fail++; console.log(`FAIL ${name}: got ${got}, expected ${want}`); } };
const data = (rows, head) => { const P = MQ.parseGenotypes(head, rows); return { P, D: MQ.encode(P.records, P.lociNames) }; };
// 1. one locus, 4 individuals: AA AB AB BB  -> p = 0.5, Ho = 0.5, He = 0.5, uHe = 8/7*0.5, PIC = 0.375
let { D } = data([['a', 1, 100, 100], ['a', 2, 100, 102], ['a', 3, 100, 102], ['a', 4, 102, 102]], ['pop', 'id', 'L(1)', 'L(2)']);
let d = MQ.describe(D).locus[0];
eq('Na', d.Na, 2); eq('Ne', d.Ne, 2); eq('Ho', d.Ho, 0.5); eq('He', d.He, 0.5); eq('uHe', d.uHe, 4 / 7); eq('PIC', d.PIC, 0.375); eq('I', d.I, Math.log(2)); eq('F', d.F, 0);
// 2. monomorphic locus: everything defined or NaN, never an exception
({ D } = data([['a', 1, 100, 100], ['a', 2, 100, 100], ['b', 3, 100, 100], ['b', 4, 100, 100]], ['pop', 'id', 'L(1)', 'L(2)']));
d = MQ.describe(D); eq('mono Na', d.locus[0].Na, 1); eq('mono He', d.locus[0].He, 0); eq('mono PIC', d.locus[0].PIC, 0); eq('mono Gst', d.locus[0].Gst, NaN); eq('mono theta', d.locus[0].theta, NaN);
eq('mono HWE p', MQ.hweAll(D, 99, MQ.rng(1)).pooled[0].pExact, NaN);
// 3. two populations fixed for different alleles: theta = 1, Jost D = 1, G''ST = 1
({ D } = data([...Array(10).keys()].map(i => ['a', i, 100, 100]).concat([...Array(10).keys()].map(i => ['b', i, 102, 102])), ['pop', 'id', 'L(1)', 'L(2)']));
d = MQ.describe(D).multi; eq('fixed theta', d.theta, 1); eq('fixed D', d.D, 1); eq('fixed Gst2', d.Gst2, 1); eq('fixed Gst', d.Gst, 1 / (1 + 0) * d.Gst);
// 4. missing data rules: half-scored genotype is a missing genotype; 0, NA, ?, -9 and empty are missing
let P; ({ P, D } = data([['a', 1, 100, ''], ['a', 2, 0, 0], ['a', 3, 'NA', 'NA'], ['a', 4, '?', '?'], ['a', 5, -9, -9], ['a', 6, 100, 102], ['a', 7, 'x', 102]], ['pop', 'id', 'L(1)', 'L(2)']));
eq('partial count', P.warn.partial, 1); eq('unreadable count', P.warn.unreadable, 1); eq('typed N', MQ.describe(D).locus[0].N, 1);
// 5. single-column format, more than two alleles flagged
({ P, D } = data([['a', '100/102'], ['a', '100:100'], ['a', '100/102/104'], ['a', '']], ['pop', 'L1'])); eq('combined detected', +P.combined, 1); eq('polyploid flagged', P.warn.polyploid, 1); eq('combined N', MQ.describe(D).locus[0].N, 2);
// 6. p-value adjustment against R: p.adjust(c(0.01,0.02,0.03,0.04,0.2), "BH") = 0.05 0.05 0.05 0.05 0.2 ; "BY" = 0.1141667 x4, 0.4566667 ; bonferroni
let a = MQ.pAdjust([0.01, 0.02, 0.03, 0.04, 0.2], 'bh'); [0.05, 0.05, 0.05, 0.05, 0.2].forEach((v, i) => eq('BH' + i, a[i], v));
a = MQ.pAdjust([0.01, 0.02, 0.03, 0.04, 0.2], 'by'); [0.11416667, 0.11416667, 0.11416667, 0.11416667, 0.45666667].forEach((v, i) => eq('BY' + i, a[i], v, 1e-7));
a = MQ.pAdjust([0.01, NaN, 0.03], 'bonferroni'); eq('bonf', a[0], 0.02); eq('bonf NaN', a[1], NaN);
// 7. chi-square tail against R: pchisq(3.84, 1, lower=FALSE) = 0.05004352 ; pchisq(30, 10, lower=FALSE) = 0.0008566412 ; pchisq(400, 300, lower = FALSE) = 9.678621995e-05
eq('chi2 a', MQ.chi2sf(3.84, 1), 0.05004352, 1e-8); eq('chi2 b', MQ.chi2sf(30, 10), 0.0008566412, 1e-9); eq('chi2 c', MQ.chi2sf(400, 300), 9.678621995e-05, 1e-12);
// 8. rarefaction: all alleles seen once, sample g of N copies -> expected g distinct alleles
eq('richness', MQ.richness([1, 1, 1, 1, 1, 1], 4), 4); eq('richness full', MQ.richness([3, 2, 1], 6), 3);
// 9. reproducibility: same seed, same Monte Carlo p value; CSV reader handles ; delimiter, quotes and BOM
({ D } = data([...Array(30).keys()].map(i => ['a', i, 100 + 2 * (i % 3), 100 + 2 * ((i * 7) % 4)]), ['pop', 'id', 'L(1)', 'L(2)']));
eq('seeded', MQ.hweAll(D, 499, MQ.rng(5)).pooled[0].pExact, MQ.hweAll(D, 499, MQ.rng(5)).pooled[0].pExact, 0);
const c = MQ.parseDelimited('﻿pop;id;"L;1"\r\na;1;"100/102"\r\n'); eq('csv delim', +(c.delim === ';'), 1); eq('csv cols', c.rows[0].length, 3); eq('csv quoted', +(c.rows[0][2] === 'L;1'), 1);
// 10. Genepop export: allele codes are zero-padded, missing = 000000
({ D } = data([['a', 'x', 98, 102], ['a', 'y', '', '']], ['pop', 'id', 'L(1)', 'L(2)'])); const g = MQ.toGenepop(D, 't').split('\n'); eq('genepop typed', +(g[3].endsWith('098102')), 1); eq('genepop missing', +(g[4].endsWith('000000')), 1);
console.log(fail ? `${fail} of ${n} checks FAILED` : `All ${n} checks passed.`); process.exit(fail ? 1 : 0);
