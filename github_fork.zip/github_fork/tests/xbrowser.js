// Runs the released MicroQuick.html in Firefox and WebKit (Safari's engine) and compares the interface values with the Node run of the core.
const { firefox, webkit, chromium } = require('playwright'), fs = require('fs'), path = require('path');
const root = process.argv[2];
(async () => {
  for (const [name, eng] of [['firefox', firefox], ['webkit', webkit]]) {
    const b = await eng.launch(), pg = await b.newPage(), errs = [], reqs = [];
    pg.on('pageerror', e => errs.push(String(e))); pg.on('console', m => { if (m.type() === 'error') errs.push(m.text()); }); pg.on('request', r => { if (!/^(file|data|blob|about):/.test(r.url())) reqs.push(r.url()); });
    await pg.goto('file://' + encodeURI(path.join(root, 'MicroQuick.html')));
    for (const ds of ['benchmark_simulated', 'nancycats']) {
      const csv = fs.readFileSync(path.join(root, 'data', ds + '.csv'), 'utf8'), ref = JSON.parse(fs.readFileSync(path.join(root, 'validation/out', ds + '.json'), 'utf8'));
      await pg.evaluate(([c, n]) => UI.loadText(c, n), [csv, ds + '.csv']); await pg.evaluate(() => UI.run());
      const r = await pg.evaluate(() => { const S = UI.S; return { theta: S.desc.multi.theta, Gst: S.desc.multi.Gst, He: S.desc.locus.map(l => l.He), pw: S.pw.map(x => x.theta), pca: S.pca.varExp.slice(0, 5), post: S.da ? Array.from(S.da.posterior[0]) : [], hw: S.hw.byPop.flat().map(c => c.pExact), t: S.timing.total, tabs: Object.keys(S.tables).length }; });
      for (const t of ['qc', 'locus', 'pops', 'fstats', 'diff', 'pca', 'cluster', 'charts', 'guide']) await pg.evaluate(x => UI.switchTab(x), t);
      const d = (a, c) => Math.max(...a.map((v, i) => Math.abs(v - c[i])));
      console.log(name, b.version(), ds, 'max|diff| theta', Math.abs(r.theta - ref.multi.theta).toExponential(1), 'He', d(r.He, ref.locus.map(l => l.He)).toExponential(1), 'pairwise', d(r.pw, ref.pairwise.map(p => p.theta)).toExponential(1), 'PCA%', d(r.pca, ref.pca.varExp.slice(0, 5)).toExponential(1), '| tables', r.tabs, '| time', (r.t / 1000).toFixed(2), 's');
      fs.writeFileSync(`hw_${name}_${ds}.json`, JSON.stringify(r.hw));
    }
    console.log(name, 'page errors:', errs.length ? errs : 'none', '| network requests:', reqs.length ? reqs : 'none'); await b.close();
  }
})().catch(e => { console.error(e); process.exit(1); });
