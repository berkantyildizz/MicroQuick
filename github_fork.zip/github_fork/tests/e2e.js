#!/usr/bin/env node
/* End-to-end test: opens the built MicroQuick.html in headless Chrome, analyses a CSV through the user
 * interface, and checks that (i) no error and no network request occurs and (ii) what the interface holds is
 * identical to what the Node run of the same core produced.   Usage: node tests/e2e.js [dataset] */
const path = require('path'), fs = require('fs'), { launch } = require('./cdp.js');
(async () => {
  const name = process.argv[2] || 'benchmark_simulated', root = path.join(__dirname, '..');
  const b = await launch('file://' + encodeURI(path.join(root, 'MicroQuick.html')));
  const csv = fs.readFileSync(path.join(root, 'data', name + '.csv'), 'utf8');
  await b.ev(`UI.loadText(${JSON.stringify(csv)}, ${JSON.stringify(name + '.csv')})`);
  await b.ev(`document.getElementById('setPerm').value='999'; UI.run()`);
  const r = await b.ev(`(()=>{const S=UI.S;return {n:S.D.n,L:S.D.L,K:S.D.K,multi:S.desc.multi,He:S.desc.locus.map(l=>l.He),theta:S.pw.map(x=>x.theta),timing:S.timing,tables:Object.keys(S.tables),tabs:[...document.querySelectorAll('.tab-btn')].length}})()`);
  const ref = JSON.parse(fs.readFileSync(path.join(root, 'validation', 'out', name + '.json'), 'utf8'));
  const d = (x, y) => Math.max(...x.map((v, i) => Math.abs(v - y[i])));
  const checks = { 'He per locus': d(r.He, ref.locus.map(l => l.He)), 'pairwise theta': r.theta.length ? d(r.theta, ref.pairwise.map(p => p.theta)) : 0, 'multilocus theta': Math.abs(r.multi.theta - ref.multi.theta), 'multilocus Gst': Math.abs(r.multi.Gst - ref.multi.Gst) };
  for (const t of ['overview', 'qc', 'locus', 'pops', 'fstats', 'diff', 'pca', 'cluster', 'charts', 'guide']) await b.ev(`UI.switchTab('${t}')`);
  await b.ev(`document.getElementById('daPrior').value='km'; UI.recluster(); UI.toggleTheme(); UI.toggleTheme(); 1`);
  await b.ev(`Object.keys(UI.S.tables).map(k=>UI.tableCSV(k).length).length`);
  console.log(`${name}: ${r.n} ind, ${r.L} loci, ${r.K} pops; ${r.tables.length} tables; browser ${await b.version()}`);
  console.log('timing (ms):', Object.entries(r.timing).map(([k, v]) => `${k} ${Math.round(v)}`).join(', '));
  console.log('max |UI − Node core|:', JSON.stringify(checks));
  console.log('page errors:', b.errors.length ? b.errors : 'none', '| network requests:', b.offline.length ? b.offline : 'none');
  await b.close();
  process.exit(b.errors.length || b.offline.length || Object.values(checks).some(v => v > 1e-12) ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
